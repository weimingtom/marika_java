//
// Config--��̬�趨
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__config_h__
#define	__config_h__

#define	CompanyName			"HyperWorks"
#define	ApplicationName		"GraphicsTest"
#define	ApplicationTitle	"��ʾ��Ϸ��ͼƬ-�ű�������"

#define	WindowWidth		640
#define	WindowHeight	480

#define	CGPATH			"cgdata/"

#endif
