//
// Script player
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "StdAfx.h"
#include "GraphicTest.h"
#include "resource.h"

CGraphicTestApp	theApp;

BOOL CGraphicTestApp::InitInstance()
{
	// �����ڵ�����
	if (!MainWin.Create(this, ApplicationTitle, LoadMenu(IDC_APPMENU)))
		return FALSE;

	MainWnd = &MainWin;

	return TRUE;
}
