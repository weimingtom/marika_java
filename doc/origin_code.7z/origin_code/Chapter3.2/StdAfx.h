#include <WinLib.h>
#include "Config.h"

#ifdef	_MSC_VER
// ����Ŀ���
//  warning C4100: 'XXX' : 
// 
// 
#pragma warning(disable: 4100)
#endif
