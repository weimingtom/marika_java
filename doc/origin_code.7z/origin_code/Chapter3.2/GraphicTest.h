//
// Script player
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__GraphicTest_h__
#define	__GraphicTest_h__

#include "Application.h"
#include "MainWin.h"

class CGraphicTestApp: public CWinApp {
  public:
	BOOL InitInstance();

  protected:
	CMainWin	MainWin;
} ;

#endif
