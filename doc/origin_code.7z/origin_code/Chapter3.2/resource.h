//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GraphicTest.rc
//
#define IDC_APPICON                     100
#define IDC_APPMENU                     100
#define IDC_APPACCEL                    100
#define ID_APP_EXIT                     101
#define IDD_ABOUT                       101
#define ID_APP_ABOUT                    102
#define IDC_TITLE                       1001
#define IDC_COMPANY                     1002
#define IDC_RIGHTLOAD                   40001
#define IDC_RIGHTCLEAR                  40002
#define IDC_BACKLOAD                    40003
#define IDC_BACKCLEAR                   40004
#define IDC_LEFTLOAD                    40005
#define IDC_LEFTCLEAR                   40006
#define IDC_CENTERLOAD                  40007
#define IDC_CENTERCLEAR                 40008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
