//
// װ�롤�洢����
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__loadsave_h__
#define	__loadsave_h__

#include "Action.h"

//
// ��Ϸװ�롤�洢�������
//
class CGameLoadSaveAction: public CAction {
  public:
	virtual	void Initialize(CMainWin *parent, unsigned param1=0, unsigned param2=0);

	virtual	void LButtonDown(UINT modKeys, CPoint point);
	virtual	void LButtonUp(UINT modKeys, CPoint point);
	virtual	void RButtonDown(UINT modKeys, CPoint point);
	virtual	void RButtonUp(UINT modKeys, CPoint point);
	virtual	void MouseMove(UINT modKeys, CPoint point);
	virtual	void KeyDown(UINT key);
	virtual void TimedOut(int timerId);

  protected:
	virtual void DoLoadSave() = 0;

	int		Selection;
	BOOL	Pressed;
	BOOL	CancelPressed;
	int		Flags;
} ;

class CGameLoadAction: public CGameLoadSaveAction {
  protected:
	virtual void DoLoadSave();
} ;

class CGameSaveAction: public CGameLoadSaveAction {
  protected:
	virtual void DoLoadSave();
} ;

#endif
