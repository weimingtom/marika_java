//
// Script converter
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "StdAfx.h"
#include "MakeScript.h"
#include "Reader.h"
#include "Lexer.h"

static const char FmtThenLabel[] = "#endif#%08x";

//
// ���캯��
//
MakeScript::MakeScript()
{
	reader = 0;
	nerror = 0;
	then_index = 0;

	ncommand = 0;

	add_value = false;

	if ((command_buffer = new char[MAX_COMMAND]) == 0)
		throw bad_alloc();

	// ��������ʼ��
	cmd_table.insert(CmdTab("set",		&MakeScript::SetCmd));
	cmd_table.insert(CmdTab("calc",		&MakeScript::SetCmd));
	cmd_table.insert(CmdTab("text",		&MakeScript::TextCmd));
	cmd_table.insert(CmdTab("goto",		&MakeScript::GotoCmd));
	cmd_table.insert(CmdTab("if",		&MakeScript::IfCmd));
	cmd_table.insert(CmdTab("else",		&MakeScript::ElseCmd));
	cmd_table.insert(CmdTab("endif",	&MakeScript::EndifCmd));
	cmd_table.insert(CmdTab("menu",		&MakeScript::MenuCmd));
	cmd_table.insert(CmdTab("exec",		&MakeScript::ExecCmd));
	cmd_table.insert(CmdTab("load",		&MakeScript::LoadCmd));
	cmd_table.insert(CmdTab("update",	&MakeScript::UpdateCmd));
	cmd_table.insert(CmdTab("clear",	&MakeScript::ClearCmd));
	cmd_table.insert(CmdTab("music",	&MakeScript::MusicCmd));
	cmd_table.insert(CmdTab("stopm",	&MakeScript::StopmCmd));
	cmd_table.insert(CmdTab("wait",		&MakeScript::WaitCmd));
	cmd_table.insert(CmdTab("sound",	&MakeScript::SoundCmd));
	cmd_table.insert(CmdTab("fadein",	&MakeScript::FadeInCmd));
	cmd_table.insert(CmdTab("fadeout",	&MakeScript::FadeOutCmd));
	cmd_table.insert(CmdTab("wipein",	&MakeScript::WipeInCmd));
	cmd_table.insert(CmdTab("wipeout",	&MakeScript::WipeOutCmd));
	cmd_table.insert(CmdTab("cutin",	&MakeScript::CutInCmd));
	cmd_table.insert(CmdTab("cutout",	&MakeScript::CutOutCmd));
	cmd_table.insert(CmdTab("whitein",	&MakeScript::WhiteInCmd));
	cmd_table.insert(CmdTab("whiteout",	&MakeScript::WhiteOutCmd));
	cmd_table.insert(CmdTab("flash",	&MakeScript::FlashCmd));
	cmd_table.insert(CmdTab("shake",	&MakeScript::ShakeCmd));
	cmd_table.insert(CmdTab("mode",		&MakeScript::ModeCmd));
	cmd_table.insert(CmdTab("system",	&MakeScript::SystemCmd));
	cmd_table.insert(CmdTab("end",		&MakeScript::EndCmd));
}

//
// ��������
//
MakeScript::~MakeScript()
{
	delete[] command_buffer;
}

//
// ������������
//
bool MakeScript::OpenValueTable()
{
	ifstream	fin(GetValueFile());

	if (!fin)
		return false;

	string	str;
	while ((fin >> str) != 0) {
		value_name.push_back(str);
	}

	return true;
}

//
// ������д���������
//
bool MakeScript::CloseValueTable()
{
	ofstream	fout(GetValueFile());

	if (!fout)
		throw("can't create value table file");

	for (int i=0; i<value_name.size(); i++) {
		fout << value_name[i] << '\n';
	}
	return true;
}

//
// �ڱ���������Ѱ�ñ�������������ֵ
//
int MakeScript::FindValue(const char *value)
{
	vector<string>::iterator vp = find(value_name.begin(), value_name.end(), value);

	if (vp != value_name.end())				// �ҵ�����
		return vp - value_name.begin();		// ���ر���������

	if (value_name.size() >= MAX_VALUES) {	// ������������ˣ�
		Error("too meny values.");
		return -1;
	}

	value_name.push_back(value);			// ��������
	add_value = true;						// �����и��ĵĶ�������

	return value_name.size() - 1;			// ���ر�������
}

//
// ��������Ĳ��յ���
//
const char *MakeScript::GetValueFile() const
{
	return "value.tbl";
}

//
// ������Ϣ�����
//
void MakeScript::OutputMessage(int code, const char *str) const
{
	cout << str << endl;
}

//
// ���뵵�����к�(������Ϣ)
//
int MakeScript::GetErrorPrefix(char *str) const
{
	if (reader == 0)
		return 0;
	return sprintf(str, "%s:%d ", reader->GetFileName(), reader->GetLineNo());
}

//
// ������Ϣ�����(�д�����)
//
void __cdecl MakeScript::ErrorMessage(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	va_start(args, fmt);
	vsprintf(str, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgError, str);
}

//
// ������Ϣ�����(�������ֵ���к�)
//
void __cdecl MakeScript::Error(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	int		len = GetErrorPrefix(str);
	va_start(args, fmt);
	vsprintf(str + len, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgError, str);
}

//
// ��ʾ����������Ϣ(�������ֵ���к�)
//
void __cdecl MakeScript::FatalError(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	int		len = GetErrorPrefix(str);
	va_start(args, fmt);
	vsprintf(str + len, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgFatal, str);
}

//
// ��ʾ��Ϣ(����Ϣ������������)
//
void __cdecl MakeScript::Notice(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	va_start(args, fmt);
	vsprintf(str, fmt, args);
	va_end(args);

	OutputMessage(MsgNotice, str);
}

//
// ����if thenʱ�ı�ǩ
//
char *MakeScript::ThenLabel()
{
	static	char	tmp[24];
	unsigned idx = then_index++ << 16;		// ����then�ı�ǩ����
	then_nest.push(idx);					// ѹ����ջ(push)
	sprintf(tmp, FmtThenLabel, idx);
	return tmp;
}

//
// ��¼��ǩ
//
void MakeScript::AddLabel(const char *label)
{
	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->label == label) {			// �Ѿ���¼��
			if (lp->ref == NULL) {			// ��ǩ�Ѿ�������
				Error("label '%s' redefinition line %d and %d",
					label, lp->line, reader->GetLineNo());
			}
			else {							// ��ǩ�Ѿ����ο���
				LabelRef *chain = lp->ref;

				lp->line = reader->GetLineNo();
				lp->ref = NULL;
				lp->jmp_addr = ncommand;

				while (chain != NULL) {		// ����ο�
					LabelRef *next = chain->next;
					*(chain->label_ref) = ncommand;
					delete chain;
					chain = next;
				}
			}
			return;
		}
	}
	// ��¼�µı�ǩ
	labels.push_back(Label(label, reader->GetLineNo(), ncommand, 0));
}

//
// �ο���ǩ
//
void MakeScript::FindLabel(const char *label, long *reference)
{
	*reference = 0;

	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->label == label) {			// �Ѿ���¼��
			if (lp->ref != NULL) {			// ��ǩ�б��ο�
				// �����ڲο�������
				lp->ref = new LabelRef(lp->ref, reference);
			}
			else {							// �Ѿ���¼��
				// ������ԾĿ��
				*reference = lp->jmp_addr;
			}
			return;
		}
	}
	// ��¼�µı�ǩ�ο�
	LabelRef *chain = new LabelRef(0, reference);
	labels.push_back(Label(label, reader->GetLineNo(), 0, chain));
}

//
// ��ǩ��ȷ��
//
void MakeScript::LabelCheck()
{
	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->ref != NULL) {			// ���вο�����
			const char *label = lp->label.c_str();
			switch (*label) {
			  case '#':
				ErrorMessage("can't find \"endif\". (line %d)", lp->line);
				break;

			  default:
				ErrorMessage("label %s undefined. (line %d)", label, lp->line);
				break;
			}
			LabelRef *chain = lp->ref;
			while (chain != NULL) {		// �ͷŲο�����
				LabelRef *next = chain->next;
				delete chain;
				chain = next;
			}
		}
	}
}

//
// ��¼��ǩ
//
void MakeScript::SetLabel(Lexer &lexer)
{
	if (lexer.NumToken() != 1) {
		Error("too meny parameter");
		return;
	}

	const char *p = lexer.GetString() + 1;
	AddLabel(p);
}

//
// ��������������ڴ�
//
void *MakeScript::AllocCommand(int size, int cmd)
{
	if (ncommand + size >= MAX_COMMAND)
		throw("command table overflow");

	void *p = command_buffer + ncommand;
	ncommand += size;

	memset(p, 0, size);
	((single_cmd_t *)p)->type = cmd;
	((single_cmd_t *)p)->size = size;

	return p;
}

#define	NewCommand(type, id)	(type *)AllocCommand(sizeof(type), id)

//
// ���ַ�����¼�ڱ�����
//
unsigned MakeScript::AddMessage(const char *msg, int limit)
{
	int len = (strlen(msg) + 4) & ~3;	// ���4λԪ�Ķ���

	if (len > limit) {
		Error("text length limit over");
		return 0;
	}

	if (ncommand + len >= MAX_COMMAND)
		throw("command table overflow");

	strcpy(command_buffer + ncommand, msg);
	ncommand += len;

	return len;
}

//
// �ȽϹؼ���
//
bool MakeScript::ChkKeyword(const char *str, const char *keyword)
{
	while (*str) {
		if (tolower(*str++) != *keyword++)
			return false;
	}
	return true;
}

//
// �ж�CG�����λ��
//
int MakeScript::GetPosition(const char *str)
{
	if (ChkKeyword(str, "center"))
		return POSITION_CENTER;
	if (ChkKeyword(str, "left"))
		return POSITION_LEFT;
	if (ChkKeyword(str, "right"))
		return POSITION_RIGHT;
	if (ChkKeyword(str, "bg") || ChkKeyword(str, "back"))
		return POSITION_BACK;
	if (ChkKeyword(str, "bgo") || ChkKeyword(str, "backonly"))
		return POSITION_BACKONLY;
	if (ChkKeyword(str, "overlap"))
		return POSITION_OVERLAP;

	Error("syntax error (position)");
	return POSITION_BACK;
}

//
// ��Чָ���ĸ���������������
//
int MakeScript::GetUpdateType(const char *str)
{
	if (ChkKeyword(str, "cut") || ChkKeyword(str, "now"))
		return UPDATE_NOW;
	if (ChkKeyword(str, "overlap"))
		return UPDATE_OVERLAP;
	if (ChkKeyword(str, "wipe"))
		return UPDATE_WIPE;

	Error("syntax error (update type)");
	return UPDATE_NOW;
}

//
// ��¼�޲���������
//
void MakeScript::CommandOnlyCmd(Lexer &lexer, int cmd)
{
	if (lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	NewCommand(single_cmd_t, cmd);
}

//
// ��¼set����
//
void MakeScript::SetCmd(Lexer &lexer)
{
	const char *p1 = lexer.GetString();
	const char *p2 = lexer.GetString();
	int value;
	bool b3 = lexer.GetValue(&value);

	if (p1 == 0 || p2 == 0 || !b3 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}

	if (strcmp(p2, "=") == 0) {			// ָ��
		set_value_t *cp = NewCommand(set_value_t, SET_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->set_value = value;
	}
	else if (strcmp(p2, "+") == 0) {	// �ӷ�
		calc_value_t *cp = NewCommand(calc_value_t, CALC_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->add_value = value;
	}
	else if (strcmp(p2, "-") == 0) {	// ����
		calc_value_t *cp = NewCommand(calc_value_t, CALC_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->add_value = -value;			// ��Ϊ���ϸ�ֵ
	}
	else {
		Error("syntax error");
	}
}

//
// ��¼goto����
//
void MakeScript::GotoCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in goto command)");
		return;
	}

	goto_t *cp = NewCommand(goto_t, GOTO_CMD);
	FindLabel(p, &(cp->goto_label));
}

//
// �жϲ�ȡ�ñ����������ַ���
//
bool MakeScript::GetValueOrNumber(ValueOrNumber *value, Lexer &lexer)
{
	int type = lexer.GetType();

	if (type == Lexer::IsString) {			// �ַ���
		const char *p = lexer.GetString();
		value->value = FindValue(p);
		value->isvalue = false;
	}
	else {									// �ַ�������
		if (!lexer.GetValue(&value->value))	// ��ȡ����
			return false;					// ����
		value->isvalue = true;
	}
	return true;
}

//
// ָ������Ƚ������ӵĶ�Ӧ��ϵ
//
int MakeScript::BoolOp(const char *op)
{
	if (strcmp(op, "==") == 0) {
		return IF_TRUE_CMD;
	}
	if (strcmp(op, "!=") == 0) {
		return IF_FALSE_CMD;
	}
	if (strcmp(op, "<=") == 0) {
		return IF_SMALLER_EQU_CMD;
	}
	if (strcmp(op, ">=") == 0) {
		return IF_BIGGER_EQU_CMD;
	}
	if (strcmp(op, "<") == 0) {
		return IF_SMALLER_CMD;
	}
	if (strcmp(op, ">") == 0) {
		return IF_BIGGER_CMD;
	}
	Error("syntax error");
	return -1;
}

//
// �Ƚ������ӵ��ж�(�߼���ת)
//
int MakeScript::NegBoolOp(const char *op)
{
	if (strcmp(op, "==") == 0) {
		return IF_FALSE_CMD;
	}
	if (strcmp(op, "!=") == 0) {
		return IF_TRUE_CMD;
	}
	if (strcmp(op, "<=") == 0) {
		return IF_BIGGER_CMD;
	}
	if (strcmp(op, ">=") == 0) {
		return IF_SMALLER_CMD;
	}
	if (strcmp(op, "<") == 0) {
		return IF_BIGGER_EQU_CMD;
	}
	if (strcmp(op, ">") == 0) {
		return IF_SMALLER_EQU_CMD;
	}
	Error("syntax error");
	return -1;
}

//
// ��¼if����
//
void MakeScript::IfCmd(Lexer &lexer)
{
	ValueOrNumber	val1;
	ValueOrNumber	val2;
	bool	b1 = GetValueOrNumber(&val1, lexer);
	const char *op = lexer.GetString();
	bool	b2 = GetValueOrNumber(&val2, lexer);

	if (!b1 || !b2 || op == 0) {
		Error("syntax error (in if command)");
		return;
	}

	if_t   *cp = NewCommand(if_t, 0);
	cp->flag = 0;
	if (val1.isvalue)
		cp->flag |= 1;
	cp->value1 = val1.value;
	if (val2.isvalue)
		cp->flag |= 2;
	cp->value2 = val2.value;

	const char *p = lexer.GetString();
	const char *label = 0;
	if (p != 0) {
		if (stricmp(p, "goto") == 0) {		// if-goto
			label = lexer.GetString();
			cp->type = BoolOp(op);
		}
		else if (stricmp(p, "then") == 0) {	// if-then
			label = ThenLabel();
			cp->type = NegBoolOp(op);
		}
	}
	if (label == 0 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	FindLabel(label, &(cp->goto_label));
}

//
// ����else����
//
void MakeScript::ElseCmd(Lexer &lexer)
{
	if (then_nest.empty()) {				// then��ǩû�е�¼
		Error("\"if\", \"else\" nest error.");
		return;
	}

	unsigned idx = then_nest.top();
	then_nest.pop();

	char	else_label[24];
	sprintf(else_label, FmtThenLabel, idx);

	goto_t *cp = NewCommand(goto_t, GOTO_CMD);
	char	goto_label[24];
	then_nest.push(idx + 1);
	sprintf(goto_label, FmtThenLabel, idx | 0xffff);
	FindLabel(goto_label, &(cp->goto_label));
	AddLabel(else_label);

	const char *p = lexer.GetString();

	if (p == 0) {							// ���ֻ��else�ͽ���
		return;
	}
	else if (stricmp(p, "if") == 0) {		// else ifʱ�Ķ���
		ValueOrNumber	val1;
		ValueOrNumber	val2;
		bool	b1 = GetValueOrNumber(&val1, lexer);
		const char *op = lexer.GetString();
		bool	b2 = GetValueOrNumber(&val2, lexer);

		if (!b1 || !b2 || op == 0) {
			Error("syntax error (in else if command)");
			return;
		}
		if_t   *cp = NewCommand(if_t, NegBoolOp(op));
		cp->flag = 0;
		if (val1.isvalue)
			cp->flag |= 1;
		cp->value1 = val1.value;
		if (val2.isvalue)
			cp->flag |= 2;
		cp->value2 = val2.value;

		const char *p = lexer.GetString();
		if (p == 0 || stricmp(p, "then") != 0) {
			Error("syntax error");
			return;
		}

		char	label[24];
		sprintf(label, FmtThenLabel, idx + 1);
		FindLabel(label, &(cp->goto_label));
	}
	else {
		Error("syntax error (in else command)");
		return;
	}
}

//
// ����endif����
//
void MakeScript::EndifCmd(Lexer &lexer)
{
	if (lexer.GetString() != 0) {
		Error("syntax error (in endif command)");
		return;
	}

	if (then_nest.empty()) {
		Error("\"if\", \"endif\" nest error.");
		return;
	}

	char	tmp[24];
	unsigned idx = then_nest.top();
	then_nest.pop();

	sprintf(tmp, FmtThenLabel, idx);
	AddLabel(tmp);

	if ((idx & 0xffff) != 0) {
		sprintf(tmp, FmtThenLabel, idx | 0xffff);
		AddLabel(tmp);
	}
}

//
// ��¼Menu����
//
void MakeScript::MenuCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in menu command)");
		return;
	}
	int	value_addr = FindValue(p);

	NewCommand(menu_init_t, MENU_INIT_CMD);

	const char *str;
	for (int no=0; (str = reader->GetString()) != NULL; no++) {
		if (stricmp(str, "end") == 0)
			break;

		menu_item_t *ip = NewCommand(menu_item_t, MENU_ITEM_CMD);
		ip->label_len = (unsigned char)AddMessage(str, 255);
		ip->number = no + 1;
	}
	menu_t *op = NewCommand(menu_t, MENU_CMD);
	op->value_addr = value_addr;
}

//
// ��¼load����
//
void MakeScript::LoadCmd(Lexer &lexer)
{
	const char *p1 = lexer.GetString();
	const char *p2 = lexer.GetString();

	if (p1 == 0 || p2 == 0 || lexer.GetString() != 0) {
		Error("syntax error (in load command)");
		return;
	}

	load_t *cp = NewCommand(load_t, LOAD_CMD);
	cp->flag = GetPosition(p1);
	cp->path_len = (unsigned char)AddMessage(p2, 255);
}

//
// ��¼update����
//
void MakeScript::UpdateCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in update command)");
		return;
	}

	update_t *cp = NewCommand(update_t, UPDATE_CMD);
	cp->flag = GetUpdateType(p);
}

//
// ��¼clear����
//
void MakeScript::ClearCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in clear command)");
		return;
	}

	if (stricmp(p, "text") == 0) {		// clear text�́A�ʈ���
		NewCommand(clear_text_t, CLEAR_TEXT_CMD);
	}
	else {
		clear_t *cp = NewCommand(clear_t, CLEAR_CMD);
		cp->pos = GetPosition(p);
	}
}

//
// ��¼music����
//
void MakeScript::MusicCmd(Lexer &lexer)
{
	int value;
	bool isval = lexer.GetValue(&value);

	if (!isval || value <= 0 || lexer.GetString() != 0) {
		Error("syntax error (in music command)");
		return;
	}
	music_t *cp = NewCommand(music_t, MUSIC_CMD);
	cp->number = value;
}

//
// ��¼sound����
//
void MakeScript::SoundCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in sound command)");
		return;
	}
	sound_t *cp = NewCommand(sound_t, SOUND_CMD);
	cp->path_len = (unsigned char)AddMessage(p, 255);
}

//
// ��¼exec����
//
void MakeScript::ExecCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in exec command)");
		return;
	}
	exec_cmd_t *cp = NewCommand(exec_cmd_t, EXEC_CMD);
	cp->path_len = (unsigned char)AddMessage(p, 255);
}

//
// ��¼wait����
//
void MakeScript::WaitCmd(Lexer &lexer)
{
	int value;
	bool isval = lexer.GetValue(&value);

	if (!isval || value <= 0 || lexer.GetString() != 0) {
		Error("syntax error (in wait command)");
		return;
	}
	sleep_t *cp = NewCommand(sleep_t, SLEEP_CMD);
	cp->time = value;
}

//
// ������ֵ�β��
//
bool MakeScript::ChkTermination(const char *str)
{
	if (*str++ != '.')
		return false;
	while (*str) {
		if (!isspace(*str))
			return false;
	}
	return true;
}

//
// ��¼text����
//
void MakeScript::TextCmd(Lexer &lexer)
{
	if (lexer.GetString() != 0) {
		Error("syntax error (in text command)");
		return;
	}

	text_t *cp = NewCommand(text_t, TEXT_CMD);

	string	work;

	for (int i=0; ; i++) {
		const char *str;
		if ((str = reader->GetString()) == NULL) {
			Error("syntax error (text syntax)");
			break;
		}
		if (ChkTermination(str))
			break;
		work += str;
		work += '\n';

		if (i >= MAX_TEXTLINE) {
			Error("text line overflow");
			break;
		}
	}
	cp->msg_len = (unsigned short)AddMessage(work.c_str(), 65536);
}

//
// ��¼mode����
//
void MakeScript::ModeCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();
	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	if (stricmp(p, "system") == 0) {
		mode_cmd_t *cp = NewCommand(mode_cmd_t, MODE_CMD);
		cp->mode = MODE_SYSTEM;
	}
	else if (stricmp(p, "scenario") == 0) {
		mode_cmd_t *cp = NewCommand(mode_cmd_t, MODE_CMD);
		cp->mode = MODE_SCENARIO;
	}
	else {
		Error("syntax error");
	}
}

//
// ��¼system����
//
void MakeScript::SystemCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();
	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	if (stricmp(p, "load") == 0) {
		NewCommand(single_cmd_t, SYS_LOAD_CMD);
	}
	else if (stricmp(p, "exit") == 0) {
		NewCommand(single_cmd_t, SYS_EXIT_CMD);
	}
	else if (stricmp(p, "clear") == 0) {
		NewCommand(single_cmd_t, SYS_CLEAR_CMD);
	}
	else {
		Error("syntax error");
	}
}

//
// ��¼stopm����
//
void MakeScript::StopmCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, STOPM_CMD);
}

//
// ��¼fadein����
//
void MakeScript::FadeInCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, FADEIN_CMD);
}

//
// ��¼fadeout����
//
void MakeScript::FadeOutCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, FADEOUT_CMD);
}

//
// ��¼wipein����
//
void MakeScript::WipeInCmd(Lexer &lexer)
{
	int value;
	bool isval = lexer.GetValue(&value);

	if (!isval || value <= 0 || value > 2 || lexer.GetString() != 0) {
		Error("syntax error (in wipein command)");
		return;
	}
	wipein_t *cp = NewCommand(wipein_t, WIPEIN_CMD);
	cp->pattern = value;
}

//
// ��¼wipeout����
//
void MakeScript::WipeOutCmd(Lexer &lexer)
{
	int value;
	bool isval = lexer.GetValue(&value);

	if (!isval || value <= 0 || value > 2 || lexer.GetString() != 0) {
		Error("syntax error (in wipeout command)");
		return;
	}
	wipeout_t *cp = NewCommand(wipeout_t, WIPEOUT_CMD);
	cp->pattern = value;
}

//
// ��¼cutin����
//
void MakeScript::CutInCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, CUTIN_CMD);
}

//
// ��¼cutout����
//
void MakeScript::CutOutCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, CUTOUT_CMD);
}

//
// ��¼whitein����
//
void MakeScript::WhiteInCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, WHITEIN_CMD);
}

//
// ��¼whiteout����
//
void MakeScript::WhiteOutCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, WHITEOUT_CMD);
}

//
// ��¼flash����
//
void MakeScript::FlashCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, FLASH_CMD);
}

//
// ��¼shake����
//
void MakeScript::ShakeCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, SHAKE_CMD);
}

//
// ��¼end����
//
void MakeScript::EndCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, END_CMD);
}

//
// �����ű�������
//
MakeScript::cmd_t MakeScript::ParseCommand(Lexer &lexer)
{
	const char *cmd = lexer.GetString(0);

	cmdmap::iterator	p = cmd_table.find(cmd);
	if (p != cmd_table.end())
		return p->second;

	// �Ƿ�Ϊ set, calc ��ʡ����ʽ
	if (lexer.NumToken() >= 3) {
		const char *p = lexer.GetString(1);
		lexer.GetType(0);			// ����ǰ��
		if (strcmp(p, "+") == 0 || strcmp(p, "-") == 0 || strcmp(p, "=") == 0) {
			return &MakeScript::SetCmd;
		}
	}
	Error("syntax error (command syntax)");
	return NULL;
}

//
// ���з���
//
void MakeScript::ParserString(const char *str)
{
	Lexer	lexer(str);

	if (lexer.NumToken() == 0)
		return;

	int	type = lexer.GetType();

	if (type == Lexer::IsLabel) {
		SetLabel(lexer);
	}
	else {
		cmd_t cmd = ParseCommand(lexer);
		if (cmd)
			(this->*cmd)(lexer);
	}
}

//
// ��ȡ�ű�ԭʼ����ת��
//
int MakeScript::ReadScript(const char *name)
{
	FileReader	Reader(name);

	if (!Reader) {
		ErrorMessage("file %s can't open.", name);
		return 1;
	}

	reader = &Reader;

	try {
		OpenValueTable();

		const char *str;
		while ((str = reader->GetString()) != 0) {
			ParserString(str);
		}
		NewCommand(single_cmd_t, END_CMD);

		LabelCheck();

		if (nerror != 0)
			Notice("I have %d error%s found.", nerror, (nerror == 1? "": "s"));

		if (nerror == 0 && add_value)
			CloseValueTable();
	}
	catch (char *error) {
		FatalError("%s", error);
	}
	catch (bad_alloc &) {
		FatalError("not enough memory");
	}

	return nerror;
}

//
// �洢�ű��ļ�
//
int MakeScript::WriteScript(const char *name)
{
	FILE *fp;

	if ((fp = fopen(name, "wb")) == NULL) {
		ErrorMessage("can't create %s.", name);
		return -1;
	}

	int		error = 0;
	if (fwrite(SCRIPT_MAGIC, sizeof(char), 8, fp) != 8
	 || fwrite(&ncommand, sizeof(long), 1, fp) != 1
	 || fwrite(command_buffer, sizeof(char), ncommand, fp) != (unsigned)ncommand) {
		ErrorMessage("write error in %s.", name);
		error = 1;
	}
	else {
		Notice("command %d bytes use", ncommand);
	}
	fclose(fp);

	return error;
}
