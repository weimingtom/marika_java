//
//	�X�N���v�g�R���o�[�^�A�e�X�g�p�_���v�o��
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//

#include <cstdio>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;
#include "ScriptTypes.h"

char	command_buffer[MAX_COMMAND];
long	ncommand;
int		position;

bool	ReadScript(const char *name)
{
	ifstream	in(name, ios_base::in | ios_base::binary);

	if (!in) {
		cerr << "can't open "<< name << endl;
		return false;
	}

	char	magic[8];
	if (!in.read(magic, sizeof(magic)) || memcmp(magic, SCRIPT_MAGIC, 8) != 0) {
		cerr << name << " not script file" << endl;
		return false;
	}

	if (!in.read((char *)&ncommand, sizeof(ncommand))
	 || !in.read((char *)command_buffer, ncommand)) {
		cerr << "read error in " << name << endl;
		return false;
	}
	return true;
}

class value_name {
  public:
	value_name(int no): valno(no) {}

	friend ostream& operator<<(ostream& out, const value_name& v);

  private:
	int	valno;
} ;

ostream& operator<<(ostream& out, const value_name& v)
{
	return out << "value[" << v.valno << ']';
}

class text {
  public:
	text(unsigned a): size(a) {}
	friend ostream& operator<<(ostream& out, const text& v);

  private:
	unsigned size;
} ;

ostream& operator<<(ostream& out, const text& v)
{
	if (v.size == 0)
		return out << "<null>";

	out << command_buffer + position;
	position += v.size;
	return out;
}

class multiline_text {
  public:
	multiline_text(unsigned a): size(a) {}
	friend ostream& operator<<(ostream& out, const multiline_text& v);

  private:
	unsigned size;
} ;

ostream& operator<<(ostream& out, const multiline_text& v)
{
	stringstream	sin(command_buffer + position);
	position += v.size;
	char	tmp[72];

	while (sin.getline(tmp, sizeof(tmp)) != 0) {
		out << '\t' << tmp << '\n';
	}
	return out << "\t.";
}

class value_or_const {
  public:
	value_or_const(int a, int f): addr(a), flag(f) {}
	friend ostream& operator<<(ostream& out, const value_or_const& v);

  private:
	int addr;
	int flag;
} ;

ostream& operator<<(ostream& out, const value_or_const& v)
{
	if (v.flag)
		return out << v.addr;
	return out << value_name(v.addr);
}

class cgpos {
  public:
	cgpos(int p): pos(p) {}
	friend ostream& operator<<(ostream& out, const cgpos& v);

  private:
	int pos;
} ;

ostream& operator<<(ostream& out, const cgpos& v)
{
	switch (v.pos) {
	  case POSITION_BACK:
		out << "back";
		break;

	  case POSITION_BACKONLY:
		out << "backonly";
		break;

	  case POSITION_CENTER:
		out << "center";
		break;

	  case POSITION_LEFT:
		out << "left";
		break;

	  case POSITION_RIGHT:
		out << "right";
		break;

	  case POSITION_OVERLAP:
		out << "overlap";
		break;

	  default:
		out << "<unknown>";
		break;
	}
	return out;
}

class update {
  public:
	update(int p): pos(p) {}
	friend ostream& operator<<(ostream& out, const update& v);

  private:
	int pos;
} ;

ostream& operator<<(ostream& out, const update& v)
{
	switch (v.pos) {
	  case UPDATE_NOW:
		out << "now";
		break;

	  case UPDATE_OVERLAP:
		out << "overlap";
		break;

	  case UPDATE_WIPE:
		out << "wipe";
		break;

	  default:
		out << "<unknown>";
		break;
	}
	return out;
}

class sysmode {
  public:
	sysmode(int m): mode(m) {}
	friend ostream& operator<<(ostream& out, const sysmode& v);

  private:
	int mode;
} ;

ostream& operator<<(ostream& out, const sysmode& v)
{
	switch (v.mode) {
	  case MODE_SYSTEM:
		out << "sysmode";
		break;

	  case MODE_SCENARIO:
		out << "scenario";
		break;

	  default:
		out << "<unknown>";
		break;
	}
	return out;
}

ostream& operator<<(ostream& out, const command_t& cmd)
{
	switch (cmd.common.type) {
	  case SET_VALUE_CMD:
		out << "set " << value_name(cmd.set.value_addr) << " = " << cmd.set.set_value;
		break;

	  case CALC_VALUE_CMD:
		out << "calc " << value_name(cmd.calc.value_addr) << " += " << cmd.calc.add_value;
		break;

	  case TEXT_CMD:
		out << "text" << '\n' << multiline_text(cmd.text.msg_len);
		break;

	  case CLEAR_TEXT_CMD:
		out << "clear text";
		break;

	  case MUSIC_CMD:
		out << "music " << cmd.music.number;
		break;

	  case STOPM_CMD:
		out << "stopm";
		break;

	  case SLEEP_CMD:
		out << "music " << cmd.sleep.time;
		break;

	  case GOTO_CMD:
		out << "goto " << cmd.goto_cmd.goto_label;
		break;

	  case IF_TRUE_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " == "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case IF_FALSE_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " != "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case IF_BIGGER_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " > "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case IF_SMALLER_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " < "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case IF_BIGGER_EQU_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " >= "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case IF_SMALLER_EQU_CMD:
		out << "if ("
			<< value_or_const(cmd.if_cmd.value1, cmd.if_cmd.flag & 1)
			<< " <= "
			<< value_or_const(cmd.if_cmd.value2, cmd.if_cmd.flag & 2)
			<< ") goto "
			<< cmd.if_cmd.goto_label;
		break;

	  case MENU_INIT_CMD:
		out << "menu init";
		break;

	  case MENU_ITEM_CMD:
		out << "menu item " << (int)cmd.menu_item.number << " "
			<< text(cmd.menu_item.label_len);
		break;

	  case MENU_CMD:
		out << "menu open " << value_name(cmd.menu.value_addr);
		break;

	  case EXEC_CMD:
		out << "exec " << text(cmd.exec_cmd.path_len);
		break;

	  case LOAD_CMD:
		out << "load " << cgpos(cmd.load.flag) << " " << text(cmd.load.path_len);
		break;

	  case UPDATE_CMD:
		out << "update " << update(cmd.update.flag);
		break;

	  case CUTIN_CMD:
		out << "cutin";
		break;

	  case CUTOUT_CMD:
		out << "cutout";
		break;

	  case FADEIN_CMD:
		out << "fadein";
		break;

	  case FADEOUT_CMD:
		out << "fadeout";
		break;

	  case WIPEIN_CMD:
		out << "wipein " << int(cmd.wipein.pattern);
		break;

	  case WIPEOUT_CMD:
		out << "wipeout " << int(cmd.wipein.pattern);
		break;

	  case WHITEIN_CMD:
		out << "whitein";
		break;

	  case WHITEOUT_CMD:
		out << "whiteout";
		break;

	  case CLEAR_CMD:
		out << "clear " << cgpos(cmd.clear.pos);
		break;

	  case SHAKE_CMD:
		out << "shake";
		break;

	  case FLASH_CMD:
		out << "flash";
		break;

	  case MODE_CMD:
		out << "mode " << sysmode(cmd.mode.mode);
		break;

	  case SYS_LOAD_CMD:
		out << "sys_load";
		break;

	  case SYS_EXIT_CMD:
		out << "sys_exit";
		break;

	  case SYS_CLEAR_CMD:
		out << "sys_clear";
		break;

	  case END_CMD:
		out << "end";
		break;

	  default:
		out << "error";
		break;
	}
	return out;
}

inline command_t *GetCommand()
{
	command_t *p = (command_t *)(command_buffer + position);
	position += p->common.size;
	return p;
}

int main(int ac, char *av[])
{
	if (ac != 2) {
		cerr << "usage: dumpscript filename " << endl;
		return 1;
	}
	if (!ReadScript(av[1]))
		return 1;

	position = 0;
	while (position < ncommand) {
		cout << setw(5) << position;
		command_t *p = GetCommand();
		cout << " : " << *p << endl;
	}
	return 0;
}
