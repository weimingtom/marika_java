//
// ����
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__params_h
#define	__params_h

#include "MkScript/ScriptTypes.h"

#define	PARAMS_MAX_SAVE		10
#define	PARAMS_MAX_VALUES	MAX_VALUES

enum	{
	SHOWCG_BLACKNESS,
	SHOWCG_IMAGE,
	SHOWCG_WHITENESS,
} ;

//
// ��Ϸ������
//
struct CParams	{
	unsigned char	save_month;
	unsigned char	save_date;
	unsigned char	save_hour;
	unsigned char	save_minute;
	unsigned long	script_pos;
	char			last_script[16];
	char			last_bg[16];
	char			last_center[16];
	char			last_left[16];
	char			last_right[16];
	char			last_overlap[16];
	unsigned long	last_bgm;
	unsigned long	show_flag;
	long			value_tab[PARAMS_MAX_VALUES];

  public:
	void Clear();
	void ClearBackCG();
	void ClearLeftCG();
	void ClearRightCG();
	void ClearCenterCG();
	void ClearOverlapCG();
	void SetBackCG(const char *file);
	void SetLeftCG(const char *file);
	void SetRightCG(const char *file);
	void SetCenterCG(const char *file);
	void SetOverlapCG(const char *file);
	void SetShowFlag();
	void ResetShowFlag(BOOL white=FALSE);
	BOOL Load(int no);
	BOOL Save(int no);
} ;

// Inline��Ա����

// ��ȥ����CG
inline void CParams::ClearBackCG()
{
	last_bg[0] = 0;
}

// ��ȥ����ص�CG
inline void CParams::ClearLeftCG()
{
	last_left[0] = 0;
	last_center[0] = 0;
	last_overlap[0] = 0;
}

// ��ȥ�Ҳ��ص�CG
inline void CParams::ClearRightCG()
{
	last_right[0] = 0;
	last_center[0] = 0;
	last_overlap[0] = 0;
}

// ��ȥ�м��ص�CG
inline void CParams::ClearCenterCG()
{
	last_left[0] = 0;
	last_right[0] = 0;
	last_center[0] = 0;
	last_overlap[0] = 0;
}

// ��ȥ�ص�CG
inline void CParams::ClearOverlapCG()
{
	last_left[0] = 0;
	last_right[0] = 0;
	last_center[0] = 0;
	last_overlap[0] = 0;
}

// �趨����CG
inline void CParams::SetBackCG(const char *file)
{
	strcpy(last_bg, file);
}

// �趨����ص�CG
inline void CParams::SetLeftCG(const char *file)
{
	last_center[0] = 0;
	last_overlap[0] = 0;
	strcpy(last_left, file);
}

// �趨�Ҳ��ص�CG
inline void CParams::SetRightCG(const char *file)
{
	last_center[0] = 0;
	last_overlap[0] = 0;
	strcpy(last_right, file);
}

// �趨�м��ص�CG
inline void CParams::SetCenterCG(const char *file)
{
	ClearOverlapCG();
	strcpy(last_center, file);
}

// �趨�ص�CG
inline void CParams::SetOverlapCG(const char *file)
{
	ClearOverlapCG();
	strcpy(last_overlap, file);
}

// �趨��ʾ���
inline void CParams::SetShowFlag()
{
	show_flag = SHOWCG_IMAGE;
}

// ��ȥ��ʾ���
inline void CParams::ResetShowFlag(BOOL white)
{
	show_flag = white? SHOWCG_WHITENESS: SHOWCG_BLACKNESS;
}

#endif
