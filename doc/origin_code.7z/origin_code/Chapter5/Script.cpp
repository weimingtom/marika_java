//
// ִ��Script
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "stdafx.h"
#include <stdlib.h>
#include "MainWin.h"
#include "File.h"
#include "Misc.h"
#include "Script.h"

//
// ������Ϣ�ĸ�ʽ
//
char *__cdecl CScriptAction::Format(const char *fmt, ...)
{
	static	char	tmp[256];

	va_list	args;
	va_start(args, fmt);
	vsprintf(tmp, fmt, args);
	va_end(args);

	return tmp;
}

//
// ��ʼ��
//
void CScriptAction::Initialize(CMainWin *parent, unsigned param1, unsigned param2)
{
	CAction::Initialize(parent, param1, param2);

	status = Continue;
	Pressed = FALSE;
	MenuSelect = -1;
	PlayMode = param1;

	Params.Clear();

	delete[] script_buffer;
	script_buffer = 0;
}

//
// ��ͣ
//
void CScriptAction::Pause()
{
	switch (status) {
	  case WaitMenuDone:	// �ȴ��˵�
		if (MenuSelect >= 0) {
			Parent->SelectMenu(MenuSelect, false);
			MenuSelect = -1;
		}
		break;
	}
}

//
// �����ͣ
//
void CScriptAction::Resume()
{
	switch (status) {
	  case WaitMenuDone:	// �ȴ��˵�
		{
			CPoint	point;
			GetCursorPos(&point);
			Parent->ScreenToClient(&point);
			MenuSelect = Parent->GetMenuSelect(point);
			if (MenuSelect >= 0)
				Parent->SelectMenu(MenuSelect, true);
		}
		break;
	}
}

//
// �����������Ĵ���
//
void CScriptAction::LButtonDown(UINT modKeys, CPoint point)
{
	switch (status) {
	  case WaitMenuDone:	// �ȴ��˵�
		Pressed = TRUE;
		break;
	}
}

//
// �ſ�����Ĵ���
//
void CScriptAction::LButtonUp(UINT modKeys, CPoint point)
{
	switch (status) {
	  case WaitKeyPressed:	// �ȴ�����
		Parent->HideWaitMark();
		status = Continue;
		break;

	  case WaitMenuDone:	// �ȴ��˵�
		if (Pressed) {
			Pressed = FALSE;
			MouseMove(modKeys, point);

			if (MenuSelect >= 0) {
				SetValue(MenuAnserAddr, Parent->GetMenuAnser(MenuSelect));
				Parent->HideMenuWindow();
				status = Continue;
			}
			MenuSelect = -1;
		}
		break;
	}
}

//
// ��������Ҽ�ʱ�Ĵ���
//
void CScriptAction::RButtonDown(UINT modKeys, CPoint point)
{
	switch (status) {
	  case WaitKeyPressed:	// �ȴ�����
		Parent->FlipMessageWindow();
		break;
	}
}

//
// �ƶ��Ҽ�ʱ�Ĵ���
//
void CScriptAction::MouseMove(UINT modKeys, CPoint point)
{
	switch (status) {
	  case WaitMenuDone:	// �ȴ��˵�
		{
			int sel = Parent->GetMenuSelect(point);
			if (sel != MenuSelect) {
				Parent->SelectMenu(MenuSelect, false);
				MenuSelect = sel;
				Parent->SelectMenu(MenuSelect, true);
			}
		}
		break;
	}
}

//
// ���̰�������ʱ�Ĵ���
//
void CScriptAction::KeyDown(UINT key)
{
	switch (key) {
	  case VK_RETURN:
	  case VK_SPACE:
		switch (status) {
		  case WaitKeyPressed:	// �ȴ�����
			Parent->HideWaitMark();
			status = Continue;
			break;

		  case WaitMenuDone:	// �ȴ��˵�
			if (MenuSelect >= 0) {
				SetValue(MenuAnserAddr, Parent->GetMenuAnser(MenuSelect));
				Parent->HideMenuWindow();
				status = Continue;
				MenuSelect = -1;
			}
			break;
		}
		break;

	  case VK_ESCAPE:
		switch (status) {
		  case WaitKeyPressed:	// �ȴ�����
			Parent->FlipMessageWindow();
			break;
		}
		break;

	  case VK_UP:
		if (status == WaitMenuDone) {	// �ȴ��˵�
			Parent->SelectMenu(MenuSelect, false);
			MenuSelect--;
			if (MenuSelect < 0)
				MenuSelect = Parent->GetMenuItemCount() - 1;
			Parent->SelectMenu(MenuSelect, true);
		}
		break;

	  case VK_DOWN:
		if (status == WaitMenuDone) {	// �ȴ��˵�
			Parent->SelectMenu(MenuSelect, false);
			MenuSelect++;
			if (MenuSelect >= Parent->GetMenuItemCount())
				MenuSelect = 0;
			Parent->SelectMenu(MenuSelect, true);
		}
		break;
	}
}

//
// IDLE����
//
BOOL CScriptAction::IdleAction()
{
	if (status == Continue) {				// ��������ִ��
		do {
			status = Step();				// ִ��1��
		} while (status == Continue) ;		// ������

		if (status == BreakGame) {			// ����
			Abort();
		}
		else if (status == WaitNextIdle) {	// �ȵ���һ��IDLE�ٽ���
			status = Continue;				// ��Ϊ����
			return TRUE;
		}
		else if (status == WaitWipeDone) {	// �ȴ���Ч����
			return TRUE;					// IDLE����
		}
	}
	return FALSE;
}

//
// ��ʱ���Ĵ���
//
void CScriptAction::TimedOut(int timerId)
{
	switch (timerId) {
	  case CMainWin::TimerSleep:	// �ȴ�TimeOut
		if (status == WaitTimeOut)
			status = Continue;
		break;
	}
}

//
// Wipe����ʱ�Ĵ���
//
void CScriptAction::WipeDone()
{
	if (status == WaitWipeDone)		// �ȴ���Ч����
		status = Continue;
}

//
// Wave�������ʱ�Ĵ���
//
void CScriptAction::WaveDone()
{
	if (status == WaitWaveDone)		// �ȴ�����WAVE����
		status = Continue;
}

//
// Scriptִ�еĽ���
//
void CScriptAction::Abort()
{
	if (status == WaitMenuDone)				// ����ǵȴ��˵�״̬
		Parent->HideMenuWindow();			// �رղ˵�
	Parent->HideMessageWindow();			// �ر����ֿ�

	status = BreakGame;
	delete[] script_buffer;					// �ͷŽű�
	script_buffer = 0;

	Parent->SetAction(CMainWin::ActionScriptDone);
}

//
// ��ȡ�ű���
//
int CScriptAction::LoadFile(const char *name)
{
	char	path[_MAX_PATH];
	sprintf(path, SCRIPTPATH "%s.scr", name);

	delete[] script_buffer;
	script_buffer = 0;

	CFile	file(path);

	if (!file)
		return FileCannotOpen;

	int		length = file.GetFileSize();

	if ((script_buffer = new char [length]) == 0)
		return NotEnoughMemory;

	if (file.Read(script_buffer, length) != length)
		return FileCannotRead;

	return FileNoError;
}

//
// ���ļ���ȡ�ű����洢�ű��Ŀռ�Ҳ������������
//
BOOL CScriptAction::Load(const char *name)
{
	strncpy(Params.last_script, name, 16);

	switch (LoadFile(name)) {
	  case FileCannotOpen:
		Parent->MessageBox(Format("�ű� [%s] �޷�������", name));
		return FALSE;

	  case NotEnoughMemory:
		Parent->MessageBox(Format("�ڴ治��, �޷���ȡ�ű�[%s]��", name));
		return FALSE;

	  case FileCannotRead:
		Parent->MessageBox(Format("�޷���ȡ�ű���[%s]", name));
		return FALSE;
	}

	script_t *header = (script_t *)script_buffer;

	if (memcmp(header->magic, SCRIPT_MAGIC, 8) != 0) {
		Parent->MessageBox(Format("û�нű����ݡ�[%s]", name));
		return FALSE;
	}

	current.ncommand = header->ncommand;
	current.commands = (byte_t *)(header + 1);

	position = 0;

	return TRUE;
}

//
// �趨��ȡ����״̬
//
BOOL CScriptAction::Setup(CParams &param)
{
	Params = param;
	position = Params.script_pos;

	if (current.ncommand < position) {
		Parent->MessageBox("��ȡ�������쳣��");
		return FALSE;
	}

	if (param.last_bgm)
		Parent->StartMusic(param.last_bgm);

	switch (param.show_flag) {
	  case SHOWCG_IMAGE:
		if (param.last_bg[0])
			LoadGraphic(param.last_bg, POSITION_BACK);
		if (param.last_overlap[0]) {
			LoadGraphic(param.last_overlap, POSITION_OVERLAP);
		}
		else if (param.last_center[0]) {
			LoadGraphic(param.last_center, POSITION_CENTER);
		}
		else {
			if (param.last_left[0])
				LoadGraphic(param.last_left, POSITION_LEFT);
			if (param.last_right[0])
				LoadGraphic(param.last_right, POSITION_RIGHT);
		}
		status = WipeIn();
		break;

	  case SHOWCG_BLACKNESS:
		CutOut();
		status = Continue;
		break;

	  case SHOWCG_WHITENESS:
		CutOut(TRUE);
		status = Continue;
		break;
	}
	return TRUE;
}

//
// ִ�нű���1��
//
int CScriptAction::Step()
{
	ASSERT(script_buffer);

	int last_pos = position;
	command_t *cmd = GetCommand();

	switch (cmd->common.type) {
	  case SET_VALUE_CMD:
		SetValue(cmd->set.value_addr, cmd->set.set_value);
		break;

	  case CALC_VALUE_CMD:
		CalcValue(cmd->calc.value_addr, cmd->calc.add_value);
		break;

	  case TEXT_CMD:
		Params.script_pos = last_pos;
		Parent->WriteMessage(GetString(cmd->text.msg_len));
		return WaitKeyPressed;

	  case CLEAR_TEXT_CMD:
		Parent->ClearMessage();
		return WaitNextIdle;

	  case MUSIC_CMD:
		Params.last_bgm = cmd->music.number;
		Parent->StartMusic(cmd->music.number);
		break;

	  case STOPM_CMD:
		Params.last_bgm = 0;
		Parent->StopMusic();
		break;

	  case SOUND_CMD:
		if (Parent->StartWave(GetString(cmd->sound.path_len)))
			return WaitWaveDone;
		return Continue;

	  case SLEEP_CMD:
		Parent->SetTimer(CMainWin::TimerSleep, cmd->sleep.time * 1000);
		return WaitTimeOut;

	  case GOTO_CMD:
		GotoCommand(cmd->goto_cmd.goto_label);
		break;

	  case IF_TRUE_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) == GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case IF_FALSE_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) != GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case IF_BIGGER_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) > GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case IF_SMALLER_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) < GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case IF_BIGGER_EQU_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) >= GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case IF_SMALLER_EQU_CMD:
		if (GetValue(cmd->if_cmd.value1, cmd->if_cmd.flag & 1) <= GetValue(cmd->if_cmd.value2, cmd->if_cmd.flag & 2))
			GotoCommand(cmd->if_cmd.goto_label);
		break;

	  case MENU_INIT_CMD:
		Params.script_pos = last_pos;
		Parent->ClearMenuItemCount();
		break;

	  case MENU_ITEM_CMD:
		Parent->SetMenuItem(GetString(cmd->menu_item.label_len), cmd->menu_item.number);
		break;

	  case MENU_CMD:
		MenuSelect = -1;
		MenuAnserAddr = cmd->menu.value_addr;
		Parent->OpenMenu();
		return WaitMenuDone;

	  case EXEC_CMD:
		if (!Load(GetString(cmd->exec_cmd.path_len)))
			return BreakGame;
		PlayMode = MODE_SCENARIO;
		break;

	  case LOAD_CMD:
		return LoadGraphic(GetString(cmd->load.path_len), cmd->load.flag);

	  case UPDATE_CMD:
		return UpdateImage(cmd->update.flag);

	  case CLEAR_CMD:
		return Clear(cmd->clear.pos);

	  case CUTIN_CMD:
		return CutIn();

	  case CUTOUT_CMD:
		return CutOut();

	  case FADEIN_CMD:
		return FadeIn();

	  case FADEOUT_CMD:
		return FadeOut();

	  case WIPEIN_CMD:
		return WipeIn(cmd->wipein.pattern);

	  case WIPEOUT_CMD:
		return WipeOut(cmd->wipeout.pattern);

	  case WHITEIN_CMD:
		return WhiteIn();

	  case WHITEOUT_CMD:
		return WhiteOut();

	  case SHAKE_CMD:
		Parent->Shake();
		return WaitWipeDone;

	  case FLASH_CMD:
		Parent->Flash();
		return WaitWipeDone;

	  case MODE_CMD:
		PlayMode = cmd->mode.mode;
		break;

	  case SYS_LOAD_CMD:
		Parent->SetAction(CMainWin::ActionGameLoad);
		return WaitNextIdle;

	  case SYS_EXIT_CMD:
		Parent->SendMessage(WM_CLOSE);
		return WaitNextIdle;

	  case SYS_CLEAR_CMD:
		ClearAllValues();
		break;

	  case END_CMD:
		return BreakGame;

	  default:
		ASSERT(false);
		break;
	}
	return Continue;
}

//
// ��ȡͼƬ��CG
//
int CScriptAction::LoadGraphic(const char *file, int pos)
{
	BOOL	result = FALSE;
	switch (pos) {
	  case POSITION_BACK:			// ����
		Params.ClearOverlapCG();
		Parent->ClearOverlap();
		// no break

	  case POSITION_BACKONLY:		// ֻ�б���
		Params.SetBackCG(file);
		result = Parent->LoadImageBack(file);
		break;

	  case POSITION_CENTER:			// �м�
		Params.SetCenterCG(file);
		result = Parent->LoadImageCenter(file);
		break;

	  case POSITION_LEFT:			// ��
		Params.SetLeftCG(file);
		result = Parent->LoadImageLeft(file);
		break;

	  case POSITION_RIGHT:			// ��
		Params.SetRightCG(file);
		result = Parent->LoadImageRight(file);
		break;

	  case POSITION_OVERLAP:		// �ص�
		Params.SetOverlapCG(file);
		result = Parent->LoadImageOverlap(file);
		break;
	}

	if (!result) {
		Parent->MessageBox(Format("�ļ��޷���ȡ��[%s]", file));
		if (PlayMode == MODE_SYSTEM)
			Parent->SendMessage(WM_CLOSE);
		return BreakGame;
	}
	return Continue;
}

//
// ���ͼƬCG
//
int CScriptAction::Clear(int pos)
{
	switch (pos) {
	  case POSITION_BACK:			// ����
		Params.ClearOverlapCG();
		Parent->ClearOverlap();
		// no break

	  case POSITION_BACKONLY:		// ֻ�б���
		Params.ClearBackCG();
		Parent->ClearBack();
		break;

	  case POSITION_CENTER:			// �м�
		Params.ClearCenterCG();
		Parent->ClearCenter();
		break;

	  case POSITION_LEFT:			// ��
		Params.ClearLeftCG();
		Parent->ClearLeft();
		break;

	  case POSITION_RIGHT:			// ��
		Params.ClearRightCG();
		Parent->ClearRight();
		break;

	  case POSITION_OVERLAP:		// �ص�
		Params.ClearOverlapCG();
		Parent->ClearOverlap();
		break;
	}
	return Continue;
}

//
// ������ʾ
//
int CScriptAction::UpdateImage(int flag)
{
	Params.SetShowFlag();

	CRect	rect = Parent->GetInvalidRect();
	if (rect.IsRectEmpty())
		return Continue;

	switch (flag) {
	  case UPDATE_NOW:
		Parent->CutIn(rect);
		return WaitNextIdle;

	  case UPDATE_OVERLAP:
		Parent->MixFade(rect);
		break;

	  case UPDATE_WIPE:
		Parent->WipeIn(rect);
		break;
	}
	return WaitWipeDone;
}

//
// ����
//
int CScriptAction::FadeIn()
{
	Params.SetShowFlag();
	Parent->FadeIn();
	return WaitWipeDone;
}

//
// ����
//
int CScriptAction::FadeOut()
{
	Params.ResetShowFlag();
	Parent->FadeOut();
	return WaitWipeDone;
}

//
// ����
//
int CScriptAction::CutIn()
{
	Params.SetShowFlag();
	Parent->CutIn();
	return WaitNextIdle;
}

//
// �г�
//
int CScriptAction::CutOut(BOOL white)
{
	Params.ResetShowFlag(white);
	Parent->CutOut(white);
	return WaitNextIdle;
}

//
// ת��
//
int CScriptAction::WipeIn(int pattern)
{
	Params.SetShowFlag();
	Parent->WipeIn(pattern);
	return WaitWipeDone;
}

//
// ת��
//
int CScriptAction::WipeOut(int pattern)
{
	Params.ResetShowFlag();
	Parent->WipeOut(pattern);
	return WaitWipeDone;
}

//
// ����(����)
//
int CScriptAction::WhiteIn()
{
	Params.SetShowFlag();
	Parent->WhiteIn();
	return WaitWipeDone;
}

//
// ����(�׳�)
//
int CScriptAction::WhiteOut()
{
	Params.ResetShowFlag(TRUE);
	Parent->WhiteOut();
	return WaitWipeDone;
}
