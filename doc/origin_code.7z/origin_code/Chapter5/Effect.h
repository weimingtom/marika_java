//
// ������Ч
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__effect_h__
#define	__effect_h__

class CMainWin;
class CDrawImage;
class CImage;

//
// Effect��
//
class CViewEffect {
  public:
	CViewEffect(CMainWin *win, unsigned step, CDrawImage *dst, CImage *src=0,
		const CRect &rect=CRect(0, 0, WindowWidth, WindowHeight));

	bool Step(unsigned time);

	void *operator new(size_t size);
	void operator delete(void *ptr);

  protected:
	virtual bool Step() = 0;

  protected:
	CMainWin   *Window;
	CDrawImage *Dst;
	CImage     *Src;

	UINT		TimeBase;
	int			EffectCnt;
	CRect		EffectRect;
	UINT		lastTime;
} ;

// Inline��Ա����

inline CViewEffect::CViewEffect(CMainWin *win, unsigned step, CDrawImage *dst, CImage *src, const CRect &rect)
	:Window(win), Dst(dst), Src(src), TimeBase(step), EffectRect(rect), EffectCnt(0), lastTime(0)
{
}

inline bool CViewEffect::Step(unsigned time)
{
	if (TimeBase <= time - lastTime) {
		lastTime = time;
		return Step();
	}
	return true;
}

//
// ��Ч-Effect
//
//	CViewEffect���̳�
//
//	step(��Ա���� TimeBase)ָ�����ms��λ
//	
//

//
// ת��
//
class EffectWipeIn: public CViewEffect {
  public:
	EffectWipeIn(CMainWin *win, CDrawImage *dst, CImage *src, const CRect &rect)
		:CViewEffect(win, 1000 / 8, dst, src, rect) {}

  protected:
	bool Step();
} ;

//
// ת��
//
class EffectWipeOut: public CViewEffect {
  public:
	EffectWipeOut(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 8, dst, src) {}

  protected:
	bool Step();
} ;

//
// ת��2
//
class EffectWipeIn2: public CViewEffect {
  public:
	EffectWipeIn2(CMainWin *win, CDrawImage *dst, CImage *src, const CRect &rect)
		:CViewEffect(win, 1000 / 20, dst, src, rect) {}

  protected:
	bool Step();
} ;

//
// ת��2
//
class EffectWipeOut2: public CViewEffect {
  public:
	EffectWipeOut2(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 20, dst, src) {}

  protected:
	bool Step();
} ;

//
// ����
//
class EffectFadeIn: public CViewEffect {
  public:
	EffectFadeIn(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 16, dst, src) {}

  protected:
	bool Step();
} ;

//
// ����
//
class EffectFadeOut: public CViewEffect {
  public:
	EffectFadeOut(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 16, dst, src) {}

  protected:
	bool Step();
} ;

//
// ����
//
class EffectWhiteIn: public CViewEffect {
  public:
	EffectWhiteIn(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 16, dst, src) {}

  protected:
	bool Step();
} ;

//
// �׳�
//
class EffectWhiteOut: public CViewEffect {
  public:
	EffectWhiteOut(CMainWin *win, CDrawImage *dst, CImage *src)
		:CViewEffect(win, 1000 / 16, dst, src) {}

  protected:
	bool Step();
} ;

//
// �����ϳ�
//
class EffectMixFade: public CViewEffect {
  public:
	EffectMixFade(CMainWin *win, CDrawImage *dst, CImage *src, const CRect &rect)
		:CViewEffect(win, 1000 / 8, dst, src, rect) {}

  protected:
	bool Step();
} ;

//
// ����
//
class EffectFlash: public CViewEffect {
  public:
	EffectFlash(CMainWin *win, CDrawImage *dst)
		:CViewEffect(win, 1000 / 24, dst) {}

  protected:
	bool Step();
} ;

//
// ҡ��
//
class EffectShake: public CViewEffect {
  public:
	EffectShake(CMainWin *win, CDrawImage *dst)
		:CViewEffect(win, 1000 / 24, dst) {}

  protected:
	bool Step();
} ;

#endif
