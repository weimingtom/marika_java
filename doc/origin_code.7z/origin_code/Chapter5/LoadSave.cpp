//
// װ�롤�洢����
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "stdafx.h"
#include "MainWin.h"
#include "LoadSave.h"

//
// ��ʼ��
//
void CGameLoadSaveAction::Initialize(CMainWin *parent, unsigned param1, unsigned param2)
{
	CAction::Initialize(parent, param1, param2);

	Selection = -1;
	Pressed = FALSE;
	CancelPressed = FALSE;
	Flags = 0;
}

//
// ����������ʱ�Ĵ���
//
void CGameLoadSaveAction::LButtonDown(UINT modKeys, CPoint point)
{
	Pressed = TRUE;
}

//
// �ſ�������ʱ�Ĵ���
//
void CGameLoadSaveAction::LButtonUp(UINT modKeys, CPoint point)
{
	Pressed = FALSE;
	if (Selection >= 0)
		DoLoadSave();
}

//
// ��������Ҽ�ʱ�Ĵ���
//
void CGameLoadSaveAction::RButtonDown(UINT modKeys, CPoint point)
{
	CancelPressed = TRUE;
}

//
// �ſ�����Ҽ�ʱ�Ĵ���
//
void CGameLoadSaveAction::RButtonUp(UINT modKeys, CPoint point)
{
	if (CancelPressed)
		Parent->CancelLoadSaveMenu(Flags);
}

//
// �ƶ����ʱ�Ĵ���
//
void CGameLoadSaveAction::MouseMove(UINT modKeys, CPoint point)
{
	int sel = Parent->GetLoadSaveSelect(point);
	if (sel != Selection) {
		Parent->SelectLoadSaveMenu(Selection, false);
		Selection = sel;
		Parent->SelectLoadSaveMenu(Selection, true);
	}
}

//
// ���¼��̰�ťʱ�Ĵ���
//
void CGameLoadSaveAction::KeyDown(UINT key)
{
	switch (key) {
	  case VK_RETURN:
	  case VK_SPACE:	// ִ��װ��洢
		if (Selection >= 0)
			DoLoadSave();
		break;

	  case VK_ESCAPE:	// ȡ��
		Parent->CancelLoadSaveMenu(Flags);
		break;

	  case VK_UP:		// ѡǰһ��
		{
			int		sel = Parent->PrevLoadSaveSelect(Selection);
			if (sel != Selection) {
				Parent->SelectLoadSaveMenu(Selection, false);
				Selection = sel;
				Parent->SelectLoadSaveMenu(Selection, true);
			}
		}
		break;

	  case VK_DOWN:		// ѡ��һ��
		{
			int		sel = Parent->NextLoadSaveSelect(Selection);
			if (sel != Selection) {
				Parent->SelectLoadSaveMenu(Selection, false);
				Selection = sel;
				Parent->SelectLoadSaveMenu(Selection, true);
			}
		}
		break;
	}
}

//
// Timer�Ĵ���
//
void CGameLoadSaveAction::TimedOut(int timerId)
{
	switch (timerId) {
	  case CMainWin::TimerSleep:
		Flags |= CMainWin::IS_TIMEDOUT;
		break;
	}
}

//
// װ����Ϸ
//
void CGameLoadAction::DoLoadSave()
{
	Parent->LoadGame(Selection);
}

//
// �洢��Ϸ
//
void CGameSaveAction::DoLoadSave()
{
	Parent->SaveGame(Selection, Flags);
}
