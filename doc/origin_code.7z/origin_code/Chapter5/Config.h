//
// Script player ��̬�趨 
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__config_h__
#define	__config_h__

#define	CompanyName			"HyperWorks"
#define	ApplicationName		"ScriptPlayer"
#define	ApplicationTitle	"Script player"

#define	WindowWidth		640
#define	WindowHeight	480

#define	CGPATH			"cgdata/"
#define	SCRIPTPATH		"data/"
#define	WAVEPATH		"wave/"

#define	MessageFont		16
#define	MessageStyle	FW_BOLD
#define	MessageWidth	72
#define	MessageLine		4

#endif
