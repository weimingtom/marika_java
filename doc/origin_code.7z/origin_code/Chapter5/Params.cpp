//
// ����
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "stdafx.h"
#include <time.h>
#include <stdio.h>
#include <ctype.h>
#include "Params.h"
#include "File.h"
#include "Misc.h"

#define	HEADER_ID	"DATA"

//
// װ�����ݵ�
//
static BOOL LoadData(const char *path, void *buf, int length)
{
	CFile	file(path, CFile::read);

	if (!file)
		return FALSE;

	if (file.Read(buf, length) != length)
		return FALSE;
	return TRUE;
}

//
// �洢���ݵ�
//
static BOOL SaveData(const char *path, const void *buf, int length)
{
	CFile	file(path, CFile::write);

	if (!file)
		return FALSE;

	if (file.Write(buf, length) != length)
		return FALSE;
	return TRUE;
}

//
// �����ĳ�ʼ��
//
void CParams::Clear()
{
	memset(this, 0, sizeof(CParams));
}

//
// ��ȡ����
//
BOOL CParams::Load(int no)
{
	char	file[16];
	sprintf(file, "SAVE%04d.DAT", no + 1);

	unsigned char	buf[sizeof(CParams) + 4];

	if (!LoadData(file, buf, sizeof(buf)))
		return FALSE;

	if (memcmp(buf, HEADER_ID, 4) != 0)
		return FALSE;

	memcpy(this, buf + 4, sizeof(CParams));
	return TRUE;
}

//
// �洢����
//
BOOL CParams::Save(int no)
{
	SYSTEMTIME	time;
	GetLocalTime(&time);

	save_month = (unsigned char)time.wMonth;
	save_date = (unsigned char)time.wDay;
	save_hour = (unsigned char)time.wHour;
	save_minute = (unsigned char)time.wMinute;

	unsigned char	buf[sizeof(CParams) + 4];

	memset(buf, 0, sizeof(buf));
	memcpy(buf, HEADER_ID, 4);
	memcpy(buf + 4, this, sizeof(CParams));

	char	file[16];
	sprintf(file, "SAVE%04d.DAT", no + 1);

	if (!SaveData(file, buf, sizeof(buf)))
		return FALSE;
	return TRUE;
}
