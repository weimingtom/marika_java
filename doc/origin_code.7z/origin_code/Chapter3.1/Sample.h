#ifndef	__Sample_h__
#define	__Sample_h__

#include "Application.h"
#include "Window.h"

//
//  ������
//
class CSampleWin: public CWindow {
  public:
	void OnCommand(UINT notifyCode, UINT id, HWND ctrl);

  protected:
	void OnPaint();
} ;

//
//  Ӧ�ó�����
//
class CSampleApp: public CWinApp {
  public:
	BOOL InitInstance();

  protected:
	CSampleWin	MainWin;
} ;

#endif
