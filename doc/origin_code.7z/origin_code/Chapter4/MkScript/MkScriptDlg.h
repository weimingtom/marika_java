// MkScriptDlg.h : header file
//

#if !defined(AFX_MKSCRIPTDLG_H__1E3B514B_DEE2_4509_85DC_28C8F3EAAC25__INCLUDED_)
#define AFX_MKSCRIPTDLG_H__1E3B514B_DEE2_4509_85DC_28C8F3EAAC25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMkScriptDlg dialog

class CMkScriptDlg : public CDialog
{
// Construction
public:
	CMkScriptDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMkScriptDlg)
	enum { IDD = IDD_MKSCRIPT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMkScriptDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

public:
	void MakeScript(const char *filename);
	void AddText(const char *text);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMkScriptDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	afx_msg void OnDropFiles(HDROP hDropInfo);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MKSCRIPTDLG_H__1E3B514B_DEE2_4509_85DC_28C8F3EAAC25__INCLUDED_)
