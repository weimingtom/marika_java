// MkScriptDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MkScript.h"
#include "MkScriptDlg.h"
#include "MakeScript.h"
#include "Reader.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMkScriptDlg dialog

CMkScriptDlg::CMkScriptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMkScriptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMkScriptDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMkScriptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMkScriptDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMkScriptDlg, CDialog)
	//{{AFX_MSG_MAP(CMkScriptDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DROPFILES()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMkScriptDlg message handlers

BOOL CMkScriptDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	DragAcceptFiles(TRUE);			// ����Drag & Drop(���)�ʧ@

	for (int i=1; i < __argc; i++) {
		MakeScript(__argv[i]);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMkScriptDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMkScriptDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMkScriptDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// ֧���Ϸ�
//
void CMkScriptDlg::OnDropFiles(HDROP hDropInfo)
{
	SetActiveWindow();		// ʹ����
	UINT nFiles = ::DragQueryFile(hDropInfo, (UINT)-1, NULL, 0);

	for (UINT i = 0; i < nFiles; i++) {
		char filename[_MAX_PATH];
		::DragQueryFile(hDropInfo, i, filename, _MAX_PATH);
		MakeScript(filename);
	}
	::DragFinish(hDropInfo);
}

void CMkScriptDlg::AddText(const char *text)
{
	int length = SendDlgItemMessage(IDC_MESSAGE, WM_GETTEXTLENGTH);
	SendDlgItemMessage(IDC_MESSAGE, EM_SETSEL, (WPARAM)length, (LPARAM)-1);
	SendDlgItemMessage(IDC_MESSAGE, EM_REPLACESEL, FALSE, (LPARAM)text);
	SendDlgItemMessage(IDC_MESSAGE, EM_REPLACESEL, FALSE, (LPARAM)"\r\n");
}

class CWinMakeScript: public MakeScript {
  public:
	CWinMakeScript(CMkScriptDlg *wnd): Wnd(wnd) {}

  protected:
	virtual void OutputMessage(int code, const char *str) const;
	virtual const char *GetValueFile() const;

  private:
	CMkScriptDlg *Wnd;
} ;

//
// �����������ƵĲο�
//
const char *CWinMakeScript::GetValueFile() const
{
	if (reader == 0)
		return "value.tbl";

	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	_splitpath(reader->GetFileName(), drive, dir, fname, ext);

	static char path_buffer[_MAX_PATH];
	_makepath(path_buffer, drive, dir, "value", "tbl");

	return path_buffer;
}

//
// ��Ϣ���
//
void CWinMakeScript::OutputMessage(int code, const char *str) const
{
	Wnd->AddText(str);
}

void CMkScriptDlg::MakeScript(const char *filename)
{
	try {
		CWinMakeScript	converter(this);

		char str[_MAX_PATH + 100];
		sprintf(str, ">> convert %s", filename);
		AddText(str);

		if (converter.ReadScript(filename) == 0) {
			char	path[_MAX_PATH];
			strcpy(path, filename);
			char *p = strrchr(path, '.');
			if (p != 0)
				*p = '\0';
			strcat(path, ".scr");
			converter.WriteScript(path);
		}
	}
	catch (bad_alloc &) {
		AddText("not enough memory");
	}
	catch (...) {
		AddText("unknown error");
	}
}
