//
// Script converter
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#include "StdAfx.h"
#include "MakeScript.h"
#include "Reader.h"
#include "Lexer.h"

//
// �ع��캯��
//
MakeScript::MakeScript()
{
	reader = 0;
	nerror = 0;

	ncommand = 0;

	add_value = false;

	if ((command_buffer = new char[MAX_COMMAND]) == 0)
		throw bad_alloc();
}

//
// ��������
//
MakeScript::~MakeScript()
{
	delete[] command_buffer;
}

//
// ���������������
//
bool MakeScript::OpenValueTable()
{
	ifstream	fin(GetValueFile());

	if (!fin)
		return false;

	string	str;
	while ((fin >> str) != 0) {
		value_name.push_back(str);
	}

	return true;
}

//
// ������д������������
//
bool MakeScript::CloseValueTable()
{
	ofstream	fout(GetValueFile());

	if (!fout)
		throw("can't create value table file");

	for (int i=0; i<value_name.size(); i++) {
		fout << value_name[i] << '\n';
	}
	return true;
}

//
// �ڱ���������Ѱ�ñ�������������ֵ
//
int MakeScript::FindValue(const char *value)
{
	vector<string>::iterator vp = find(value_name.begin(), value_name.end(), value);

	if (vp != value_name.end())				// �ҵ�����
		return vp - value_name.begin();		// ���ر���������

	if (value_name.size() >= MAX_VALUES) {	// ������������ˣ�
		Error("too meny values.");
		return -1;
	}

	value_name.push_back(value);			// ��������
	add_value = true;						// �����и��ĵĶ�������

	return value_name.size() - 1;			// ���ر�������
}

//
// ��������Ĳ��յ���
//
const char *MakeScript::GetValueFile() const
{
	return "value.tbl";
}

//
// ������Ϣ�����
//
void MakeScript::OutputMessage(int code, const char *str) const
{
	cout << str << endl;
}

//
// ���뵵�����к�(������Ϣ)
//
int MakeScript::GetErrorPrefix(char *str) const
{
	if (reader == 0)
		return 0;
	return sprintf(str, "%s:%d ", reader->GetFileName(), reader->GetLineNo());
}

//
// ������Ϣ�����(�д�����)
//
void __cdecl MakeScript::ErrorMessage(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	va_start(args, fmt);
	vsprintf(str, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgError, str);
}

//
// ������Ϣ�����(�������ֵ���к�)
//
void __cdecl MakeScript::Error(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	int		len = GetErrorPrefix(str);
	va_start(args, fmt);
	vsprintf(str + len, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgError, str);
}

//
// ��ʾ����������Ϣ(�������ֵ���к�)
//
void __cdecl MakeScript::FatalError(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	int		len = GetErrorPrefix(str);
	va_start(args, fmt);
	vsprintf(str + len, fmt, args);
	va_end(args);

	nerror++;
	OutputMessage(MsgFatal, str);
}

//
// ��ʾ��Ϣ(����Ϣ������������)
//
void __cdecl MakeScript::Notice(const char *fmt, ...)
{
	va_list	args;

	char	str[256];
	va_start(args, fmt);
	vsprintf(str, fmt, args);
	va_end(args);

	OutputMessage(MsgNotice, str);
}

//
// ��¼��ǩ
//
void MakeScript::AddLabel(const char *label)
{
	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->label == label) {			// �Ѿ���¼��
			if (lp->ref == NULL) {			// ��ǩ�Ѿ�������
				Error("label '%s' redefinition line %d and %d",
					label, lp->line, reader->GetLineNo());
			}
			else {							// ��ǩ�Ѿ����ο���
				LabelRef *chain = lp->ref;

				lp->line = reader->GetLineNo();
				lp->ref = NULL;
				lp->jmp_addr = ncommand;

				while (chain != NULL) {		// ����ο�
					LabelRef *next = chain->next;
					*(chain->label_ref) = ncommand;
					delete chain;
					chain = next;
				}
			}
			return;
		}
	}
	// ��¼�µı�ǩ
	labels.push_back(Label(label, reader->GetLineNo(), ncommand, 0));
}
//
// �ο���ǩ
//
void MakeScript::FindLabel(const char *label, long *reference)
{
	*reference = 0;

	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->label == label) {			// �Ѿ���¼��
			if (lp->ref != NULL) {			// ��ǩ�б��ο�
				// �����ڲο�������
				lp->ref = new LabelRef(lp->ref, reference);
			}
			else {							// �Ѿ���¼��
				// ������ԾĿ��
				*reference = lp->jmp_addr;
			}
			return;
		}
	}
	// ��¼�µı�ǩ�ο�
	LabelRef *chain = new LabelRef(0, reference);
	labels.push_back(Label(label, reader->GetLineNo(), 0, chain));
}

//
// ��ǩ��ȷ��
//
void MakeScript::LabelCheck()
{
	for (vector<Label>::iterator lp = labels.begin(); lp<labels.end(); ++lp) {
		if (lp->ref != NULL) {			// ���вο�����
			const char *label = lp->label.c_str();
			switch (*label) {
			  case '#':
				ErrorMessage("can't find \"endif\". (line %d)", lp->line);
				break;

			  default:
				ErrorMessage("label %s undefined. (line %d)", label, lp->line);
				break;
			}
			LabelRef *chain = lp->ref;
			while (chain != NULL) {		// �ͷŲο�����
				LabelRef *next = chain->next;
				delete chain;
				chain = next;
			}
		}
	}
}

//
// ��¼��ǩ
//
void MakeScript::SetLabel(Lexer &lexer)
{
	if (lexer.NumToken() != 1) {
		Error("too meny parameter");
		return;
	}

	const char *p = lexer.GetString() + 1;
	AddLabel(p);
}

//
// ��������������ڴ�
//
void *MakeScript::AllocCommand(int size, int cmd)
{
	if (ncommand + size >= MAX_COMMAND)
		throw("command table overflow");

	void *p = command_buffer + ncommand;
	ncommand += size;

	memset(p, 0, size);
	((single_cmd_t *)p)->type = cmd;
	((single_cmd_t *)p)->size = size;

	return p;
}

#define	NewCommand(type, id)	(type *)AllocCommand(sizeof(type), id)

//
// ���ַ�����¼�ڱ�����
//
unsigned MakeScript::AddMessage(const char *msg, int limit)
{
	int len = (strlen(msg) + 4) & ~3;	// ���4λԪ�Ķ���

	if (len > limit) {
		Error("length limit over");
		return 0;
	}

	if (ncommand + len >= MAX_COMMAND)
		throw("command table overflow");

	strcpy(command_buffer + ncommand, msg);
	ncommand += len;

	return len;
}

//
// �ȽϹؼ���
//
bool MakeScript::ChkKeyword(const char *str, const char *keyword)
{
	while (*str) {
		if (tolower(*str++) != *keyword++)
			return false;
	}
	return true;
}

//
// �P�ж�CG�����λ��
//
int MakeScript::GetPosition(const char *str)
{
	if (ChkKeyword(str, "center"))
		return POSITION_CENTER;
	if (ChkKeyword(str, "left"))
		return POSITION_LEFT;
	if (ChkKeyword(str, "right"))
		return POSITION_RIGHT;
	if (ChkKeyword(str, "bg") || ChkKeyword(str, "back"))
		return POSITION_BACK;
	if (ChkKeyword(str, "bgo") || ChkKeyword(str, "backonly"))
		return POSITION_BACKONLY;
	if (ChkKeyword(str, "overlap"))
		return POSITION_OVERLAP;

	Error("syntax error (position)");
	return POSITION_BACK;
}

//
// ��¼�޲���������
//
void MakeScript::CommandOnlyCmd(Lexer &lexer, int cmd)
{
	if (lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	NewCommand(single_cmd_t, cmd);
}

//
// ��¼set����
//
void MakeScript::SetCmd(Lexer &lexer)
{
	const char *p1 = lexer.GetString();
	const char *p2 = lexer.GetString();
	int value;
	bool b3 = lexer.GetValue(&value);

	if (p1 == 0 || p2 == 0 || !b3 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}

	if (strcmp(p2, "=") == 0) {			// ָ��
		set_value_t *cp = NewCommand(set_value_t, SET_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->set_value = value;
	}
	else if (strcmp(p2, "+") == 0) {	// �ӷ�
		calc_value_t *cp = NewCommand(calc_value_t, CALC_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->add_value = value;
	}
	else if (strcmp(p2, "-") == 0) {	// ����
		calc_value_t *cp = NewCommand(calc_value_t, CALC_VALUE_CMD);
		cp->value_addr = FindValue(p1);
		cp->add_value = -value;			// ��Ϊ���ϸ�ֵ
	}
	else {
		Error("syntax error");
	}
}


//
// ��¼goto����O
//
void MakeScript::GotoCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in goto command)");
		return;
	}

	goto_t *cp = NewCommand(goto_t, GOTO_CMD);
	FindLabel(p, &(cp->goto_label));
}

//
// �P�жϲ�ȡ�ñ����������ַ���
//
bool MakeScript::GetValueOrNumber(ValueOrNumber *value, Lexer &lexer)
{
	int type = lexer.GetType();

	if (type == Lexer::IsString) {
		const char *p = lexer.GetString();
		if (p == 0)
			return false;
		value->value = FindValue(p);
		value->isvalue = false;
	}
	else {
		if (!lexer.GetValue(&value->value))
			return false;
		value->isvalue = true;
	}
	return true;
}

//
// ���Oָ������Ƚ������ӵĶ�Ӧ��ϵ
//
int MakeScript::BoolOp(const char *op)
{
	if (strcmp(op, "==") == 0) {
		return IF_TRUE_CMD;
	}
	if (strcmp(op, "!=") == 0) {
		return IF_FALSE_CMD;
	}
	if (strcmp(op, "<=") == 0) {
		return IF_SMALLER_EQU_CMD;
	}
	if (strcmp(op, ">=") == 0) {
		return IF_BIGGER_EQU_CMD;
	}
	if (strcmp(op, "<") == 0) {
		return IF_SMALLER_CMD;
	}
	if (strcmp(op, ">") == 0) {
		return IF_BIGGER_CMD;
	}
	Error("syntax error");
	return -1;
}

//
// ��¼if����
//
void MakeScript::IfCmd(Lexer &lexer)
{
	ValueOrNumber	val1;
	ValueOrNumber	val2;
	bool	b1 = GetValueOrNumber(&val1, lexer);
	const char *op = lexer.GetString();
	bool	b2 = GetValueOrNumber(&val2, lexer);

	if (!b1 || !b2 || op == 0) {
		Error("syntax error (in if command)");
		return;
	}

	if_t   *cp = NewCommand(if_t, BoolOp(op));
	cp->flag = 0;
	if (val1.isvalue)
		cp->flag |= 1;
	cp->value1 = val1.value;
	if (val2.isvalue)
		cp->flag |= 2;
	cp->value2 = val2.value;

	const char *p = lexer.GetString();
	const char *label = lexer.GetString();

	if (stricmp(p, "goto") != 0 || label == 0 || lexer.GetString() != 0) {
		Error("syntax error (in if command)");
		return;
	}
	FindLabel(label, &(cp->goto_label));
}

//
// ��¼Menu����
//
void MakeScript::MenuCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in menu command)");
		return;
	}
	int	value_addr = FindValue(p);

	NewCommand(menu_init_t, MENU_INIT_CMD);

	const char *str;
	for (int no=0; (str = reader->GetString()) != NULL; no++) {
		if (stricmp(str, "end") == 0)
			break;

		menu_item_t *ip = NewCommand(menu_item_t, MENU_ITEM_CMD);
		ip->label_len = (unsigned char)AddMessage(str, 255);
		ip->number = no + 1;
	}
	menu_t *op = NewCommand(menu_t, MENU_CMD);
	op->value_addr = value_addr;
}

//
// ��¼load����O
//
void MakeScript::LoadCmd(Lexer &lexer)
{
	const char *p1 = lexer.GetString();
	const char *p2 = lexer.GetString();

	if (p1 == 0 || p2 == 0 || lexer.GetString() != 0) {
		Error("syntax error (in load command)");
		return;
	}

	load_t *cp = NewCommand(load_t, LOAD_CMD);
	cp->flag = GetPosition(p1);
	cp->path_len = (unsigned char)AddMessage(p2, 255);
}

//
// �n��update�R�O
//
void MakeScript::UpdateCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, UPDATE_CMD);
}

//
// ��¼update����
//
void MakeScript::ClearCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in clear command)");
		return;
	}

	if (stricmp(p, "text") == 0) {		// clear text�́A�ʈ���
		NewCommand(clear_text_t, CLEAR_TEXT_CMD);
	}
	else {
		clear_t *cp = NewCommand(clear_t, CLEAR_CMD);
		cp->pos = GetPosition(p);
	}
}

//
// ��¼exec����O
//
void MakeScript::ExecCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error (in exec command)");
		return;
	}

	exec_cmd_t *cp = NewCommand(exec_cmd_t, EXEC_CMD);
	cp->path_len = (unsigned char)AddMessage(p, 255);
}

//
// ������ֵ�β��
//
bool MakeScript::ChkTermination(const char *str)
{
	if (*str++ != '.')
		return false;
	while (*str) {
		if (!isspace(*str))
			return false;
	}
	return true;
}

//
// ��¼text����O
//
void MakeScript::TextCmd(Lexer &lexer)
{
	if (lexer.GetString() != 0) {
		Error("syntax error (in text command)");
		return;
	}

	text_t *cp = NewCommand(text_t, TEXT_CMD);

	string	work;

	for (int i=0; ; i++) {
		const char *str;
		if ((str = reader->GetString()) == NULL) {
			Error("syntax error (text syntax)");
			break;
		}
		if (ChkTermination(str))
			break;
		work += str;
		work += '\n';

		if (i >= MAX_TEXTLINE) {
			Error("text line overflow");
			break;
		}
	}
	cp->msg_len = (unsigned short)AddMessage(work.c_str(), 65536);
}

//
// ��¼mode����
//
void MakeScript::ModeCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();
	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	if (stricmp(p, "system") == 0) {
		mode_cmd_t *cp = NewCommand(mode_cmd_t, MODE_CMD);
		cp->mode = MODE_SYSTEM;
	}
	else if (stricmp(p, "scenario") == 0) {
		mode_cmd_t *cp = NewCommand(mode_cmd_t, MODE_CMD);
		cp->mode = MODE_SCENARIO;
	}
	else {
		Error("syntax error");
	}
}

//
// ��¼system����
//
void MakeScript::SystemCmd(Lexer &lexer)
{
	const char *p = lexer.GetString();

	if (p == 0 || lexer.GetString() != 0) {
		Error("syntax error");
		return;
	}
	if (stricmp(p, "exit") == 0) {
		NewCommand(single_cmd_t, SYS_EXIT_CMD);
	}
	else if (stricmp(p, "clear") == 0) {
		NewCommand(single_cmd_t, SYS_CLEAR_CMD);
	}
	else {
		Error("syntax error");
	}
}

//
// ��¼end����O
//
void MakeScript::EndCmd(Lexer &lexer)
{
	CommandOnlyCmd(lexer, END_CMD);
}

//
// �����ű�������O
//
MakeScript::cmd_t MakeScript::ParseCommand(Lexer &lexer)
{
	static CmdTab	Table[] = {
		{ "set",		&MakeScript::SetCmd },
		{ "calc",		&MakeScript::SetCmd },
		{ "text",		&MakeScript::TextCmd },
		{ "goto",		&MakeScript::GotoCmd },
		{ "if",			&MakeScript::IfCmd },
		{ "menu",		&MakeScript::MenuCmd },
		{ "exec",		&MakeScript::ExecCmd },
		{ "load",		&MakeScript::LoadCmd },
		{ "update",		&MakeScript::UpdateCmd },
		{ "clear",		&MakeScript::ClearCmd },
		{ "mode",		&MakeScript::ModeCmd },
		{ "system",		&MakeScript::SystemCmd },
		{ "end",		&MakeScript::EndCmd },
		{ NULL },
	} ;

	const char *cmd = lexer.GetString(0);

	for (CmdTab *tp=Table; tp->command != NULL; tp++) {
		if (stricmp(cmd, tp->command) == 0)
			return tp->func;
	}

	// �Ƿ�Ϊ set, calc ��ʡ����ʽ
	if (lexer.NumToken() >= 3) {
		const char *p = lexer.GetString(1);
		lexer.GetType(0);			// ����ǰ��
		if (strcmp(p, "+") == 0 || strcmp(p, "-") == 0 || strcmp(p, "=") == 0) {
			return &MakeScript::SetCmd;
		}
	}
	Error("syntax error (command syntax)");
	return NULL;
}

//
// ���з���
//
void MakeScript::ParserString(const char *str)
{
	Lexer	lexer(str);

	if (lexer.NumToken() == 0)
		return;

	int	type = lexer.GetType();

	if (type == Lexer::IsLabel) {
		SetLabel(lexer);
	}
	else {
		cmd_t cmd = ParseCommand(lexer);
		if (cmd)
			(this->*cmd)(lexer);
	}
}

//
// ��ȡ�ű�ԭʼ����ת��
//
int MakeScript::ReadScript(const char *name)
{
	FileReader	Reader(name);

	if (!Reader) {
		ErrorMessage("file %s can't open.", name);
		return 1;
	}

	reader = &Reader;

	try {
		OpenValueTable();

		const char *str;
		while ((str = reader->GetString()) != 0) {
			ParserString(str);
		}
		NewCommand(single_cmd_t, END_CMD);

		LabelCheck();

		if (nerror != 0)
			Notice("I have %d error%s found.", nerror, (nerror == 1? "": "s"));

		if (nerror == 0 && add_value)
			CloseValueTable();
	}
	catch (char *error) {
		FatalError("%s", error);
	}
	catch (bad_alloc &) {
		FatalError("not enough memory");
	}

	return nerror;
}

//
// �洢�ű��ļ���
//
int MakeScript::WriteScript(const char *name)
{
	FILE *fp;

	if ((fp = fopen(name, "wb")) == NULL) {
		ErrorMessage("can't create %s.", name);
		return -1;
	}

	int		error = 0;
	if (fwrite(SCRIPT_MAGIC, sizeof(char), 8, fp) != 8
	 || fwrite(&ncommand, sizeof(long), 1, fp) != 1
	 || fwrite(command_buffer, sizeof(char), ncommand, fp) != (unsigned)ncommand) {
		ErrorMessage("write error in %s.", name);
		error = 1;
	}
	else {
		Notice("command %d bytes use", ncommand);
	}
	fclose(fp);

	return error;
}

