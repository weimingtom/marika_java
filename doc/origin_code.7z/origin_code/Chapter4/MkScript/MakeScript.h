//
// Script converter
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__MAKESCRIPT_H__
#define	__MAKESCRIPT_H__

#include "Lexer.h"
#include "ScriptTypes.h"

#ifndef	_MAX_PATH
#define	_MAX_PATH	260
#endif

#define	UC(c)	(unsigned char)(c)

class FileReader;

//
// Script converter ��
//
class MakeScript {
  protected:
	// ������Ϣ��
	enum	{
		MsgNotice,
		MsgError,
		MsgFatal,
	} ;

  protected:
	//
	// Label reference ��
	//
	class LabelRef {
	  public:
		LabelRef(LabelRef *_next, long *_label_ref)
			:next(_next), label_ref(_label_ref) {}

	  public:
		LabelRef   *next;
		long       *label_ref;
	} ;

	//
	// Label ��
	//
	class Label {
	  public:
		Label(const char *_label, unsigned _line, long _jmp_addr, LabelRef *_ref)
			:label(_label), line(_line), jmp_addr(_jmp_addr), ref(_ref) {}

	  public:
		string		label;
		unsigned	line;
		long		jmp_addr;
		LabelRef   *ref;
	} ;

	//
	// ����/������O
	//
	struct	ValueOrNumber	{
		bool	isvalue;
		int		value;
	} ;

	typedef void (MakeScript::*cmd_t)(Lexer &);
	struct	CmdTab	{
		const char *command;
		cmd_t		func;
	} ;

  public:
	MakeScript();
	~MakeScript();

	int ReadScript(const char *name);
	void ParserString(const char *str);
	int WriteScript(const char *name);

	bool IsError() const { return nerror != 0; }

  protected:
	void AddLabel(const char *label);
	void FindLabel(const char *label, long *reference);
	void LabelCheck();
	void SetLabel(Lexer &lexer);
	void *AllocCommand(int size, int cmd);
	bool ChkKeyword(const char *str, const char *keyword);
	int GetPosition(const char *str);
	bool GetValueOrNumber(ValueOrNumber *value, Lexer &lexer);
	int BoolOp(const char *op);
	void CommandOnlyCmd(Lexer &lexer, int cmd);
	void SetCmd(Lexer &lexer);
	void GotoCmd(Lexer &lexer);
	void IfCmd(Lexer &lexer);
	void MenuCmd(Lexer &lexer);
	void ExecCmd(Lexer &lexer);
	void LoadCmd(Lexer &lexer);
	void UpdateCmd(Lexer &lexer);
	void ClearCmd(Lexer &lexer);
	bool ChkTermination(const char *str);
	void TextCmd(Lexer &lexer);
	void ModeCmd(Lexer &lexer);
	void SystemCmd(Lexer &lexer);
	void EndCmd(Lexer &lexer);

	cmd_t ParseCommand(Lexer &lexer);

	bool OpenValueTable();
	bool CloseValueTable();
	int FindValue(const char *value);

	unsigned AddMessage(const char *msg, int limit);

	virtual void OutputMessage(int code, const char *str) const;
	virtual int GetErrorPrefix(char *str) const;
	virtual const char *GetValueFile() const;

	void __cdecl ErrorMessage(const char *fmt, ...);
	void __cdecl Error(const char *fmt, ...);
	void __cdecl FatalError(const char *fmt, ...);
	void __cdecl Notice(const char *fmt, ...);

  protected:
	FileReader     *reader;

  private:
	int				nerror;
	int				ncommand;
	bool			add_value;
	vector<string>	value_name;
	vector<Label>	labels;
	char           *command_buffer;
} ;

#endif
