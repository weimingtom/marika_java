//
// Script converter
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__SCRIPTTYPES_H__
#define	__SCRIPTTYPES_H__

// ���Oָ����-Command code
enum	{
	SET_VALUE_CMD,
	CALC_VALUE_CMD,
	TEXT_CMD,
	CLEAR_TEXT_CMD,
	GOTO_CMD,
	IF_TRUE_CMD,
	IF_FALSE_CMD,
	IF_BIGGER_CMD,
	IF_SMALLER_CMD,
	IF_BIGGER_EQU_CMD,
	IF_SMALLER_EQU_CMD,
	MENU_INIT_CMD,
	MENU_ITEM_CMD,
	MENU_CMD,
	EXEC_CMD,
	LOAD_CMD,
	UPDATE_CMD,
	CLEAR_CMD,
	MODE_CMD,
	SYS_EXIT_CMD,
	SYS_CLEAR_CMD,
	END_CMD,
} ;

// CG��λ��
enum	{
	POSITION_BACK,
	POSITION_BACKONLY,
	POSITION_CENTER,
	POSITION_LEFT,
	POSITION_RIGHT,
	POSITION_OVERLAP,
} ;

// Mode Flag
enum	{
	MODE_SYSTEM,
	MODE_SCENARIO,
} ;

#ifdef	_MSC_VER
#pragma pack(push, 4)
#endif

// ����Ĺ�ͨ�ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			dummy[2];
} single_cmd_t;

typedef	single_cmd_t	clear_text_t;
typedef	single_cmd_t	sys_clear_t;
typedef	single_cmd_t	end_t;

// set����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	unsigned short	value_addr;
	long			set_value;
} set_value_t;

// calc����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	unsigned short	value_addr;
	long			add_value;
} calc_value_t;

// text����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	unsigned short	msg_len;
} text_t;

// goto����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			dummy[2];
	long			goto_label;
} goto_t;

// if����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	unsigned char	flag;
	char			dummy;
	long			value1;
	long			value2;
	long			goto_label;
} if_t;

typedef	single_cmd_t	menu_init_t;

// menu����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	short			value_addr;
} menu_t;

// Menuѡ������O
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	unsigned char	number;
	unsigned char	label_len;
} menu_item_t;

// exec����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			dummy;
	unsigned char	path_len;
} exec_cmd_t;

// load����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			flag;
	unsigned char	path_len;
} load_t;

// update����ṹ��
typedef	single_cmd_t	update_t;

// clear����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			pos;
	char			dummy;
} clear_t;

// mode����ṹ��
typedef	struct	{
	unsigned char	type;
	unsigned char	size;
	char			mode;
	char			dummy;
} mode_cmd_t;

// ����O
typedef	union	{
	struct	{
		unsigned char	type;
		unsigned char	size;
	} common;
	set_value_t			set;
	calc_value_t		calc;
	text_t				text;
	clear_text_t		clear_text;
	goto_t				goto_cmd;
	if_t				if_cmd;
	menu_init_t			menu_init;
	menu_t				menu;
	menu_item_t			menu_item;
	load_t				load;
	update_t			update;
	clear_t				clear;
	exec_cmd_t			exec_cmd;
	mode_cmd_t			mode;
	end_t				end;
} command_t;

#ifdef	_MSC_VER
#pragma pack(pop)
#endif

//  ���ֵ�j��
#define	MAX_COMMAND		65536
#define	MAX_VALUES		100
#define	MAX_TEXTLINE	4

#define	SCRIPT_MAGIC	"[SCRIPT]"

#endif
