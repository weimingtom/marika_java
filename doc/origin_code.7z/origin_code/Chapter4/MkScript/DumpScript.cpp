// �T�{�}���ഫ�����ʧ@--���եε{��
// Script converter, the dumping output for a test


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ScriptTypes.h"

char command_buffer[MAX_COMMAND];
long ncommand;
int position;

int ReadScript(const char *name)
{
	FILE *fp;

	if ((fp = fopen(name, "rb")) == NULL) {
		fprintf(stderr, "can't open %s.\n", name);
	return -1;
	}

	char magic[8];
	int error = 0;
	if (fread(magic, sizeof(char), 8, fp) != 8
		|| memcmp(magic, SCRIPT_MAGIC, 8) != 0) {
		fprintf(stderr, "%s not script file.\n", name);
		error = 1;
	}
	else if (fread(&ncommand, sizeof(long), 1, fp) != 1
		|| fread(command_buffer, sizeof(char), ncommand, fp) != (unsigned)ncommand) {
		fprintf(stderr, "read error in %s.\n", name);
		error = 1;
	}
	fclose(fp);

	return error;
}

const char *ValName(char *name, int valno)
{
	sprintf(name, "value[%d]", valno);
	return name;
}

const char *GetString(unsigned size)
{
	if (size == 0)
		return "<null>";
	char *p = command_buffer + position;
	position += size;
	return p;
}

const char *GetValue(char *name, int addr, int flag)
{
	if (flag) {
		sprintf(name, "%d", addr);
		return name;
	}
	return ValName(name, addr);
}

const char *GetPosName(int pos)
{
	switch (pos) {
	case POSITION_BACK:
		return "back";

	case POSITION_BACKONLY:
		return "backonly";

	case POSITION_CENTER:
		return "center";

	case POSITION_LEFT:
		return "left";

	case POSITION_RIGHT:
		return "right";

	case POSITION_OVERLAP:
		return "overlap";
	}
	return "<unknown>";
}

const char *GetModeName(int mode)
{
switch (mode) {
case MODE_SYSTEM:
return "system";

case MODE_SCENARIO:
return "scenario";
}
return "<unknown>";
}

void DumpStep(command_t *cmd)
{
char str1[24], str2[24];

switch (cmd->common.type) {
case SET_VALUE_CMD:
printf("set %s = %d\n", ValName(str1, cmd->set.value_addr), cmd->set.set_value);
break;

case CALC_VALUE_CMD:
printf("calc %s += %d\n", ValName(str1, cmd->calc.value_addr), cmd->calc.add_value);
break;

case TEXT_CMD:
printf("text\n%s.\n", GetString(cmd->text.msg_len));
break;

case CLEAR_TEXT_CMD:
printf("clear text\n");
break;

case GOTO_CMD:
printf("goto %d\n", cmd->goto_cmd.goto_label);
break;

case IF_TRUE_CMD:
printf("if (%s == %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case IF_FALSE_CMD:
printf("if (%s != %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case IF_BIGGER_CMD:
printf("if (%s > %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case IF_SMALLER_CMD:
printf("if (%s < %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case IF_BIGGER_EQU_CMD:
printf("if (%s >= %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case IF_SMALLER_EQU_CMD:
printf("if (%s <= %s) goto %d\n",
GetValue(str1, cmd->if_cmd.value1, cmd->if_cmd.flag & 1),
GetValue(str2, cmd->if_cmd.value2, cmd->if_cmd.flag & 2),
cmd->if_cmd.goto_label);
break;

case MENU_INIT_CMD:
printf("menu init\n");
break;

case MENU_ITEM_CMD:
printf("menu item %d %s\n", cmd->menu_item.number,
GetString(cmd->menu_item.label_len));
break;

case MENU_CMD:
printf("menu open %s\n", ValName(str1, cmd->menu.value_addr));
break;

case EXEC_CMD:
printf("exec %s\n", GetString(cmd->exec_cmd.path_len));
break;

case LOAD_CMD:
printf("load %s %s\n", GetPosName(cmd->load.flag), GetString(cmd->load.path_len));
break;

case UPDATE_CMD:
printf("update\n");
break;

case CLEAR_CMD:
printf("clear %s\n", GetPosName(cmd->clear.pos));
break;

case MODE_CMD:
printf("mode %s\n", GetModeName(cmd->mode.mode));
break;

case SYS_EXIT_CMD:
printf("sys_exit\n");
break;

case SYS_CLEAR_CMD:
printf("sys_clear\n");
break;

case END_CMD:
printf("end\n");
break;

default:
printf("error\n");
break;
}
}

inline command_t *GetCommand()
{
command_t *p = (command_t *)(command_buffer + position);
position += p->common.size;
return p;
}

int main(int ac, char *av[])
{
if (ac != 2) {
fprintf(stderr, "usage dumpscript filename\n");
exit(1);
}
if (ReadScript(av[1]) != 0)
exit(1);

position = 0;
while (position < ncommand) {
printf("%3d:", position);
command_t *p = GetCommand();
DumpStep(p);
}

return 0;
}
