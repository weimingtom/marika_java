// MkScript.h : main header file for the MKSCRIPT application
//

#if !defined(AFX_MKSCRIPT_H__9BC7FC10_2EF9_4972_8132_2ACDC74FD72A__INCLUDED_)
#define AFX_MKSCRIPT_H__9BC7FC10_2EF9_4972_8132_2ACDC74FD72A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMkScriptApp:
// See MkScript.cpp for the implementation of this class
//

class CMkScriptApp : public CWinApp
{
public:
	CMkScriptApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMkScriptApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMkScriptApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MKSCRIPT_H__9BC7FC10_2EF9_4972_8132_2ACDC74FD72A__INCLUDED_)
