//
// Script converter
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__READER_H__
#define	__READER_H__

//
// Text file reading class
//
class FileReader {
  public:
	FileReader(const char *name);
	~FileReader();

	const char *GetString();
	const char *GetFileName() const { return filename; }
	int GetLineNo() const { return lineno; }
	bool IsOpen() const { return fp != 0; }

	operator bool() const { return IsOpen(); }

  private:
	const char *filename;
	int		lineno;
	FILE   *fp;
	char	read_buffer[512];
} ;

#endif
