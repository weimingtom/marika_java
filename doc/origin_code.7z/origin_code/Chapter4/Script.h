//
// ִ��Script
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__script_h__
#define	__script_h__

#include "MkScript/ScriptTypes.h"
#include "Action.h"
#include "Misc.h"

//
// Script���ı�ͷ
//
typedef	struct	{
	char		magic[8];
	long		ncommand;
} script_t;

//
// Script
//
struct	ScriptData	{
	byte_t     *commands;
	int			ncommand;
} ;

class CMainWin;

//
// Script ��
//
class CScriptAction: public CAction {
  public:
	// ״̬
	enum	{
		BreakGame = -1,
		Continue = 0,
		WaitNextIdle,
		WaitKeyPressed,
		WaitMenuDone,
	} ;

  public:
	CScriptAction(): CAction(TRUE), script_buffer(0) {}
	~CScriptAction() { delete script_buffer; }

	virtual	void Initialize(CMainWin *parent, unsigned param1=0, unsigned param2=0);

	virtual	void LButtonDown(UINT modKeys, CPoint point);
	virtual	void LButtonUp(UINT modKeys, CPoint point);
	virtual	void RButtonDown(UINT modKeys, CPoint point);
	virtual	void MouseMove(UINT modKeys, CPoint point);

	virtual	void KeyDown(UINT key);

	virtual BOOL IdleAction();

	BOOL Load(const char *name);

	void Abort();

  protected:
	enum	{
		FileNoError,
		FileCannotOpen,
		NotEnoughMemory,
		FileCannotRead,
	} ;

	char *__cdecl Format(const char *fmt,...);
	int LoadFile(const char *name);
	command_t *GetCommand();
	void GotoCommand(unsigned next);
	char *GetString(unsigned size);
	int GetValue(unsigned value_addr);
	int GetValue(int addr, int flag);
	void SetValue(unsigned value_addr, int set_value);
	void CalcValue(unsigned value_addr, int calc_value);
	int LoadGraphic(const char *file, int pos);
	int UpdateImage();
	int Clear(int pos);
	void ClearAllValues();

	int Step();

  protected:
	BOOL		Pressed;
	int			MenuSelect;
	int			MenuAnserAddr;
	int			PlayMode;

	char       *script_buffer;

	ScriptData	current;

	int			position;
	int			status;

	int			value_tab[MAX_VALUES];
} ;

// Inline��Ա����

inline command_t *CScriptAction::GetCommand()
{
	command_t *p = (command_t *)(current.commands + position);
	position += p->common.size;
	return p;
}

inline void CScriptAction::GotoCommand(unsigned next)
{
	position = next;
}

inline char *CScriptAction::GetString(unsigned size)
{
	if (size == 0)
		return NULL;
	char *p = (char *)current.commands + position;
	position += size;
	return p;
}

inline int CScriptAction::GetValue(unsigned value_addr)
{
	return value_tab[value_addr];
}

inline int CScriptAction::GetValue(int addr, int flag)
{
	if (flag)
		return addr;

	return value_tab[addr];
}

inline void CScriptAction::SetValue(unsigned value_addr, int set_value)
{
	value_tab[value_addr] = set_value;
}

inline void CScriptAction::CalcValue(unsigned value_addr, int calc_value)
{
	value_tab[value_addr] += calc_value;
}

inline void CScriptAction::ClearAllValues()
{
	memset(value_tab, 0, sizeof(value_tab));
}

#endif
