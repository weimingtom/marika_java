//
// ʹ���ߵĶ���
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__action_h__
#define	__action_h__

class CMainWin;

//
// Action ��
// 
// ������������������ڲ�����Ϣ
// �Ǵ�CMainWin����
//
class CAction {
  public:
	CAction(BOOL scriptRun=FALSE): ScriptRunning(scriptRun) {}

	virtual	void Initialize(CMainWin *parent, unsigned param1=0, unsigned param2=0);

	virtual	void LButtonDown(UINT modKeys, CPoint point);
	virtual	void LButtonUp(UINT modKeys, CPoint point);
	virtual	void RButtonDown(UINT modKeys, CPoint point);
	virtual	void RButtonUp(UINT modKeys, CPoint point);
	virtual	void MouseMove(UINT modKeys, CPoint point);
	virtual	void KeyDown(UINT key);
	virtual BOOL IdleAction();

	BOOL IsScriptRunning() const { return ScriptRunning; }

  protected:
	BOOL			ScriptRunning;
	CMainWin       *Parent;
	unsigned long	Param1, Param2;
} ;

#endif
