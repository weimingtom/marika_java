//
//  Script Player Application
//
//		Copyright (c) 2000-2002 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__ScrPlay_h__
#define	__ScrPlay_h__

#include "Application.h"
#include "MainWin.h"

#define	WM_FIRSTACTION	(WM_USER + 1)

//
// Ӧ�ó�����
//
class CScrPlayApp: public CWinApp {
  public:
	CScrPlayApp();
	~CScrPlayApp();

	BOOL InitInstance();

  protected:
	CMainWin	MainWin;
	HANDLE		hMutex;
} ;

#endif
