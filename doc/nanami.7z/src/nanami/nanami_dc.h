#ifndef	__NANAMI_DC_H__
#define	__NANAMI_DC_H__

struct nanami_window_struct;

typedef struct nanami_dc_struct {
	HDC	hDC;
	HWND hWnd;
	PAINTSTRUCT ps;
} nanami_dc_t;

extern nanami_dc_t *nanami_dc_new_1();
extern nanami_dc_t *nanami_dc_new_2(HDC dc);
extern void nanami_dc_free(nanami_dc_t *dc);
extern int nanami_dc_GetDIBits(nanami_dc_t *dc, HBITMAP hbmp, UINT uStartScan, UINT cScanLines, LPVOID lpvBits, LPBITMAPINFO lpbi, UINT uUsage);
extern BOOL nanami_dc_GetTextExtentPoint32(nanami_dc_t *dc, LPCTSTR lpsz, int cbString, LPSIZE lpSize);
extern BOOL nanami_dc_ExtTextOut(nanami_dc_t *dc, int X, int Y, UINT fuOptions, CONST RECT *lprc, LPCTSTR lpszString, UINT cbCount, CONST INT *lpDx);
extern COLORREF nanami_dc_SetTextColor(nanami_dc_t *dc, COLORREF crColor);
extern COLORREF nanami_dc_SetBkColor(nanami_dc_t *dc, COLORREF crColor);
extern int nanami_dc_SetBkMode(nanami_dc_t *dc, int bkMode);
extern int nanami_dc_GetDeviceCaps(nanami_dc_t *dc, int nIndex);
extern HBITMAP nanami_dc_SelectObject_bitmap(nanami_dc_t *dc, HBITMAP hBitmap);
extern HFONT nanami_dc_SelectObject_font(nanami_dc_t *dc, HFONT hFont);

extern nanami_dc_t *nanami_client_dc_new(struct nanami_window_struct *win);
extern void nanami_client_dc_free(nanami_dc_t *dc);
extern nanami_dc_t *nanami_paint_dc_new(struct nanami_window_struct *win);
extern void nanami_paint_dc_free(nanami_dc_t *dc);
extern nanami_dc_t *nanami_memory_dc_new(HDC hdc);
extern void nanami_memory_dc_free(nanami_dc_t *dc);
extern nanami_dc_t *nanami_screen_dc_new();
extern void nanami_screen_dc_free(nanami_dc_t *dc);

#endif //__NANAMI_DC_H__
