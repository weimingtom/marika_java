#include "nanami_common.h"

#include <windows.h>
#include <io.h>
#include <stdio.h>
#include <share.h>
#include "nanami_file.h"

nanami_file_t *nanami_file_new(const char *filename, int mode)
{
	nanami_file_t *file = (nanami_file_t *)malloc(sizeof(nanami_file_t)); 
	file->fp = NULL;
	nanami_file_Open(file, filename, mode);
	return file;
}

void nanami_file_free(nanami_file_t *file)
{
	nanami_file_Close(file);
	free(file);
}

BOOL nanami_file_Open(nanami_file_t *file, const char *filename, int mode)
{
#if defined(_MSC_VER)
	file->fp = _fsopen(filename, mode == NANAMI_FILE_READ? "rb": "wb", _SH_DENYWR);
#elif defined(__BORLANDC__)
	file->fp = fopen(filename, mode == NANAMI_FILE_READ? "rb": "wb");
#else
        file->fp = fopen(filename, mode == NANAMI_FILE_READ? "rb": "wb");
#endif //_MSC_VER
	return (file->fp != NULL) ? TRUE : FALSE;
}

BOOL nanami_file_Close(nanami_file_t *file)
{
	if (file->fp != NULL) 
	{
		fclose(file->fp);
		file->fp = NULL;
	}
	return TRUE;
}

int nanami_file_Read(nanami_file_t *file, void *buffer, int length)
{
	return fread(buffer, 1, length, file->fp);
}

int nanami_file_Write(nanami_file_t *file, const void *buffer, int length)
{
	return fwrite(buffer, 1, length, file->fp);
}

long nanami_file_Seek(nanami_file_t *file, long offset, int from)
{
	return fseek(file->fp, offset, from);
}

long nanami_file_GetFileSize(nanami_file_t *file) 
{
#if defined(_MSC_VER)
        return _filelength(_fileno(file->fp));
#elif defined(__BORLANDC__)
	return filelength(_fileno(file->fp));
#else
        return filelength(_fileno(file->fp));
#endif //_MSC_VER
}

BOOL nanami_file_IsOk(nanami_file_t *file)
{ 
	return (file->fp != NULL) ? TRUE : FALSE; 
}

BOOL nanami_file_Error(nanami_file_t *file) 
{
	return (ferror(file->fp) != 0) ? TRUE : FALSE; 
}
