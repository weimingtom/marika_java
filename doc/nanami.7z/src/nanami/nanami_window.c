#include "nanami_common.h"

#ifndef NO_D3D_DEFINED
#include <d3d9.h>
#include <d3dx9.h>
#endif

#include "nanami_app.h"
#include "nanami_window.h"
#include "nanami_misc.h"
#include "nanami_dc.h"
#include "nanami_geometry.h"
#include "resource.h"

//#pragma comment(lib, "d3d9.lib")
//#pragma comment(lib, "d3dx9.lib")

//#define FULLSCREEN

nanami_window_t *nanami_window_WindowListTop;
nanami_window_t *nanami_window_WindowInitPtr;

void nanami_window_init(nanami_window_t *win)
{
	win->App = NULL;
	win->hWnd = NULL;
	win->LastMsg = WM_NULL;
	win->LastWParam = 0;
	win->LastLParam = 0;
	win->hAccelTable = 0;
	win->Next = 0;

	//virtual functions
	win->PreTranslateMessage = nanami_window_PreTranslateMessage;
	win->WindowProc = NULL;
	win->OnCommand = nanami_window_OnCommand;
	win->OnInitSubMenu = nanami_window_OnInitSubMenu;

	win->OnPaint = nanami_window_OnPaint;
	win->OnInitMenuPopup = nanami_window_OnInitMenuPopup;
#ifndef NO_D3D_DEFINED
	if(0)
	{
		win->PreCreateWindow = nanami_window_PreCreateWindow;
		win->OnCreate = nanami_window_OnCreate;
		win->OnDestroy = nanami_window_OnDestroy;
		win->OnIdle = nanami_window_OnIdle;
	}
	else if(1)
	{
		win->PreCreateWindow = nanami_d3dwin_PreCreateWindow;
		win->OnCreate = nanami_d3dwin_OnCreate;
		win->OnDestroy = nanami_d3dwin_OnDestroy;
		win->OnIdle = nanami_d3dwin_OnIdle;
	}
#else
        win->PreCreateWindow = nanami_window_PreCreateWindow;
        win->OnCreate = nanami_window_OnCreate;
        win->OnDestroy = nanami_window_OnDestroy;
        win->OnIdle = nanami_window_OnIdle;
#endif //NO_D3D_DEFINED
}

nanami_window_t *nanami_window_new()
{
	nanami_window_t *win = (nanami_window_t *)malloc(sizeof(nanami_window_t));
	nanami_window_init(win);
	return win;
}

void nanami_window_free(nanami_window_t *win)
{
	free(win);
}

nanami_window_t *nanami_window_GetWindow(HWND hwnd)
{
	nanami_window_t *p;
	for (p = nanami_window_WindowListTop; p; p=p->Next) 
	{
		if (p->hWnd == hwnd)
		{
			return p;
		}
	}
	return NULL;
}

BOOL nanami_window_AddWindowList(nanami_window_t *win, HWND hWndNew)
{
	win->Next = nanami_window_WindowListTop;
	nanami_window_WindowListTop = win;
	win->hWnd = hWndNew;
	return TRUE;
}

HWND nanami_window_DeleteWindowList(nanami_window_t *win)
{
	nanami_window_t **p;

	for (p = &nanami_window_WindowListTop; *p; p = &((*p)->Next)) 
	{
		if (*p == win) 
		{
			*p = win->Next;
			break;
		}
	}
	return win->hWnd;
}

//static public
LRESULT CALLBACK nanami_window_WindowProc_2(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	nanami_window_t *win = nanami_window_GetWindow(hwnd);
	if (win == 0 && nanami_window_WindowInitPtr != 0) 
	{
		win = nanami_window_WindowInitPtr;
		nanami_window_AddWindowList(nanami_window_WindowInitPtr, hwnd);
		nanami_window_WindowInitPtr = 0;
	}
	if (win) 
	{
		nanami_window_SetLastParam(win, uMsg, wParam, lParam);
		return nanami_window_WindowProc(win, uMsg, wParam, lParam);
	}
	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}



BOOL nanami_window_PreTranslateMessage(nanami_window_t *win, MSG *msg)
{
	if (msg->message >= WM_KEYFIRST && msg->message <= WM_KEYLAST) 
	{
		return win->hAccelTable != NULL && TranslateAccelerator(win->hWnd, win->hAccelTable, msg);
	}
	return FALSE;
}

BOOL nanami_window_Create(nanami_window_t *win, nanami_app_t *app, const char *name, nanami_window_t *parent)
{
	return nanami_window_Create_menu(win, app, name, 0, parent);
}

BOOL nanami_window_Create_menu(nanami_window_t *win, nanami_app_t *app, const char *name, HMENU hMenu, nanami_window_t *parent)
{
	CREATESTRUCT cs;
	HWND hWnd;

	win->App = app;
	cs.dwExStyle = WS_EX_CLIENTEDGE;
	cs.lpszClass = NULL;
	cs.lpszName = name;
	cs.style = WS_OVERLAPPEDWINDOW;
	cs.x = CW_USEDEFAULT;
	cs.y = CW_USEDEFAULT;
	cs.cx = CW_USEDEFAULT;
	cs.cy = CW_USEDEFAULT;
	cs.hwndParent = parent? parent->hWnd: 0;
	cs.hMenu = hMenu;
	cs.hInstance = app->Instance;
	cs.lpCreateParams = 0;
	//if (!nanami_window_PreCreateWindow(win, &cs))
	if (!win->PreCreateWindow(win, &cs))
	{
		return FALSE;
	}
	if (cs.lpszClass == 0) 
	{
		cs.lpszClass = "Window";
		if (!nanami_app_RegisterWndClass(nanami_app_Application, cs.lpszClass, CS_VREDRAW | CS_HREDRAW, NULL, (HBRUSH)(COLOR_WINDOW+1), NULL))
		{
			return FALSE;
		}
	}

	nanami_window_WindowInitPtr = win;
	hWnd = CreateWindowEx(cs.dwExStyle, cs.lpszClass,
		cs.lpszName, cs.style, cs.x, cs.y, cs.cx, cs.cy,
		cs.hwndParent, cs.hMenu, cs.hInstance, cs.lpCreateParams);
	if (nanami_window_WindowInitPtr != NULL) 
	{
		nanami_window_WindowInitPtr = NULL;
		return FALSE;
	}
	if (hWnd == NULL)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL nanami_window_PreCreateWindow(nanami_window_t *win, CREATESTRUCT *cs)
{
	return TRUE;
}

LRESULT nanami_window_WindowProc(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) 
	{
	case WM_CREATE:
		//if (!nanami_window_OnCreate(win, (LPCREATESTRUCT)lParam))
		if (!win->OnCreate(win, (LPCREATESTRUCT)lParam))
		{
			return -1;
		}
		break;

	case WM_PAINT:
		//nanami_window_OnPaint(win);
		win->OnPaint(win);
		break;

	case WM_DESTROY:
		//nanami_window_OnDestroy(win);
		win->OnDestroy(win);
		break;

	case WM_COMMAND:
		//nanami_window_OnCommand(win, HIWORD(wParam), LOWORD(wParam), (HWND)lParam);
		win->OnCommand(win, HIWORD(wParam), LOWORD(wParam), (HWND)lParam);
		break;

	case WM_INITMENUPOPUP:
		//nanami_window_OnInitMenuPopup(win, (HMENU)wParam, LOWORD(lParam), HIWORD(lParam));
		win->OnInitMenuPopup(win, (HMENU)wParam, LOWORD(lParam), HIWORD(lParam));
		break;

	case WM_NCDESTROY:
		nanami_window_DeleteWindowList(win);
		break;
	
	default:
		return nanami_window_Default(win);
	}
	return 0L;
}

BOOL nanami_window_OnIdle(nanami_window_t *win, long count)
{
	return FALSE;
}

BOOL nanami_window_OnCreate(nanami_window_t *win, CREATESTRUCT *cs)
{
	return TRUE;
}

void nanami_window_OnPaint(nanami_window_t *win)
{
	nanami_dc_t *dc = nanami_paint_dc_new(win);
	nanami_paint_dc_free(dc);
}

void nanami_window_OnDestroy(nanami_window_t *win)
{
	PostQuitMessage(0);
}

void nanami_window_OnCommand(nanami_window_t *win, UINT notifyCode, UINT id, HWND ctrl)
{

}

void nanami_window_OnInitMenuPopup(nanami_window_t *win, HMENU hMenu, UINT pos, BOOL sysMenu)
{
	int indexMax, index;

	if (sysMenu)
	{
		return;
	}
	indexMax = GetMenuItemCount(hMenu);
	for (index = 0; index < indexMax; index++) 
	{
		//nanami_window_OnInitSubMenu(win, hMenu, GetMenuItemID(hMenu, index));
		win->OnInitSubMenu(win, hMenu, GetMenuItemID(hMenu, index));
	}
}

void nanami_window_OnInitSubMenu(nanami_window_t *win, HMENU hMenu, UINT id)
{

}

void nanami_window_SetLastParam(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	win->LastMsg = uMsg;
	win->LastWParam = wParam;
	win->LastLParam = lParam;
}

BOOL nanami_window_LoadAccelTable_name(nanami_window_t *win, const char *name)
{
	win->hAccelTable = nanami_app_LoadAccelerators(nanami_app_Application, name);
	return (win->hAccelTable != NULL);
}

BOOL nanami_window_LoadAccelTable_id(nanami_window_t *win, int resId)
{
	return nanami_window_LoadAccelTable_name(win, MAKEINTRESOURCE(resId));
}

LRESULT nanami_window_Default(nanami_window_t *win)
{
	return DefWindowProc(win->hWnd, win->LastMsg, win->LastWParam, win->LastLParam);
}

LRESULT nanami_window_SendMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return SendMessage(win->hWnd, uMsg, wParam, lParam);
}

BOOL nanami_window_PostMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return PostMessage(win->hWnd, uMsg, wParam, lParam);
}

//NULL, MB_OK | MB_ICONERROR
int nanami_window_MessageBox(nanami_window_t *win, const char *text, const char *title, unsigned style)
{
	return MessageBox(win->hWnd, text, title, style);
}

BOOL nanami_window_ShowWindow(nanami_window_t *win, int cmdShow)
{
	return ShowWindow(win->hWnd, cmdShow);
}

BOOL nanami_window_ScreenToClient(nanami_window_t *win, POINT *point)
{
	return ScreenToClient(win->hWnd, point);
}

BOOL nanami_window_SetMenu(nanami_window_t *win, HMENU hMenu)
{
	return SetMenu(win->hWnd, hMenu);
}

HMENU nanami_window_GetMenu(nanami_window_t *win)
{
	return GetMenu(win->hWnd);
}

BOOL nanami_window_DrawMenuBar(nanami_window_t *win)
{
	return DrawMenuBar(win->hWnd);
}

BOOL nanami_window_SetWindowPos(nanami_window_t *win, HWND hWndIA, int X, int Y, int cx, int cy, UINT uFlags)
{
	return SetWindowPos(win->hWnd, hWndIA, X, Y, cx, cy, uFlags);
}

BOOL nanami_window_GetClientRect(nanami_window_t *win, RECT *rc)
{
	return GetClientRect(win->hWnd, rc);
}

BOOL nanami_window_GetWindowRect(nanami_window_t *win, RECT *rc)
{
	return GetWindowRect(win->hWnd, rc);
}

UINT nanami_window_SetTimer(nanami_window_t *win, UINT idTimer, UINT uTimeout)
{
	return SetTimer(win->hWnd, idTimer, uTimeout, 0);
}

BOOL nanami_window_KillTimer(nanami_window_t *win, UINT idTimer)
{
	return KillTimer(win->hWnd, idTimer);
}

BOOL nanami_window_InvalidateRect(nanami_window_t *win, CONST RECT *lpRect, BOOL bErase)
{
	return InvalidateRect(win->hWnd, lpRect, bErase);
}

BOOL nanami_window_UpdateWindow(nanami_window_t *win)
{
	return UpdateWindow(win->hWnd);
}

HWND nanami_window_SetFocus(nanami_window_t *win)
{
	return SetFocus(win->hWnd);
}

//-------------------------------------
//d3dwin
#ifndef NO_D3D_DEFINED

int nanami_d3dwin_BackBufferWidth(nanami_window_t *win)
{ 
	return win->d3dppApp.BackBufferWidth; 
}

int nanami_d3dwin_BackBufferHeight(nanami_window_t *win)
{ 
	return win->d3dppApp.BackBufferHeight; 
}

BOOL nanami_d3dwin_PreCreateWindow(nanami_window_t *win, CREATESTRUCT *cs)
{
	RECT rect;
	RECT rcArea;
	int width, height, x, y; 

	cs->dwExStyle = WS_EX_CLIENTEDGE;
	cs->style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
	rect.left = 0;
	rect.top = 0;
	rect.right = 640;
	rect.bottom = 480;
	AdjustWindowRectEx(&rect, cs->style, TRUE, cs->dwExStyle);
	width = nanami_rect_Width(&rect);
	height = nanami_rect_Height(&rect);

	SystemParametersInfo(SPI_GETWORKAREA, 0, &rcArea, 0);
	x = rcArea.left + (nanami_rect_Width(&rcArea) - width) / 2;
	y = rcArea.top + (nanami_rect_Height(&rcArea) - height) / 2;
	cs->x = x;
	cs->y = y;
	cs->cx = width;
	cs->cy = height;
	cs->lpszClass = "D3DWindow";
	if (!nanami_app_RegisterWndClass(nanami_app_Application, cs->lpszClass,
		CS_VREDRAW | CS_HREDRAW | CS_OWNDC, LoadCursor(NULL, IDC_ARROW),
		(HBRUSH)GetStockObject(BLACK_BRUSH), nanami_app_LoadIcon_id(nanami_app_Application, IDC_APPICON)))
		return FALSE;
	return TRUE;
}

LRESULT nanami_d3dwin_WindowProc(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) 
	{
	case WM_ERASEBKGND:
		return FALSE;

	case WM_ACTIVATE:
		win->bActive = !((BOOL)HIWORD(wParam));
		break;

	case WM_SIZE:
		if (wParam == SIZE_RESTORED || wParam == SIZE_MAXIMIZED) 
		{
			win->d3dppApp.BackBufferWidth = LOWORD(lParam);
			win->d3dppApp.BackBufferHeight = HIWORD(lParam);
			if (win->pD3DDevice && !win->sizeMoving) 
			{
				nanami_d3dwin_ResetRenderSetting(win);
				win->bUpdateView = TRUE;
			}
		}
		break;

	case WM_ENTERSIZEMOVE:
		win->sizeMoving = TRUE;
		break;

	case WM_EXITSIZEMOVE:
		win->sizeMoving = FALSE;
		if (win->pD3DDevice) 
		{
			nanami_d3dwin_ResetRenderSetting(win);
			win->bUpdateView = TRUE;
		}
		break;

	default:
		return nanami_window_WindowProc(win, uMsg, wParam, lParam);
	}
	return 0L;
}

BOOL nanami_d3dwin_OnCreate(nanami_window_t *win, CREATESTRUCT *cs)
{
#ifndef	FULLSCREEN
	D3DDISPLAYMODE dmode;
#endif

	win->pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	if (win->pD3D == NULL) 
	{
		nanami_window_MessageBox(win, "Direct3D�γ��ڻ���ʧ�����ޤ�����DirectX 9.0�����󥹥ȩ`�뤵��Ƥ��뤫�_�J���Ƥ���������", NULL, MB_OK | MB_ICONERROR);
		return FALSE;
	}
#ifdef	FULLSCREEN
	ZeroMemory(&win->d3dppApp,sizeof(win->d3dppApp));
	win->d3dppApp.BackBufferWidth = 640;
	win->d3dppApp.BackBufferHeight = 480;
	win->d3dppApp.BackBufferFormat = D3DFMT_R5G6B5;
	win->d3dppApp.Windowed = FALSE;
	win->d3dppApp.BackBufferCount = 1;
	win->d3dppApp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	win->d3dppApp.FullScreen_RefreshRateInHz = 60;
	win->d3dppApp.EnableAutoDepthStencil = TRUE;
	win->d3dppApp.AutoDepthStencilFormat= D3DFMT_D16;
#else
	//FIXME:
	//win->pD3D->GetAdapterDisplayMode
	if (FAILED(IDirect3D9_GetAdapterDisplayMode(win->pD3D, D3DADAPTER_DEFAULT, &dmode))) 
	{
		nanami_window_MessageBox(win, "�ǥ����ץ쥤��`�ɤ�ȡ�ä�ʧ�����ޤ�����", NULL,  MB_OK | MB_ICONERROR);
		return FALSE;
	}
	ZeroMemory(&win->d3dppApp, sizeof(win->d3dppApp));
	win->d3dppApp.Windowed = TRUE;
	win->d3dppApp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	win->d3dppApp.BackBufferCount = 1;
	win->d3dppApp.BackBufferFormat = dmode.Format;
	win->d3dppApp.EnableAutoDepthStencil = TRUE;
	win->d3dppApp.AutoDepthStencilFormat= D3DFMT_D16;
#endif
	//pD3D->CreateDevice
	if (FAILED(IDirect3D9_CreateDevice(win->pD3D, D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, win->hWnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &win->d3dppApp, &win->pD3DDevice))) 
	{
		//pD3D->CreateDevice
		if (FAILED(IDirect3D9_CreateDevice(win->pD3D, D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, win->hWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &win->d3dppApp, &win->pD3DDevice))) 
		{
			nanami_window_MessageBox(win, "�ǥХ��������ɤ�ʧ�����ޤ����������`�ɤ�16�ӥåȤ��뤤��32�ӥåȤˤʤäƤ��뤳�Ȥ�_�J���Ƥ���������", NULL, MB_OK | MB_ICONERROR);
			return FALSE;
		}
	}
	if (!nanami_d3dwin_RenderSetting(win))
		return FALSE;
	nanami_timer_Reset(&win->Timer);
	nanami_timer_Start(&win->Timer);
	return TRUE;
}

void nanami_d3dwin_OnDestroy(nanami_window_t *win)
{
	if (win->pD3D)
	{
		IDirect3D9_Release(win->pD3D);
		win->pD3D = 0;
	}
	if (win->pD3DDevice) 
	{
		IDirect3DDevice9_Release(win->pD3DDevice);
		win->pD3DDevice = 0;
	}
	nanami_window_OnDestroy(win);
}

BOOL nanami_d3dwin_RenderSetting(nanami_window_t *win)
{
	return TRUE;
}

BOOL nanami_d3dwin_ResetRenderSetting(nanami_window_t *win)
{
	IDirect3DDevice9_Reset(win->pD3DDevice, &win->d3dppApp);
	return nanami_d3dwin_RenderSetting(win);
}

BOOL nanami_d3dwin_OnIdle(nanami_window_t *win, long count)
{
	float AppTime = nanami_timer_GetAppTime(&win->Timer);
	float ElapsedTime = nanami_timer_GetElapsedTime(&win->Timer);

	if (ElapsedTime == 0.0f)
		return TRUE;
	nanami_d3dwin_FrameMove(win, AppTime, ElapsedTime);
	if (win->pD3D && win->pD3DDevice) 
	{
		IDirect3DDevice9_Clear(win->pD3DDevice, 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 255), 1.0, 0);
		if (SUCCEEDED(IDirect3DDevice9_BeginScene(win->pD3DDevice))) 
		{
			nanami_d3dwin_Render(win);
			IDirect3DDevice9_EndScene(win->pD3DDevice);
		}
		IDirect3DDevice9_Present(win->pD3DDevice, NULL, NULL, NULL, NULL);
	}
	return TRUE;
}

BOOL nanami_d3dwin_FrameMove(nanami_window_t *win, float AppTime, float ElapsedTime)
{
	return TRUE;
}

BOOL nanami_d3dwin_Render(nanami_window_t *win)
{
	return TRUE;
}

#endif // NO_D3D_DEFINED

