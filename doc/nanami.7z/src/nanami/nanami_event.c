#include "nanami_common.h"
#include "nanami_event.h"

struct nanami_event_SEventTable 
{
	int code;
	char *text;
};

static struct nanami_event_SEventTable EventTable[] = {
	{ NANAMI_EVENT_PLAYERTALK, "����ˤ���" },
	{ NANAMI_EVENT_NPCTALK, "�ʤ���ä���" },
	{ NANAMI_EVENT_PLAYERTALK, "����������������" },
	{ NANAMI_EVENT_PLAYERTALK, "�ޤ�ޤ뤦�ޤ���" },
	{ NANAMI_EVENT_NPCTALK, "����ʤ�Τ�֪���" },
	{ NANAMI_EVENT_END, NULL },
} ;

static void nanami_event_init(nanami_event_t *ev)
{
	ev->LastBtn = FALSE;
	ev->Count = -1;
}

nanami_event_t *nanami_event_new()
{
	nanami_event_t *ev = (nanami_event_t *)malloc(sizeof(nanami_event_t));
	nanami_event_init(ev);
	return ev;
}

// �ǥ��ȥ饯��
void nanami_event_free(nanami_event_t *ev)
{
	free(ev);
}

int nanami_event_GetAction(nanami_event_t *ev, BOOL btn)
{
	if (ev->Count < 0) 
	{
		ev->Count = 0;
	}
	else if (btn && !ev->LastBtn) 
	{
		ev->Count++;
	}
	ev->LastBtn = btn;
	return EventTable[ev->Count].code;
}

const char *nanami_event_GetText(nanami_event_t *ev)
{
	return EventTable[ev->Count].text;
}

nanami_event_t *nanami_event_mgr_GetEvent(int no)
{
	return nanami_event_new();
}
