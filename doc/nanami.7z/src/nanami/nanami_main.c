#include "nanami_common.h"

#include <windows.h>
#include <locale.h>
#include "nanami_app.h"
#include "nanami_misc.h"
#include "nanami_main.h"
#include "nanami_window.h"
#include "resource.h"

static nanami_window_t *nanami_sampleapp_MainWin = NULL;

static BOOL nanami_sampleapp_InitInstance(nanami_app_t *app)
{
	if (!nanami_window_Create_menu(nanami_sampleapp_MainWin, app, "Sample", nanami_app_LoadMenu_id(app, IDC_APPMENU), NULL))
	{
		return FALSE;
	}
	app->MainWnd = nanami_sampleapp_MainWin;
	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR CmdLine, int CmdShow)
{
	nanami_app_t *app;
	int ret;

	app = nanami_app_new();
	nanami_sampleapp_MainWin = nanami_window_new();

	app->InitInstance = nanami_sampleapp_InitInstance;
#if defined(_MSC_VER) && defined(_DEBUG)
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	if (nanami_app_Application == NULL) 
	{
		TRACE("CWinApp �����h����Ƥ��ʤ���\n");
		
		nanami_window_free(nanami_sampleapp_MainWin);
		nanami_app_free(app);
		
		return -1;
	}
	nanami_app_SetWinMainArgs(nanami_app_Application, hInstance, CmdLine, CmdShow);
	if (!nanami_app_Application->InitInstance(nanami_app_Application))
	{
		nanami_window_free(nanami_sampleapp_MainWin);
		nanami_app_free(app);
		
		return -1;
	}
	ret = nanami_app_Run(nanami_app_Application);
	
	nanami_window_free(nanami_sampleapp_MainWin);
	nanami_app_free(app);
	
	return ret; 
}

