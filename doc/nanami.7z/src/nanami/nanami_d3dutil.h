#ifndef	__D3DUTIL_H__
#define	__D3DUTIL_H__

#include <d3d9.h>
#include <d3dx9.h>

//#pragma comment(lib, "d3d9.lib")
//#pragma comment(lib, "d3dx9.lib")

typedef struct nanami_d3dvertex_struct {
	float x, y, z;
	float nx, ny, nz;
	float tu0, tv0;
} nanami_d3dvertex_t;

extern void nanami_d3dvertex_init(nanami_d3dvertex_t *vt, float _x, float _y, float _z, float _nx, float _ny, float _nz, float _tu0, float _tv0);
extern void nanami_d3dvertex_Set(nanami_d3dvertex_t *vt, float _x, float _y, float _z, float _nx, float _ny, float _nz, float _tu0, float _tv0);

#define NANAMI_D3DVERTEX_FVF = (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)

struct D3DLVERTEX {
	float x, y, z;
	DWORD color;
	float tu0, tv0;
} ;

#define NANAMI_D3DLVERTEX_FVF (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1)

struct D3DTLVERTEX {
	float x, y, z;
	float rhw;
	DWORD color;
	float tu0, tv0;
} ;

#define NANAMI_D3DTLVERTEX_FVF (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);

typedef struct nanami_camera_struct {
	D3DXMATRIX ViewMat;
	D3DXMATRIX PersMat;
	D3DXVECTOR3 ViewFrom;
	D3DXVECTOR3 ViewTo;
	D3DXVECTOR3 ViewUp;
	float FOV;
	float Aspect;
	float NearPlane;
	float FarPlane;
} nanami_camera_t;

extern void SetViewParams_1(nanami_camera_t *cam, float rot_x, float rot_y, float dist, D3DXVECTOR3 *lookat);
extern void SetViewParams_2(nanami_camera_t *cam, D3DXVECTOR3 *eye, D3DXVECTOR3 *lookat);
extern void SetProjParams(nanami_camera_t *cam, float fov, float aspect, float nz, float fz);
extern void GetViewRotation(nanami_camera_t *cam, float *yaw, float *pitch);

extern void GetViewDistance(nanami_camera_t *cam, D3DXVECTOR3 *v);
extern float CalcDistance(nanami_camera_t *cam, const D3DXVECTOR3 *v);

extern void SetMaterial_1(D3DMATERIAL9 *material, float r, float g, float b);
extern void SetMaterial_2(D3DMATERIAL9 *material, float r, float g, float b, float a);
extern void SetDirectionalLight(D3DLIGHT9 *light, float r, float g, float b, const D3DXVECTOR3 dir);

#endif
