#ifndef	__NANAMI_DIALOG_H__
#define	__NANAMI_DIALOG_H__

typedef struct nanami_dialog_struct {
	HWND hDlg;
} nanami_dialog_t;

extern int nanami_dialog_DoModal(nanami_dialog_t *dlg, UINT idRes, HWND hParent);
extern HWND nanami_dialog_DoModeless(nanami_dialog_t *dlg, UINT idRes, HWND hParent);
extern BOOL nanami_dialog_IsDialogMessage(nanami_dialog_t *dlg, LPMSG lpmsg);
extern LONG nanami_dialog_SendDlgItemMessage(nanami_dialog_t *dlg, int nIDDlgItem, UINT Msg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_dialog_CheckRadioButton(nanami_dialog_t *dlg, int nIDFirstButton, int nIDLastButton, int nIDCheckButton);
extern void nanami_dialog_Show(nanami_dialog_t *dlg, BOOL flag);
extern HWND nanami_dialog_GetDlgItem(nanami_dialog_t *dlg, int id);
extern BOOL nanami_dialog_SetDlgItemText(nanami_dialog_t *dlg, int id, const char *str);
extern void nanami_dialog_CenterWindow(nanami_dialog_t *dlg);

//protected:
extern BOOL CALLBACK nanami_dialog_DlgProc_2(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_dialog_DlgProc(nanami_dialog_t *dlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif //__NANAMI_DIALOG_H__
