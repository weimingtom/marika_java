#ifndef	__NANAMI_MISC_H__
#define	__NANAMI_MISC_H__

#include <windows.h>
#include <mbctype.h>

#ifndef	_MAX_PATH
#define	_MAX_PATH	260
#endif //_MAX_PATH

#define	UC(c)	(unsigned char)(c)

typedef	unsigned char	byte_t;

#define WhitePixel (RGB(255, 255, 255))
#define BlackPixel (RGB(0, 0, 0))
#define GrayPixel (RGB(128, 128, 192))
#define RedPixel (RGB(255, 96, 96))

BOOL FullPath(char *path, const char *file);

#ifndef __MINGW32__
__inline int Rand(int fact) { return rand() % fact; }
#else
static __inline int Rand(int fact) { return rand() % fact; }
#endif

#ifdef _DEBUG

void __cdecl DebugPrintf(const char *fmt, ...);
#define	TRACE DebugPrintf

extern BOOL AssertFailed(const char *expr, const char *file, unsigned line);

#if 0

#define	ASSERT(exp)	\
	do \
		if (!(exp) && AssertFailed(#exp, __FILE__, __LINE__)) \
			DebugBreak(); \
	while (0)

#endif //__BOLANDC__

#else //_DEBUG

#ifndef __MINGW32__
__inline void __cdecl DebugPrintf(const char *fmt, ...) { }
#else
static __inline void __cdecl DebugPrintf(const char *fmt, ...) { }
#endif

#define	TRACE 1? (void)0: DebugPrintf

#define ASSERT(exp)	(void)(0)

#endif //_DEBUG

#pragma warning(disable: 4127)

#endif //__NANAMI_MISC_H__
