#ifndef __NANAMI_TIMER_H__
#define __NANAMI_TIMER_H__

typedef struct nanami_timer_struct {
	BOOL		bUsingQPF;
	BOOL		bTimerStopped;
	LONGLONG	StopTime;
	LONGLONG	TicksPerSec;
	LONGLONG	LastElapsedTime;
	LONGLONG	BaseTime;
    DWORD		PausedCount;
	double		InvTicksPerSec;
} nanami_timer_t;

extern float nanami_timer_PeekElapsedTime(nanami_timer_t *timer);
extern float nanami_timer_GetElapsedTime(nanami_timer_t *timer);
extern float nanami_timer_GetAppTime(nanami_timer_t *timer);
extern float nanami_timer_GetAbsoluteTime(nanami_timer_t *timer);
extern void nanami_timer_Reset(nanami_timer_t *timer);
extern void nanami_timer_Start(nanami_timer_t *timer);
extern void nanami_timer_Stop(nanami_timer_t *timer);
extern void nanami_timer_Pause(nanami_timer_t *timer);
extern void nanami_timer_Resume(nanami_timer_t *timer);

extern LONGLONG nanami_timer_GetSystemTimer(nanami_timer_t *timer, BOOL real_time);

#endif //__NANAMI_TIMER_H__
