#ifndef __NANAMI_WINDOW_h__
#define __NANAMI_WINDOW_h__

#include <windows.h>
#ifndef NO_D3D_DEFINED
//CD3DWin
#include <d3d9.h>
#include <d3dx9.h>
#include "nanami_timer.h"
#endif

struct nanami_app_struct;
struct nanami_window_struct;

struct nanami_timer_struct;

typedef struct nanami_window_struct {
	struct nanami_app_struct *App;
	HWND hWnd;
	UINT LastMsg;
	WPARAM LastWParam;
	LPARAM LastLParam;
	HACCEL hAccelTable;
	struct nanami_window_struct *Next;

	//virtual 
	BOOL (*PreTranslateMessage)(struct nanami_window_struct *win, MSG *msg);
	LRESULT (*WindowProc)(struct nanami_window_struct *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
	void (*OnCommand)(struct nanami_window_struct *win, UINT notifyCode, UINT id, HWND ctrl);
	void (*OnInitSubMenu)(struct nanami_window_struct *win, HMENU hMenu, UINT id);
	BOOL (*OnIdle)(struct nanami_window_struct *win, long count);
	BOOL (*PreCreateWindow)(struct nanami_window_struct *win, CREATESTRUCT *cs);
	BOOL (*OnCreate)(struct nanami_window_struct *win, CREATESTRUCT *cs);
	void (*OnPaint)(struct nanami_window_struct *win);
	void (*OnDestroy)(struct nanami_window_struct *win);
	void (*OnInitMenuPopup)(struct nanami_window_struct *win, HMENU hMenu, UINT pos, BOOL sysMenu);
#ifndef NO_D3D_DEFINED
	//CD3DWin
	LPDIRECT3D9 pD3D;
	LPDIRECT3DDEVICE9 pD3DDevice;
	D3DPRESENT_PARAMETERS d3dppApp;
	struct nanami_timer_struct Timer;
	BOOL bActive;
	BOOL sizeMoving;
	BOOL bUpdateView;
#endif
} nanami_window_t;

//public:

extern nanami_window_t *nanami_window_new(void);
extern void nanami_window_free(nanami_window_t *win);

//public:


extern BOOL nanami_window_ShowWindow(nanami_window_t *win, int cmdShow);
extern BOOL nanami_window_PreTranslateMessage(nanami_window_t *win, MSG *msg);
extern LRESULT nanami_window_WindowProc(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern void nanami_window_OnCommand(nanami_window_t *win, UINT notifyCode, UINT id, HWND ctrl);
extern void nanami_window_OnInitSubMenu(nanami_window_t *win, HMENU hMenu, UINT id);
extern int nanami_window_MessageBox(nanami_window_t *win, const char *str, const char *title, unsigned sty);
extern LRESULT nanami_window_SendMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_window_PostMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_window_ScreenToClient(nanami_window_t *win, POINT *point);
extern BOOL nanami_window_SetMenu(nanami_window_t *win, HMENU hMenu);
extern HMENU nanami_window_GetMenu(nanami_window_t *win);
extern BOOL nanami_window_DrawMenuBar(nanami_window_t *win);
extern BOOL nanami_window_SetWindowPos(nanami_window_t *win, HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags);
extern BOOL nanami_window_GetClientRect(nanami_window_t *win, RECT *rc);
extern BOOL nanami_window_GetWindowRect(nanami_window_t *win, RECT *rc);
extern UINT nanami_window_SetTimer(nanami_window_t *win, UINT idTimer, UINT uTimeout);
extern BOOL nanami_window_KillTimer(nanami_window_t *win, UINT idTimer);
extern BOOL nanami_window_InvalidateRect(nanami_window_t *win, CONST RECT *lpRect, BOOL bErase);
extern BOOL nanami_window_UpdateWindow(nanami_window_t *win);
extern HWND nanami_window_SetFocus(nanami_window_t *win);
extern BOOL nanami_window_OnIdle(nanami_window_t *win, long count);
extern BOOL nanami_window_AddWindowList(nanami_window_t *win, HWND hWndNew);
extern HWND nanami_window_DeleteWindowList(nanami_window_t *win);

//protected:

extern void nanami_window_SetLastParam(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_window_PreCreateWindow(nanami_window_t *win, CREATESTRUCT *cs);
extern BOOL nanami_window_OnCreate(nanami_window_t *win, CREATESTRUCT *cs);
extern void nanami_window_OnPaint(nanami_window_t *win);
extern void nanami_window_OnDestroy(nanami_window_t *win);
extern void nanami_window_OnInitMenuPopup(nanami_window_t *win, HMENU hMenu, UINT pos, BOOL sysMenu);
extern LRESULT nanami_window_Default(nanami_window_t *win);
extern void nanami_window_SetLastParam(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);

extern BOOL nanami_window_Create_menu(nanami_window_t *win, struct nanami_app_struct *app, const char *name, HMENU hMenu, nanami_window_t *parent);
extern BOOL nanami_window_Create(nanami_window_t *win, struct nanami_app_struct *app, const char *name, nanami_window_t *parent);

extern LRESULT nanami_window_Default(nanami_window_t *win);
extern LRESULT nanami_window_SendMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern BOOL nanami_window_PostMessage(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern int nanami_window_MessageBox(nanami_window_t *win, const char *text, const char *title, unsigned style);
extern BOOL nanami_window_ShowWindow(nanami_window_t *win, int cmdShow);
extern BOOL nanami_window_ScreenToClient(nanami_window_t *win, POINT *point);
extern BOOL nanami_window_SetMenu(nanami_window_t *win, HMENU hMenu);
extern HMENU nanami_window_GetMenu(nanami_window_t *win);
extern BOOL nanami_window_DrawMenuBar(nanami_window_t *win);
extern BOOL nanami_window_SetWindowPos(nanami_window_t *win, HWND hWndIA, int X, int Y, int cx, int cy, UINT uFlags);
extern BOOL nanami_window_GetClientRect(nanami_window_t *win, RECT *rc);
extern BOOL nanami_window_GetWindowRect(nanami_window_t *win, RECT *rc);
extern UINT nanami_window_SetTimer(nanami_window_t *win, UINT idTimer, UINT uTimeout);
extern BOOL nanami_window_KillTimer(nanami_window_t *win, UINT idTimer);
extern BOOL nanami_window_InvalidateRect(nanami_window_t *win, CONST RECT *lpRect, BOOL bErase);
extern BOOL nanami_window_UpdateWindow(nanami_window_t *win);
extern HWND nanami_window_SetFocus(nanami_window_t *win);

//static public:
extern LRESULT CALLBACK nanami_window_WindowProc_2(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
extern nanami_window_t *nanami_window_GetWindow(HWND hwnd);
extern nanami_window_t *nanami_window_WindowListTop;
extern nanami_window_t *nanami_window_WindowInitPtr;


extern BOOL nanami_window_LoadAccelTable_name(nanami_window_t *win, const char *name);
extern BOOL nanami_window_LoadAccelTable_id(nanami_window_t *win, int resId);


//---------------------------

//d3dwin

#ifndef NO_D3D_DEFINED
extern LRESULT nanami_d3dwin_WindowProc(nanami_window_t *win, UINT uMsg, WPARAM wParam, LPARAM lParam);

//protected:
extern BOOL nanami_d3dwin_PreCreateWindow(nanami_window_t *win, CREATESTRUCT *cs);
extern BOOL nanami_d3dwin_OnCreate(nanami_window_t *win, CREATESTRUCT *cs);
extern void nanami_d3dwin_OnDestroy(nanami_window_t *win);
extern BOOL nanami_d3dwin_OnIdle(nanami_window_t *win, long count);
extern BOOL nanami_d3dwin_FrameMove(nanami_window_t *win, float AppTime, float ElapsedTime);
extern BOOL nanami_d3dwin_Render(nanami_window_t *win);
extern BOOL nanami_d3dwin_RenderSetting(nanami_window_t *win);
extern int nanami_d3dwin_BackBufferWidth(nanami_window_t *win);
extern int nanami_d3dwin_BackBufferHeight(nanami_window_t *win);

//private
extern BOOL nanami_d3dwin_ResetRenderSetting(nanami_window_t *win);

#endif

#endif //__NANAMI_WINDOW_h__
