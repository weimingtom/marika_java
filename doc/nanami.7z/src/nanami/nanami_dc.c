#include "nanami_common.h"
#include "nanami_window.h"
#include "nanami_misc.h"
#include "nanami_dc.h"

void nanami_dc_free(nanami_dc_t *dc) 
{
	free(dc);
}

HBITMAP nanami_dc_SelectObject_bitmap(nanami_dc_t *dc, HBITMAP hBitmap)
{
	return (HBITMAP)SelectObject(dc->hDC, hBitmap);
}

HFONT nanami_dc_SelectObject_font(nanami_dc_t *dc, HFONT hFont)
{
	return (HFONT)SelectObject(dc->hDC, hFont);
}

int nanami_dc_GetDIBits(nanami_dc_t *dc, HBITMAP hbmp, UINT uStartScan, UINT cScanLines, LPVOID lpvBits, LPBITMAPINFO lpbi, UINT uUsage)
{
	return GetDIBits(dc->hDC, hbmp, uStartScan, cScanLines, lpvBits, lpbi, uUsage);
}

BOOL nanami_dc_GetTextExtentPoint32(nanami_dc_t *dc, LPCTSTR lpsz, int cbString, LPSIZE lpSize)
{
	return GetTextExtentPoint32(dc->hDC, lpsz, cbString, lpSize);
}

BOOL nanami_dc_ExtTextOut(nanami_dc_t *dc, int X, int Y, UINT fuOptions, CONST RECT *lprc, LPCTSTR lpszString, UINT cbCount, CONST INT *lpDx)
{
	return ExtTextOut(dc->hDC, X, Y, fuOptions, lprc, lpszString, cbCount, lpDx);
}

COLORREF nanami_dc_SetTextColor(nanami_dc_t *dc, COLORREF crColor)
{
	return SetTextColor(dc->hDC, crColor);
}

COLORREF nanami_dc_SetBkColor(nanami_dc_t *dc, COLORREF crColor)
{
	return SetBkColor(dc->hDC, crColor);
}

int nanami_dc_SetBkMode(nanami_dc_t *dc, int bkMode)
{
	return SetBkMode(dc->hDC, bkMode);
}

int nanami_dc_GetDeviceCaps(nanami_dc_t *dc, int nIndex)
{
	return GetDeviceCaps(dc->hDC, nIndex);
}


// --------------------------


nanami_dc_t *nanami_client_dc_new(nanami_window_t *win)
{
	nanami_dc_t *dc = (nanami_dc_t *)malloc(sizeof(nanami_dc_t));
	dc->hWnd = win->hWnd;
	dc->hDC = GetDC(dc->hWnd);
	return dc;
}

void nanami_client_dc_free(nanami_dc_t *dc)
{
	ReleaseDC(dc->hWnd, dc->hDC);
	free(dc);
}

nanami_dc_t *nanami_paint_dc_new(nanami_window_t *win)
{
	nanami_dc_t *dc = (nanami_dc_t *)malloc(sizeof(nanami_dc_t));
	dc->hWnd = win->hWnd;
	dc->hDC = BeginPaint(dc->hWnd, &dc->ps);
	return dc;
}

void nanami_paint_dc_free(nanami_dc_t *dc)
{
	EndPaint(dc->hWnd, &dc->ps);
	free(dc);
}

nanami_dc_t *nanami_memory_dc_new(HDC hdc)
{
	nanami_dc_t *dc = (nanami_dc_t *)malloc(sizeof(nanami_dc_t));
	dc->hDC = CreateCompatibleDC(hdc);
	return dc;
}

void nanami_memory_dc_free(nanami_dc_t *dc)
{
	DeleteDC(dc->hDC);
	free(dc);
}

nanami_dc_t *nanami_screen_dc_new()
{
	nanami_dc_t *dc = (nanami_dc_t *)malloc(sizeof(nanami_dc_t));
	dc->hDC = GetDC(NULL);
	return dc;
}

void nanami_screen_dc_free(nanami_dc_t *dc)
{
	ReleaseDC(NULL, dc->hDC);
	free(dc);
}
