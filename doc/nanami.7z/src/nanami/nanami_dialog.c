#include "nanami_common.h"
#include "nanami_app.h"
#include "nanami_dialog.h"
#include "nanami_geometry.h"

BOOL nanami_dialog_DlgProc(nanami_dialog_t *dlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return FALSE;
}

BOOL CALLBACK nanami_dialog_DlgProc_2(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	nanami_dialog_t *pThis;
	
	pThis = (nanami_dialog_t *)GetWindowLong(hDlg, DWL_USER);
	if (uMsg == WM_INITDIALOG) 
	{
		pThis = (nanami_dialog_t *)lParam;
		pThis->hDlg = hDlg;
		SetWindowLong(hDlg, DWL_USER, lParam);
	}
	else if (!pThis) 
	{
		return FALSE;
	}
	//FIXME:
	return nanami_dialog_DlgProc(pThis, uMsg, wParam, lParam);
}

int nanami_dialog_DoModal(nanami_dialog_t *dlg, UINT id, HWND hParent)
{
	return DialogBoxParam(nanami_app_Application->Instance, MAKEINTRESOURCE(id), hParent, nanami_dialog_DlgProc_2, (LPARAM)dlg);
}

HWND nanami_dialog_DoModeless(nanami_dialog_t *dlg, UINT id, HWND hParent)
{
	return CreateDialogParam(nanami_app_Application->Instance, MAKEINTRESOURCE(id), hParent, nanami_dialog_DlgProc_2, (LPARAM)dlg);
}

void nanami_dialog_CenterWindow(nanami_dialog_t *dlg)
{
	HWND hParent;
	RECT rectParent, rectWindow;
	POINT pt;
	int	width, height;

	hParent = GetParent(dlg->hDlg);
	GetWindowRect(dlg->hDlg, &rectWindow);
	GetClientRect(hParent, &rectParent);
	nanami_point_init_1(&pt, nanami_rect_Width(&rectParent) / 2, nanami_rect_Height(&rectParent) / 2);
	ClientToScreen(hParent, &pt);
	width = nanami_rect_Width(&rectWindow);
	height = nanami_rect_Height(&rectWindow);
	pt.x -= width / 2;
	pt.y -= height / 2;
	MoveWindow(dlg->hDlg, pt.x, pt.y, width, height, FALSE);
}

BOOL nanami_dialog_IsDialogMessage(nanami_dialog_t *dlg, LPMSG lpmsg)
{
	return dlg->hDlg? IsDialogMessage(dlg->hDlg, lpmsg): FALSE;
}

LONG nanami_dialog_SendDlgItemMessage(nanami_dialog_t *dlg, int nID, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	return SendDlgItemMessage(dlg->hDlg, nID, Msg, wParam, lParam);
}

BOOL nanami_dialog_CheckRadioButton(nanami_dialog_t *dlg, int nIDFirst, int nIDLast, int nIDCheck)
{
	return CheckRadioButton(dlg->hDlg, nIDFirst, nIDLast, nIDCheck);
}

void nanami_dialog_Show(nanami_dialog_t *dlg, BOOL flag)
{
	ShowWindow(dlg->hDlg, flag? SW_SHOW: SW_HIDE);
}

HWND nanami_dialog_GetDlgItem(nanami_dialog_t *dlg, int id)
{
	return GetDlgItem(dlg->hDlg, id);
}

BOOL nanami_dialog_SetDlgItemText(nanami_dialog_t *dlg, int id, const char *str)
{
	return SetDlgItemText(dlg->hDlg, id, str);
}
