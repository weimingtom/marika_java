#include "nanami_common.h"
#include <windows.h>
#include <locale.h>
#include "nanami_app.h"
#include "nanami_misc.h"
#include "nanami_window.h"

nanami_app_t *nanami_app_Application;

nanami_app_t *nanami_app_new()
{
	nanami_app_t *app = (nanami_app_t *)malloc(sizeof(nanami_app_t));
#ifdef	_DEBUG
	if (nanami_app_Application != NULL) 
	{
		TRACE("CWinApp �������ص��h����Ƥ��ޤ���\n");
	}
#endif
	app->Instance = NULL;
	app->CmdLine = NULL;
	app->CmdShow = 0;
	nanami_app_Application = app;
	app->msgCur.message = WM_NULL;
	app->MainWnd = NULL;
	app->InitInstance = nanami_app_InitInstance;
	return app;
}

void nanami_app_free(nanami_app_t *app)
{
	nanami_app_Application = NULL;
	free(app);
}

BOOL nanami_app_InitInstance(nanami_app_t *app)
{
	return TRUE;
}

BOOL nanami_app_OnIdle(nanami_app_t *app, long count)
{
	//FIXME:
	//return app->MainWnd && nanami_window_OnIdle(app->MainWnd, count);
	return app->MainWnd && app->MainWnd->OnIdle(app->MainWnd, count);
}

int nanami_app_Run(nanami_app_t *app)
{
	BOOL idle = TRUE;
	long count = 0;
	if (app->MainWnd)
	{
		nanami_window_ShowWindow(app->MainWnd, app->CmdShow);
	}
	for (;;) 
	{
		if (PeekMessage(&app->msgCur, NULL, 0, 0, PM_NOREMOVE)) 
		{
			if (!GetMessage(&app->msgCur, NULL, 0, 0))
			{
				return app->msgCur.wParam;
			}
			if (!nanami_app_PreTranslateMessage(app, &app->msgCur)) 
			{
				TranslateMessage(&app->msgCur);
				DispatchMessage(&app->msgCur);
			}
			idle = TRUE;
			count = 0;
		}
		else if (idle) 
		{
			if (!nanami_app_OnIdle(app, count++))
			{
				idle = FALSE;
			}
		}
		else 
		{
			WaitMessage();
		}
	}
}

BOOL nanami_app_PreTranslateMessage(nanami_app_t *app, MSG *msg)
{
	//return nanami_window_PreTranslateMessage(app->MainWnd, msg);
	return app->MainWnd->PreTranslateMessage(app->MainWnd, msg);
}

BOOL nanami_app_RegisterWndClass(nanami_app_t *app, const char *name, UINT classStyle, HCURSOR hCursor, HBRUSH hbrBackground, HICON hIcon)
{
	WNDCLASS wndclass;
	if (!GetClassInfo(app->Instance, name, &wndclass)) 
	{
		wndclass.style = classStyle;
		wndclass.lpfnWndProc = nanami_window_WindowProc_2;
		wndclass.cbClsExtra = 0;
		wndclass.cbWndExtra = 0;
		wndclass.hInstance = app->Instance;
		wndclass.hIcon = hIcon;
		wndclass.hCursor = hCursor;
		wndclass.hbrBackground = hbrBackground;
		wndclass.lpszMenuName = 0;
		wndclass.lpszClassName = name;
		if (!RegisterClass(&wndclass)) 
		{
			TRACE("Can't register window class [%s]\n", name);
			return FALSE;
		}
	}
	return TRUE;
}

void nanami_app_SetWinMainArgs(nanami_app_t *app, HINSTANCE hInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	app->Instance = hInstance;
	app->CmdLine = lpszCmdLine;
	app->CmdShow = nCmdShow;
}

HRSRC nanami_app_FindResource(nanami_app_t *app, const char *name, const char *type)
{
	return FindResource(app->Instance, name, type);
}

HGLOBAL nanami_app_LoadResource(nanami_app_t *app, HRSRC hres)
{
	return LoadResource(app->Instance, hres);
}

HACCEL nanami_app_LoadAccelerators(nanami_app_t *app, const char *name)
{
	return LoadAccelerators(app->Instance, name);
}

HMENU nanami_app_LoadMenu_name(nanami_app_t *app, const char *name)
{
	return LoadMenu(app->Instance, name);
}

HMENU nanami_app_LoadMenu_id(nanami_app_t *app, int resId)
{
	return LoadMenu(app->Instance, MAKEINTRESOURCE(resId));
}

HICON nanami_app_LoadIcon_name(nanami_app_t *app, const char *name)
{
	return LoadIcon(app->Instance, name);
}

HICON nanami_app_LoadIcon_id(nanami_app_t *app, int resId)
{
	return LoadIcon(app->Instance, MAKEINTRESOURCE(resId));
}

HINSTANCE nanami_app_GetInstance(nanami_app_t* app) 
{
	return app->Instance; 
}

nanami_window_t *nanami_app_GetMainWnd(nanami_app_t* app) 
{ 
	return app->MainWnd; 
}




