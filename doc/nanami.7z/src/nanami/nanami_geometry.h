#ifndef __NANAMI_GEOMTRY_H__
#define __NANAMI_GEOMTRY_H__

#include <windows.h>

extern void nanami_size_init(SIZE *sz);
extern void nanami_size_init_1(SIZE *sz, int _cx, int _cy);
extern void nanami_size_init_2(SIZE *sz, SIZE size);
extern void nanami_size_init_3(SIZE *sz, DWORD size);
extern BOOL nanami_size_equal(SIZE *sz, SIZE size);
extern BOOL nanami_size_not_equal(SIZE *sz, SIZE size);
extern void nanami_size_inc(SIZE *sz, SIZE size);
extern void nanami_size_dec(SIZE *sz, SIZE size);
extern SIZE nanami_size_add(SIZE *sz, SIZE size);
extern SIZE nanami_size_minus(SIZE *sz, SIZE size);
extern SIZE nanami_size_neg(SIZE *sz);

extern void nanami_point_init(POINT *pt);
extern void nanami_point_init_1(POINT *pt, int _x, int _y);
extern void nanami_point_init_2(POINT *pt, POINT point);
extern void nanami_point_init_3(POINT *pt, DWORD point);
extern void nanami_point_Offset_1(POINT *pt, int offx, int offy);
extern void nanami_point_Offset_2(POINT *pt, POINT point);
extern void nanami_point_Offset_3(POINT *pt, SIZE size);
extern BOOL nanami_point_equal(POINT *pt, POINT point);
extern BOOL nanami_point_not_equal(POINT *pt, POINT point);
extern void nanami_point_inc_1(POINT *pt, SIZE size);
extern void nanami_point_dec_1(POINT *pt, SIZE size);
extern void nanami_point_inc_2(POINT *pt, POINT point);
extern void nanami_point_dec_2(POINT *pt, POINT point);
extern POINT nanami_point_plus_1(POINT *pt, SIZE size);
extern POINT nanami_point_minus_1(POINT *pt, SIZE size);
extern POINT nanami_point_neg(POINT *pt);
extern POINT nanami_point_plus_2(POINT *pt, POINT point);
extern POINT nanami_point_minus_2(POINT *pt, POINT point);


extern void nanami_rect_init(RECT *rc);
extern void nanami_rect_init_1(RECT *rc, int x1, int y1, int x2, int y2);
extern void nanami_rect_init_2(RECT *rc, const RECT rect);
extern int nanami_rect_Width(RECT *rc);
extern int nanami_rect_Height(RECT *rc);
extern SIZE nanami_rect_Size(RECT *rc);
extern POINT *nanami_rect_TopLeft_1(RECT *rc);
extern POINT *nanami_rect_BottomRight_1(RECT *rc);
extern BOOL nanami_rect_IsRectEmpty(RECT *rc);
extern BOOL nanami_rect_IsRectNull(RECT *rc);
extern BOOL nanami_rect_PtInRect(RECT *rc, POINT point);
extern void nanami_rect_SetRect(RECT *rc, int x1, int y1, int x2, int y2);
extern void nanami_rect_SetRectEmpty(RECT *rc);
extern void nanami_rect_InflateRect_1(RECT *rc, int x, int y);
extern void nanami_rect_InflateRect_2(RECT *rc, SIZE size);
extern void nanami_rect_OffsetRect_1(RECT *rc, int x, int y);
extern void nanami_rect_OffsetRect_2(RECT *rc, SIZE size);
extern void nanami_rect_OffsetRect_3(RECT *rc, POINT point);
extern void nanami_rect_NormalizeRect(RECT *rc);
extern void nanami_rect_set(RECT *rc, const RECT rect);
extern BOOL nanami_rect_equal(RECT *rc, const RECT rect);
extern BOOL nanami_rect_not_equal(RECT *rc, const RECT rect);
extern void nanami_rect_inc_1(RECT *rc, POINT point);
extern void nanami_rect_inc_2(RECT *rc, SIZE size);
extern void nanami_rect_inc_3(RECT *rc, const RECT rect);
extern void nanami_rect_dec_1(RECT *rc, POINT point);
extern void nanami_rect_dec_2(RECT *rc, SIZE size);
extern void nanami_rect_dec_3(RECT *rc, const RECT rect);
extern void nanami_rect_and_set(RECT *rc, const RECT rect);
extern void nanami_rect_or_set(RECT *rc, const RECT rect);
extern RECT nanami_rect_plus_1(RECT *rc, POINT point);
extern RECT nanami_rect_minus_1(RECT *rc, POINT point);
extern RECT nanami_rect_plus_2(RECT *rc, SIZE size);
extern RECT nanami_rect_minus_2(RECT *rc, SIZE size);
extern RECT nanami_rect_and(RECT *rc, const RECT rect2);
extern RECT nanami_rect_or(RECT *rc, const RECT rect2);

#endif //__NANAMI_GEOMTRY_H__
