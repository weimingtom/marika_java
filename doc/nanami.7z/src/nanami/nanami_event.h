#ifndef	__NANAMI_EVENT_H__
#define	__NANAMI_EVENT_H__

#include <windows.h>

typedef struct nanami_event_struct 
{
	int Count;
	BOOL LastBtn;
} nanami_event_t;

extern nanami_event_t *nanami_event_new(void);
extern void nanami_event_free(nanami_event_t *ev);

#define NANAMI_EVENT_NOACTION 0
#define NANAMI_EVENT_PLAYERTALK 1
#define NANAMI_EVENT_NPCTALK 2
#define NANAMI_EVENT_END 3

extern int nanami_event_GetAction(nanami_event_t *ev, BOOL btn);
extern const char *nanami_event_GetText(nanami_event_t *ev);
extern nanami_event_t *nanami_event_mgr_GetEvent(int no);

#endif
