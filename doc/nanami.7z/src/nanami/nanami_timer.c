#include "nanami_common.h"
#include <windows.h>
#include <mmsystem.h>
#include "nanami_timer.h"

//#pragma comment(lib, "winmm.lib")

static void nanami_timer_init(nanami_timer_t *timer)
{
	LARGE_INTEGER tps;

	timer->bUsingQPF = FALSE;
	timer->bTimerStopped = TRUE;
	timer->StopTime = 0;
	timer->TicksPerSec = 0;
	timer->LastElapsedTime = 0;
	timer->BaseTime = 0;
        timer->PausedCount = 0;
	timer->bUsingQPF = QueryPerformanceFrequency(&tps);
	if (timer->bUsingQPF) 
	{
		timer->TicksPerSec = tps.QuadPart;
	}
	else 
	{
		timer->TicksPerSec = 1000;
	}
	timer->InvTicksPerSec = 1.0 / (double)timer->TicksPerSec;
}

nanami_timer_t *nanami_timer_new()
{
	nanami_timer_t *timer = (nanami_timer_t *)malloc(sizeof(nanami_timer_t));
	nanami_timer_init(timer);
	return timer;
}

LONGLONG nanami_timer_GetSystemTimer(nanami_timer_t *timer, BOOL real_time)
{
	if (timer->bUsingQPF) 
	{
		LARGE_INTEGER Time;

		if (timer->StopTime != 0 && !real_time)
		{
			return timer->StopTime;
		}
		QueryPerformanceCounter(&Time);
		return Time.QuadPart;
	}
	return (LONGLONG)timeGetTime();
}

float nanami_timer_PeekElapsedTime(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, FALSE);
	return (float)((time - timer->LastElapsedTime) * timer->InvTicksPerSec);
}

float nanami_timer_GetElapsedTime(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, FALSE);
	float elapsed = (float)((time - timer->LastElapsedTime) * timer->InvTicksPerSec);
	timer->LastElapsedTime = time;
	return elapsed;
}

float nanami_timer_GetAppTime(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, FALSE);
	return (float)((time - timer->BaseTime) * timer->InvTicksPerSec);
}

void nanami_timer_Reset(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, FALSE);
	timer->BaseTime = time;
	timer->LastElapsedTime = time;
	timer->StopTime = 0;
	timer->bTimerStopped = FALSE;
}

void nanami_timer_Start(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, TRUE);
	if (timer->bTimerStopped)
	{
		timer->BaseTime += time - timer->StopTime;
	}
	timer->StopTime = 0;
	timer->LastElapsedTime = time;
	timer->bTimerStopped = FALSE;
}

void nanami_timer_Stop(nanami_timer_t *timer)
{
	if (!timer->bTimerStopped) 
	{
		LONGLONG time = nanami_timer_GetSystemTimer(timer, TRUE);
		timer->StopTime = time;
		timer->LastElapsedTime = time;
		timer->bTimerStopped = TRUE;
	}
}

float nanami_timer_GetAbsoluteTime(nanami_timer_t *timer)
{
	LONGLONG time = nanami_timer_GetSystemTimer(timer, TRUE);
	return (float)(time * timer->InvTicksPerSec);
}

void nanami_timer_Pause(nanami_timer_t *timer)
{
	if (timer->PausedCount == 0) 
	{
		nanami_timer_Stop(timer);
	}
	timer->PausedCount++;
}

void nanami_timer_Resume(nanami_timer_t *timer)
{
	timer->PausedCount--;
	if (timer->PausedCount == 0) 
	{
		nanami_timer_Start(timer);
	}
}
