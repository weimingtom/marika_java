#ifndef __NANAMI_FILE_H__
#define __NANAMI_FILE_H__

#include <windows.h>
#include <stdio.h>

typedef struct nanami_file_struct {
	FILE *fp;
} nanami_file_t;

#define NANAMI_FILE_READ  0
#define NANAMI_FILE_WRITE 1

#define NANAMI_FILE_BEGIN SEEK_SET
#define NANAMI_FILE_CURRENT SEEK_CUR
#define NANAMI_FILE_END SEEK_END

extern nanami_file_t *nanami_file_new(const char *file, int mode);
extern void nanami_file_free(nanami_file_t *file);

extern BOOL nanami_file_Open(nanami_file_t *file, const char *filename, int mode);
extern BOOL nanami_file_Close(nanami_file_t *file);
extern int nanami_file_Read(nanami_file_t *file, void *buffer, int length);
extern int nanami_file_Write(nanami_file_t *file, const void *buffer, int length);
extern long nanami_file_Seek(nanami_file_t *file, long offset, int from);
extern long nanami_file_GetFileSize(nanami_file_t *file);

#endif //__NANAMI_FILE_H__
