#include "nanami_common.h"
#include "nanami_geometry.h"

void nanami_size_init(SIZE *sz)
{

}

void nanami_size_init_1(SIZE *sz, int _cx, int _cy)
{
	sz->cx = _cx;
	sz->cy = _cy;
}

void nanami_size_init_2(SIZE *sz, SIZE size)
{
	sz->cx = size.cx;
	sz->cy = size.cy;
}

void nanami_size_init_3(SIZE *sz, DWORD size)
{
	sz->cx = (short)LOWORD(size);
	sz->cy = (short)HIWORD(size);
}

BOOL nanami_size_equal(SIZE *sz, SIZE size)
{
	return (sz->cx == size.cx && sz->cy == size.cy) ? TRUE : FALSE;
}

BOOL nanami_size_not_equal(SIZE *sz, SIZE size)
{
	return (sz->cx != size.cx || sz->cy != size.cy) ? TRUE : FALSE;
}

void nanami_size_inc(SIZE *sz, SIZE size)
{
	sz->cx += size.cx;
	sz->cy += size.cy;
}

void nanami_size_dec(SIZE *sz, SIZE size)
{
	sz->cx -= size.cx;
	sz->cy -= size.cy;
}

SIZE nanami_size_add(SIZE *sz, SIZE size)
{
	SIZE ret;
	ret.cx = sz->cx + size.cx;
	ret.cy = sz->cy + size.cy;
	return ret;
}

SIZE nanami_size_minus(SIZE *sz, SIZE size)
{
	SIZE ret;
	ret.cx = sz->cx - size.cx;
	ret.cy = sz->cy - size.cy;
	return ret;
}

SIZE nanami_size_neg(SIZE *sz)
{
	SIZE ret;
	ret.cx = - sz->cx;
	ret.cy = - sz->cy;
	return ret;
}

void nanami_point_init(POINT *pt)
{

}

void nanami_point_init_1(POINT *pt, int _x, int _y)
{
	pt->x = _x;
	pt->y = _y;
}

void nanami_point_init_2(POINT *pt, POINT point)
{
	pt->x = point.x;
	pt->y = point.y;
}

void nanami_point_init_3(POINT *pt, DWORD point)
{
	pt->x = (short)LOWORD(point);
	pt->y = (short)HIWORD(point);
}

void nanami_point_Offset_1(POINT *pt, int offx, int offy)
{
	pt->x += offx;
	pt->y += offy;
}

void nanami_point_Offset_2(POINT *pt, POINT point)
{
	pt->x += point.x;
	pt->y += point.y;
}

void nanami_point_Offset_3(POINT *pt, SIZE size)
{
	pt->x += size.cx;
	pt->y += size.cy;
}

BOOL nanami_point_equal(POINT *pt, POINT point)
{
	return (pt->x == point.x && pt->y == point.y) ? TRUE : FALSE;
}

BOOL nanami_point_not_equal(POINT *pt, POINT point)
{
	return (pt->x != point.x || pt->y != point.y) ? TRUE : FALSE;
}

void nanami_point_inc_1(POINT *pt, SIZE size)
{
	pt->x += size.cx;
	pt->y += size.cy;
}

void nanami_point_dec_1(POINT *pt, SIZE size)
{
	pt->x -= size.cx;
	pt->y -= size.cy;
}

void nanami_point_inc_2(POINT *pt, POINT point)
{
	pt->x += point.x;
	pt->y += point.y;
}

void nanami_point_dec_2(POINT *pt, POINT point)
{
	pt->x -= point.x;
	pt->y -= point.y;
}

POINT nanami_point_plus_1(POINT *pt, SIZE size)
{
	POINT ret;
	ret.x = pt->x + size.cx;
	ret.y = pt->y + size.cy;
	return ret;
}

POINT nanami_point_minus_1(POINT *pt, SIZE size)
{
	POINT ret;
	ret.x = pt->x - size.cx;
	ret.y = pt->y - size.cy;
	return ret;
}

POINT nanami_point_neg(POINT *pt)
{
	POINT ret;
	ret.x = - pt->x;
	ret.y = - pt->y;
	return ret;
}

POINT nanami_point_plus_2(POINT *pt, POINT point)
{
	POINT ret;
	ret.x = pt->x + point.x;
	ret.y = pt->y + point.y;
	return ret;
}

POINT nanami_point_minus_2(POINT *pt, POINT point)
{
	POINT ret;
	ret.x = pt->x - point.x;
	ret.y = pt->y - point.y;
	return ret;
}

void nanami_rect_init(RECT *rc)
{

}

void nanami_rect_init_1(RECT *rc, int x1, int y1, int x2, int y2)
{
	rc->left = x1;
	rc->top = y1;
	rc->right = x2;
	rc->bottom = y2;
}

void nanami_rect_init_2(RECT *rc, const RECT rect)
{
	rc->left = rect.left;
	rc->top = rect.top;
	rc->right = rect.right;
	rc->bottom = rect.bottom;
}

int nanami_rect_Width(RECT *rc)
{
	return rc->right - rc->left;
}

int nanami_rect_Height(RECT *rc)
{
	return rc->bottom - rc->top;
}

SIZE nanami_rect_Size(RECT *rc)
{
	SIZE ret;
	ret.cx = rc->right - rc->left;
	ret.cy = rc->bottom - rc->top;
	return ret;
}

POINT *nanami_rect_TopLeft_1(RECT *rc)
{
	return ((POINT *)rc);
}

POINT *nanami_rect_BottomRight_1(RECT *rc)
{
	return ((POINT *)rc + 1);
}

BOOL nanami_rect_IsRectEmpty(RECT *rc)
{
	return (rc->left == rc->right || rc->top == rc->bottom) ? TRUE : FALSE;
}

BOOL nanami_rect_IsRectNull(RECT *rc)
{
	return (rc->left == 0 && rc->right == 0 && rc->top == 0 && rc->bottom == 0) ? TRUE : FALSE;
}

BOOL nanami_rect_PtInRect(RECT *rc, POINT point)
{
	return PtInRect(rc, point);
}

void nanami_rect_SetRect(RECT *rc, int x1, int y1, int x2, int y2)
{
	rc->left = x1;
	rc->top = y1;
	rc->right = x2;
	rc->bottom = y2;
}

void nanami_rect_SetRectEmpty(RECT *rc)
{
	rc->left = rc->top = rc->right = rc->bottom = 0;
}

void nanami_rect_InflateRect_1(RECT *rc, int x, int y)
{
	InflateRect(rc, x, y);
}

void nanami_rect_InflateRect_2(RECT *rc, SIZE size)
{
	InflateRect(rc, size.cx, size.cy);
}

void nanami_rect_OffsetRect_1(RECT *rc, int x, int y)
{
	OffsetRect(rc, x, y);
}

void nanami_rect_OffsetRect_2(RECT *rc, SIZE size)
{
	OffsetRect(rc, size.cx, size.cy);
}

void nanami_rect_OffsetRect_3(RECT *rc, POINT point)
{
	OffsetRect(rc, point.x, point.y);
}

void nanami_rect_set(RECT *rc, const RECT rect)
{
	CopyRect(rc, &rect);
}

BOOL nanami_rect_equal(RECT *rc, const RECT rect)
{
	return EqualRect(rc, &rect);
}

BOOL nanami_rect_not_equal(RECT *rc, const RECT rect)
{
	return !EqualRect(rc, &rect);
}

void nanami_rect_inc_1(RECT *rc, POINT point)
{
	OffsetRect(rc, point.x, point.y);
}

void nanami_rect_inc_2(RECT *rc, SIZE size)
{
	OffsetRect(rc, size.cx, size.cy);
}

void nanami_rect_inc_3(RECT *rc, const RECT rect)
{
	rc->left += rect.left;
	rc->top += rect.top;
	rc->right += rect.right;
	rc->bottom += rect.bottom;
}

void nanami_rect_dec_1(RECT *rc, POINT point)
{
	OffsetRect(rc, -point.x, -point.y);
}

void nanami_rect_dec_2(RECT *rc, SIZE size)
{
	OffsetRect(rc, -size.cx, -size.cy);
}

void nanami_rect_dec_3(RECT *rc, const RECT rect)
{
	rc->left -= rect.left;
	rc->top -= rect.top;
	rc->right -= rect.right;
	rc->bottom -= rect.bottom;
}

void nanami_rect_and_set(RECT *rc, const RECT rect)
{
	IntersectRect(rc, rc, &rect);
}

void nanami_rect_or_set(RECT *rc, const RECT rect)
{
	UnionRect(rc, rc, &rect);
}

RECT nanami_rect_plus_1(RECT *rc, POINT point)
{
	RECT rect = *rc;
	OffsetRect(&rect, point.x, point.y);
	return rect;
}

RECT nanami_rect_minus_1(RECT *rc, POINT point)
{
	RECT rect = *rc;
	OffsetRect(&rect, -point.x, -point.y);
	return rect;
}

RECT nanami_rect_plus_2(RECT *rc, SIZE size)
{
	RECT rect = *rc;
	OffsetRect(&rect, size.cx, size.cy);
	return rect;
}

RECT nanami_rect_minus_2(RECT *rc, SIZE size)
{
	RECT rect = *rc;
	OffsetRect(&rect, -size.cx, -size.cy);
	return rect;
}

RECT nanami_rect_and(RECT *rc, const RECT rect2)
{
	RECT rect;
	IntersectRect(&rect, rc, &rect2);
	return rect;
}

RECT nanami_rect_or(RECT *rc, const RECT rect2)
{
	RECT rect;
	UnionRect(&rect, rc, &rect2);
	return rect;
}
