#ifndef __NANAMI_APP_H__
#define __NANAMI_APP_H__

#define	WM_KICKIDLE		0x036A

//#include "nanami_window.h"

struct nanami_window_struct;
struct nanami_app_struct;

typedef struct nanami_app_struct {
	HINSTANCE Instance;
	LPSTR CmdLine;
	int CmdShow;
	MSG	msgCur;
	struct nanami_window_struct *MainWnd;
	BOOL (*InitInstance)(struct nanami_app_struct *app);
} nanami_app_t;

extern nanami_app_t *nanami_app_new(void);
extern void nanami_app_free(nanami_app_t *app);

extern void nanami_app_SetWinMainArgs(nanami_app_t *app, HINSTANCE hInstance, LPSTR lpszCmdLine, int nCmdShow);
extern BOOL nanami_app_RegisterWndClass(nanami_app_t *app, const char *name, UINT classStyle, HCURSOR hCursor, HBRUSH hbrBackground, HICON hIcon);
extern int nanami_app_Run(nanami_app_t *app);
extern HRSRC nanami_app_FindResource(nanami_app_t *app, const char *name, const char *type);
extern HGLOBAL nanami_app_LoadResource(nanami_app_t *app, HRSRC hres);
extern HACCEL nanami_app_LoadAccelerators(nanami_app_t *app, const char *name);
extern HMENU nanami_app_LoadMenu_name(nanami_app_t *app, const char *name);
extern HMENU nanami_app_LoadMenu_id(nanami_app_t *app, int resId);
extern HICON nanami_app_LoadIcon_name(nanami_app_t *app, const char *name);
extern HICON nanami_app_LoadIcon_id(nanami_app_t *app, int resId);
extern HINSTANCE nanami_app_GetInstance(nanami_app_t* app);
extern struct nanami_window_struct *nanami_app_GetMainWnd(nanami_app_t* app);

extern BOOL nanami_app_InitInstance(nanami_app_t *app);
extern BOOL nanami_app_OnIdle(nanami_app_t *app, long count);
extern BOOL nanami_app_PreTranslateMessage(nanami_app_t *app, MSG *msg);

//public static 

extern nanami_app_t *nanami_app_Application;

#endif  //__NANAMI_APP_H__
