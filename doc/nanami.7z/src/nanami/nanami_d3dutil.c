#include "nanami_common.h"
#include "nanami_d3dutil.h"
#include <math.h>

#if _MSC_VER <= 1200
static float atanf(float x)
{
	return (float)atan((double)x);
}
#endif

void nanami_camera_init(nanami_camera_t *cam)
{
	cam->ViewFrom.x = 0;
	cam->ViewFrom.y = 100;
	cam->ViewFrom.z = 0;
	cam->ViewTo.x = 0;
	cam->ViewTo.y = 0;
	cam->ViewTo.z = 0;
	cam->ViewUp.x = 0;
	cam->ViewUp.y = 1;
	cam->ViewUp.z = 0;
	cam->FOV = D3DX_PI / 2.0f;
	cam->Aspect = 4.0f / 3.0f;
	cam->NearPlane = 1.0f;
	cam->FarPlane = 1000.0f;
}

void nanami_camera_SetViewParams_1(nanami_camera_t *cam, D3DXVECTOR3 *eye, D3DXVECTOR3 *lookat)
{
	cam->ViewFrom = *eye;
	cam->ViewTo = *lookat;
	D3DXMatrixLookAtLH(&cam->ViewMat, &cam->ViewFrom, &cam->ViewTo, &cam->ViewUp);
}

void nanami_camera_SetViewParams_2(nanami_camera_t *cam, float rot_x, float rot_y, float dist, D3DXVECTOR3 *lookat)
{
	D3DXVECTOR3 vfrom;
	D3DXMATRIX m;

	vfrom.x = 0;
	vfrom.y = 0;
	vfrom.z = dist;
	D3DXMatrixRotationYawPitchRoll(&m, rot_x, rot_y, 0.0f);
	D3DXVec3TransformCoord(&cam->ViewFrom, &vfrom, &m);
	cam->ViewTo = *lookat;
	cam->ViewFrom.x += cam->ViewTo.x;
	cam->ViewFrom.y += cam->ViewTo.y;
	cam->ViewFrom.z += cam->ViewTo.z;
	D3DXMatrixLookAtLH(&cam->ViewMat, &cam->ViewFrom, &cam->ViewTo, &cam->ViewUp);
}

void nanami_camara_SetProjParams(nanami_camera_t *cam, float fov, float aspect, float nz, float fz)
{
	cam->FOV = fov;
	cam->Aspect = aspect;
	cam->NearPlane = nz;
	cam->FarPlane = fz;
	D3DXMatrixPerspectiveFovLH(&cam->PersMat, cam->FOV, cam->Aspect, cam->NearPlane, cam->FarPlane);
}

void nanami_camera_GetViewRotation(nanami_camera_t *cam, float *yaw, float *pitch)
{
	D3DXVECTOR3 v;
	float dist;
	
	v.x = cam->ViewFrom.x - cam->ViewTo.x;
	v.y = cam->ViewFrom.y - cam->ViewTo.y;
	v.z = cam->ViewFrom.z - cam->ViewTo.z;

	if (v.x >= 0.0f)
		*yaw = -atanf(v.z / v.x) - D3DX_PI / 2;
	else
		*yaw = -atanf(v.z / v.x) + D3DX_PI / 2;

	dist = (float)sqrt(v.z * v.z + v.x * v.x);

	if (v.y >= 0.0f)
		*pitch = -atanf(dist / v.y) + D3DX_PI / 2;
	else
		*pitch = -atanf(dist / v.y) - D3DX_PI / 2;
}

void SetMaterial_1(D3DMATERIAL9 *material, float r, float g, float b)
{
	ZeroMemory(material, sizeof(D3DMATERIAL9));
	material->Diffuse.r = r;
	material->Diffuse.g = g;
	material->Diffuse.b = b;
	material->Ambient.r = r;
	material->Ambient.g = g;
	material->Ambient.b = b;
	material->Specular.r = 1.0f;
	material->Specular.g = 1.0f;
	material->Specular.b = 1.0f;
	material->Emissive.r = 0;
	material->Emissive.g = 0;
	material->Emissive.b = 0;
	material->Power = 10;
}

void SetMaterial_2(D3DMATERIAL9 *material, float r, float g, float b, float a)
{
	ZeroMemory(material, sizeof(D3DMATERIAL9));
	material->Diffuse.r = r;
	material->Diffuse.g = g;
	material->Diffuse.b = b;
	material->Diffuse.a = a;
	material->Ambient.r = r;
	material->Ambient.g = g;
	material->Ambient.b = b;
	material->Ambient.a = a;
	material->Specular.r = 1.0f;
	material->Specular.g = 1.0f;
	material->Specular.b = 1.0f;
	material->Specular.a = 1.0f;
	material->Emissive.r = 0;
	material->Emissive.g = 0;
	material->Emissive.b = 0;
	material->Power = 10;
}

void SetDirectionalLight(D3DLIGHT9 *light, float r, float g, float b, const D3DXVECTOR3 dir)
{
	ZeroMemory(light, sizeof(D3DLIGHT9));
	light->Type = D3DLIGHT_DIRECTIONAL;
	light->Diffuse.r = r;
	light->Diffuse.g = g;
	light->Diffuse.b = b;
	D3DXVec3Normalize((D3DXVECTOR3 *)&light->Direction, &dir);
}

// -----------------------------------

void nanami_d3dvertex_init(nanami_d3dvertex_t *vt, float _x, float _y, float _z, float _nx, float _ny, float _nz, float _tu0, float _tv0)
{
	vt->x = _x;
	vt->y = _y;
	vt->z = _z;
	vt->nx = _nx;
	vt->ny = _ny;
	vt->nz = _nz;
	vt->tu0 = _tu0;
	vt->tv0 = _tv0;
}

void nanami_d3dvertex_Set(nanami_d3dvertex_t *vt, float _x, float _y, float _z, float _nx, float _ny, float _nz, float _tu0, float _tv0)
{
	vt->x = _x;
	vt->y = _y;
	vt->z = _z;
	vt->nx = _nx;
	vt->ny = _ny;
	vt->nz = _nz;
	vt->tu0 = _tu0;
	vt->tv0 = _tv0;
}



//FIXME:
void GetViewDistance(nanami_camera_t *cam, D3DXVECTOR3 *v)
{
	v->x = cam->ViewFrom.x - cam->ViewTo.x;
	v->y = cam->ViewFrom.x - cam->ViewTo.y;
	v->z = cam->ViewFrom.x - cam->ViewTo.z;
}

//FIXME:
float CalcDistance(nanami_camera_t *cam, const D3DXVECTOR3 *v)
{
	D3DXVECTOR3 v2;
	v2.x = cam->ViewFrom.x - v->x;
	v2.y = cam->ViewFrom.y - v->y;
	v2.z = cam->ViewFrom.z - v->z;
	return D3DXVec3LengthSq(&v2);
}


// public:
//CCamera();
/*
const D3DXMATRIX &GetViewMat() const 
{
	return ViewMat; 
}
const D3DXMATRIX &GetPersMat()
{ 
	return PersMat; 
}
*/
