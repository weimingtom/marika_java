// JFC
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

// GTGE
import ugame.nanami.*;

public class Tutorial8_2 extends Game {
    Sprite            sprite;
    Background        backgr;
    ColorBackground   colorBG;
    ImageBackground   imageBG;
    TileBackground    tileBG;
    GameFont          font;

    @Override
    public void initResources() {
        int w = 768;
        int h = 576;
        Color color = Color.BLUE;
        BufferedImage image = getImage("resources/background.jpg");
        BufferedImage[] tileImages = getImages("resources/tiles.png", 6, 1); // tile size = 64 x 64
        int[][] tiles = new int[w/64][h/64];
        for (int i=0;i < tiles.length;i++) {
            for (int j=0;j < tiles[0].length;j++) {
                tiles[i][j] = getRandom(0, tileImages.length-1);
            }
        }
        colorBG = new ColorBackground(color, w, h);
        imageBG = new ImageBackground(image);
        tileBG  = new TileBackground(tileImages, tiles);
        backgr = imageBG;
        sprite = new Sprite(getImage("resources/plane1.png"), 100, 100);
        sprite.setBackground(backgr);
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    public void update(long elapsedTime) {
        backgr.update(elapsedTime);
        sprite.update(elapsedTime);
        if (keyPressed(KeyEvent.VK_ENTER)) {
            if (backgr == colorBG) {
                backgr = imageBG;
            } else if (backgr == imageBG) {
                backgr = tileBG;
            } else if (backgr == tileBG) {
                backgr = colorBG;
            }
            sprite.setBackground(backgr);
        }
        if (keyDown(KeyEvent.VK_LEFT))       
            sprite.addHorizontalSpeed(elapsedTime, -0.001, -0.4);
        else if (keyDown(KeyEvent.VK_RIGHT)) 
            sprite.addHorizontalSpeed(elapsedTime,  0.001,  0.4);
        else if (sprite.getHorizontalSpeed() > 0) 
            sprite.addHorizontalSpeed(elapsedTime, -0.005, 0);
        else if (sprite.getHorizontalSpeed() < 0) 
            sprite.addHorizontalSpeed(elapsedTime,  0.005, 0);
        if (keyDown(KeyEvent.VK_UP))         
            sprite.addVerticalSpeed(elapsedTime, -0.001, -0.4);
        else if (keyDown(KeyEvent.VK_DOWN))  
            sprite.addVerticalSpeed(elapsedTime,  0.001,  0.4);
        else if (sprite.getVerticalSpeed() > 0) 
            sprite.addVerticalSpeed(elapsedTime, -0.005, 0);
        else if (sprite.getVerticalSpeed() < 0) 
            sprite.addVerticalSpeed(elapsedTime,  0.005, 0);
        backgr.setToCenter(sprite);
    }

    public void render(Graphics2D g) {
        backgr.render(g);
        sprite.render(g);
        font.drawString(g, "ENTER: CHANGE ACTIVE BACKGROUND", 10, 10);
    }

    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial8_2(), new Dimension(640,480), false);
        game.start();
    }

}