import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import ugame.nanami.*;

public class Tutorial11 extends Game {
    PlayField playfield;
    Background background;
    SpriteGroup PLAYER_GROUP;
    SpriteGroup PROJECTILE_GROUP;
    SpriteGroup ENEMY_GROUP;
    AnimatedSprite plane;
    Timer moveTimer;
    ProjectileEnemyCollision2 collision;
    GameFont font;

    @Override
    public void initResources() {
        playfield = new PlayField();
        background = new ImageBackground(getImage("resources/background.jpg"), 640, 480);
        playfield.setBackground(background);
        plane = new AnimatedSprite(getImages("resources/plane2.png",3,1), 287.5, 390);
        plane.setAnimate(true);
        plane.setLoopAnim(true);
        PLAYER_GROUP = new SpriteGroup("Player");
        PROJECTILE_GROUP = new SpriteGroup("Projectile");
        playfield.addGroup(PLAYER_GROUP);
        playfield.addGroup(PROJECTILE_GROUP);
        ENEMY_GROUP = playfield.addGroup(new SpriteGroup("Enemy"));
        PLAYER_GROUP.add(plane);
        BufferedImage image = getImage("resources/plane1.png");
        int startX = 10;
        int startY = 30;
        for (int j=0;j < 4;j++) {
            for (int i=0;i < 7;i++) {
                Sprite enemy = new Sprite(image, startX+(i*80), startY+(j*70));
                enemy.setHorizontalSpeed(0.04);
                ENEMY_GROUP.add(enemy);
            }
        }
        moveTimer = new Timer(2000);
        collision = new ProjectileEnemyCollision2(this);
        playfield.addCollisionGroup(PROJECTILE_GROUP, ENEMY_GROUP, collision);
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    @Override
    public void update(long elapsedTime) {
	playfield.update(elapsedTime);
	if (moveTimer.action(elapsedTime)) {
            Sprite[] sprites = ENEMY_GROUP.getSprites();
            int size = ENEMY_GROUP.getSize();
            for (int i=0;i < size;i++) {
                sprites[i].setHorizontalSpeed(-sprites[i].getHorizontalSpeed());
            }
        }
        double speedX = 0;
        if (keyDown(KeyEvent.VK_LEFT))   
            speedX = -0.1;
        if (keyDown(KeyEvent.VK_RIGHT))  
            speedX = 0.1;
        plane.setHorizontalSpeed(speedX);
        if (keyPressed(KeyEvent.VK_CONTROL)) {
            Sprite projectile = new Sprite(getImage("resources/projectile.png"));
            projectile.setLocation(plane.getX()+16.5, plane.getY()-16);
            projectile.setVerticalSpeed(-0.2);
            PROJECTILE_GROUP.add(projectile);
            playSound("resources/sound1.wav");
        }
        if (keyPressed(KeyEvent.VK_ENTER)) {
            collision.pixelPerfectCollision = !collision.pixelPerfectCollision;
        }
        background.setToCenter(plane);
    }
    
    @Override
    public void render(Graphics2D g) {
        playfield.render(g);
        font.drawString(g, "ARROW KEY : MOVE", 10, 10);
        font.drawString(g, "CONTROL   : FIRE", 10, 30);
        font.drawString(g, "ENTER     : TOGGLE PPC", 10, 50);
        if (collision.pixelPerfectCollision) {
            font.drawString(g, " USE PIXEL PERFECT COLLISION ", GameFont.RIGHT, 0, 460, getWidth());
        }
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial11(), new Dimension(640,480), false);
        game.start();
    }
}

class ProjectileEnemyCollision2 extends BasicCollisionGroup {
    Tutorial11    owner;
    public ProjectileEnemyCollision2(Tutorial11 owner) {
        this.owner = owner;
    }

    @Override
    public void collided(Sprite s1, Sprite s2) {
        s1.setActive(false);
        s2.setActive(false);
        BufferedImage[] images = owner.getImages("resources/explosion.png", 7, 1);
        VolatileSprite explosion = new VolatileSprite(images, s2.getX(), s2.getY());
        owner.playfield.add(explosion);
    }
}
