import java.awt.*;

import ugame.nanami.*;

public class Tutorial5_1 extends Game {
    @Override
    public void initResources() {
	
    }

    @Override
    public void update(long elapsedTime) {
	
    }

    public void render(Graphics2D g) {
	
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial5_1(), new Dimension(640,480), false);
        game.start();
    }
}