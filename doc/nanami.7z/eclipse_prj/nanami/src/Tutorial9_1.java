import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import ugame.nanami.*;

public class Tutorial9_1 extends Game {
    SpriteGroup SPRITE_GROUP; 
    AnimatedSprite sprite1;
    Sprite sprite2;
    Sprite sprite3;
    Background        background;
    
    @Override
    public void initResources() {
        background = new ImageBackground(getImage("resources/background.jpg"));
        sprite1 = new AnimatedSprite(getImages("resources/plane2.png",3,1), 120, 50);
        sprite1.setAnimate(true);
        sprite1.setLoopAnim(true);
        sprite2 = new Sprite(getImage("resources/plane1.png"), 220, 50);
        sprite3 = new Sprite(getImage("resources/plane1.png"), 320, 50);
        String name = "Plane Group";
        SPRITE_GROUP = new SpriteGroup(name);
        SPRITE_GROUP.setBackground(background);
        SPRITE_GROUP.add(sprite1);
        SPRITE_GROUP.add(sprite2);
        SPRITE_GROUP.add(sprite3);
        BufferedImage image = getImage("resources/plane1.png");
        SPRITE_GROUP.add(new Sprite(image, 420, 50));
        SPRITE_GROUP.add(new Sprite(image, 120, 150));
        SPRITE_GROUP.add(new Sprite(image, 220, 150));
        SPRITE_GROUP.add(new Sprite(image, 320, 150));
        SPRITE_GROUP.add(new Sprite(image, 420, 150));
        SPRITE_GROUP.add(new Sprite(image, 120, 250));
        SPRITE_GROUP.add(new Sprite(image, 220, 250));
        SPRITE_GROUP.add(new Sprite(image, 320, 250));
        SPRITE_GROUP.add(new Sprite(image, 420, 250));
        SPRITE_GROUP.add(new Sprite(image, 120, 350));
        SPRITE_GROUP.add(new Sprite(image, 220, 350));
        SPRITE_GROUP.add(new Sprite(image, 320, 350));
        SPRITE_GROUP.add(new Sprite(image, 420, 350));
    }
    
    @Override
    public void update(long elapsedTime) {
        background.update(elapsedTime);
        SPRITE_GROUP.update(elapsedTime);
        double speedX = 0;
        double speedY = 0;
        if (keyDown(KeyEvent.VK_LEFT))     
            speedX = -0.1;
        if (keyDown(KeyEvent.VK_RIGHT)) 
            speedX = 0.1;
        if (keyDown(KeyEvent.VK_UP))     
            speedY = -0.1;
        if (keyDown(KeyEvent.VK_DOWN))     
            speedY = 0.1;
        sprite1.setSpeed(speedX, speedY);
        background.setToCenter(sprite1);
    }
    
    @Override
    public void render(Graphics2D g) {
        background.render(g);
        SPRITE_GROUP.render(g);
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial9_1(), new Dimension(640,480), false);
        game.start();
    }

}