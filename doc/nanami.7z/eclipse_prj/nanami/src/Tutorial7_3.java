
import java.awt.*;

import ugame.nanami.*;

public class Tutorial7_3 extends Game {
    Sprite sprite;
    Sprite projectile;
    Timer fireTimer;
    Timer countDownTimer; 
    int time; 
    GameFont font;
    
    public void initResources() {
        sprite = new AnimatedSprite(getImages("resources/plane2.png",3,1), 287.5, 330);
        ((AnimatedSprite) sprite).setAnimate(true);
        ((AnimatedSprite) sprite).setLoopAnim(true);
        projectile = new Sprite(getImage("resources/projectile.png"), -50, -50);
        fireTimer = new Timer(1000);
        countDownTimer = new Timer(1000);
        time = 20;
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    @Override
    public void update(long elapsedTime) {
        sprite.update(elapsedTime);
        projectile.update(elapsedTime);
        if (fireTimer.action(elapsedTime)) {
            playSound("resources/sound1.wav");
            projectile.setLocation(sprite.getX()+16.5, sprite.getY()-16);
            projectile.setVerticalSpeed(-0.5);
        }
        if (countDownTimer.action(elapsedTime)) {
            time--;
            if (time <= 0) {
                finish();
            }
        }
    }

    @Override
    public void render(Graphics2D g) {
        g.setColor(Color.BLUE);
        g.fillRect(0, 0, getWidth(), getHeight());
        sprite.render(g);
        projectile.render(g);
        font.drawString(g, "TIME : " + time, 15, 15);
    }

    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial7_3(), new Dimension(640,480), false);
        game.start();
    }

}