
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import ugame.nanami.*;

public class Tutorial9_2 extends Game {
    SpriteGroup SPRITE_GROUP;
    Background background;
    GameFont font;

    @Override
    public void initResources() {
        background = new ImageBackground(getImage("resources/background.jpg"));
        SPRITE_GROUP = new SpriteGroup("Anonymous Group");
        SPRITE_GROUP.setBackground(background);
        BufferedImage image = getImage("resources/plane1.png");
        SPRITE_GROUP.add(new Sprite(image, 120, 50));
        SPRITE_GROUP.add(new Sprite(image, 220, 50));
        SPRITE_GROUP.add(new Sprite(image, 320, 50));
        SPRITE_GROUP.add(new Sprite(image, 420, 50));
        SPRITE_GROUP.add(new Sprite(image, 120, 150));
        SPRITE_GROUP.add(new Sprite(image, 220, 150));
        SPRITE_GROUP.add(new Sprite(image, 320, 150));
        SPRITE_GROUP.add(new Sprite(image, 420, 150));
        SPRITE_GROUP.add(new Sprite(image, 120, 250));
        SPRITE_GROUP.add(new Sprite(image, 220, 250));
        SPRITE_GROUP.add(new Sprite(image, 320, 250));
        SPRITE_GROUP.add(new Sprite(image, 420, 250));
        SPRITE_GROUP.add(new Sprite(image, 120, 350));
        SPRITE_GROUP.add(new Sprite(image, 220, 350));
        SPRITE_GROUP.add(new Sprite(image, 320, 350));
        SPRITE_GROUP.add(new Sprite(image, 420, 350));
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    @Override
    public void update(long elapsedTime) {
        background.update(elapsedTime);
        SPRITE_GROUP.update(elapsedTime);
        if (keyPressed(KeyEvent.VK_ENTER)) {
            Sprite activeSprite = SPRITE_GROUP.getActiveSprite();
            if (activeSprite != null) {
                activeSprite.setActive(false);
            }
        }
    }

    @Override
    public void render(Graphics2D g) {
        background.render(g);
        SPRITE_GROUP.render(g);
        font.drawString(g, "ENTER : REMOVE A SPRITE", 10, 10);
        font.drawString(g, "        FROM ITS GROUP", 10, 30);
    }

    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial9_2(), new Dimension(640,480), false);
        game.start();
    }
}
