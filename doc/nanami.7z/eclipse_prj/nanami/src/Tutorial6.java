import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.*;

import ugame.nanami.*;

public class Tutorial6 extends Game {
    BufferedImage image;
    BufferedImage[] images;
    URL url;
    GameFont font;
    
    @Override
    public void initResources() {
        image = getImage("resources/plane1.png");
        images = getImages("resources/plane2.png", 3, 1);
        url = bsIO.getURL("resources/textfile.txt");
        playMusic("resources/music1.mid");
        setFPS(25);
        font = fontManager.getFont(getImages("resources/smallfont.png", 8, 12),
                                   " !\"#$%&'()*+,-./0123456789:;<=>?" +
                                   "@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_" +
                                   "`abcdefghijklmnopqrstuvwxyz{|}~~");
    }

    @Override
    public void update(long elapsedTime) {
        if (keyPressed(KeyEvent.VK_ENTER)) {
            System.out.println("ENTER is pressed");
        }
        if (keyDown(KeyEvent.VK_A)) {
            System.out.println("A is being pressed");
        }
        if (click()) {
            System.out.println("Mouse LEFT BUTTON is pressed");
        }
        if (bsInput.isMouseDown(MouseEvent.BUTTON3)) {
            System.out.println("Mouse RIGHT BUTTON is being pressed");
        }
        if (keyPressed(KeyEvent.VK_SPACE)) {
            playSound("resources/sound1.wav");
        }
    }

    @Override
    public void render(Graphics2D g) {
        // Graphics Engine (bsGraphics)
        // getting window size: getWidth(), getHeight()
        g.setColor(Color.RED.darker());
        g.fillRect(0, 0, getWidth(), getHeight());
        font.drawString(g, "====================", 10, 7);
        font.drawString(g, "Testing Game Engines", 10, 17);
        font.drawString(g, "====================", 10, 27);
        font.drawString(g, "Image Engine (bsLoader)", 10, 45);
        font.drawString(g, "- Loading \"resource/plane1.png\" and \"resource/plane2.png\" :", 20, 60);
        g.drawImage(image, 20, 65, null);
        g.drawImage(images[0], 140, 65, null);
        g.drawImage(images[1], 220, 65, null);
        g.drawImage(images[2], 300, 65, null);
        font.drawString(g, "I/O Engine (bsIO)", 10, 145);
        font.drawString(g, "- Loading file URL \"resources/textfile.txt\" :", 20, 160);
        font.drawString(g, "  "+url.toString(), 20, 175);
        font.drawString(g, "Music Engine (bsMusic)", 10, 205);
        font.drawString(g, "- Playing \"resources/music1.mid\"", 20, 220);
        font.drawString(g, "Timer Engine (bsTimer)", 10, 250);
        font.drawString(g, "- Set FPS to 25", 20, 265);
        font.drawString(g, "- Get current FPS : "+getCurrentFPS(), 20, 280);
        font.drawString(g, "Input Engine (bsInput)", 10, 310);
        font.drawString(g, "- Press \"ENTER\" : print something to console", 20, 325);
        font.drawString(g, "- Pressing \"A\"  : print something to console", 20, 340);
        font.drawString(g, "- Click mouse left button     : print something to console", 20, 355);
        font.drawString(g, "- Clicking mouse right button : print something to console", 20, 370);
        font.drawString(g, "Sound Engine (bsSound)", 10, 400);
        font.drawString(g, "- Press \"SPACE\" : play \"resources/sound1.wav\"", 20, 415);
        font.drawString(g, "Graphics Engine (bsGraphics) : Show this screen with all these text!", 10, 445);
    }

    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial6(), new Dimension(640,480), false);
        game.start();
    }
}