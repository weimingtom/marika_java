import ugame.nanami.*;

public class Tutorial5_3 extends GameLoader {
    private static final long serialVersionUID = 1L;

    @Override
    protected Game createAppletGame() {
        return new Tutorial5_1();
    }
}
