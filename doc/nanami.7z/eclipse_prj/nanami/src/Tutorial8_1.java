import java.awt.*;
import java.awt.event.*;

import ugame.nanami.*;

public class Tutorial8_1 extends Game {
    Sprite sprite1;
    Sprite sprite2;
    Sprite sprite3;
    Background backgr;
    GameFont font;

    @Override
    public void initResources() {
        int w = 768; 
        int h = 576; 
        backgr = new ImageBackground(getImage("resources/background.jpg"), w, h);
        sprite1 = new Sprite(getImage("resources/plane1.png"), 100, 100);
        sprite1.setBackground(backgr);
        sprite2 = new Sprite(getImage("resources/plane1.png"), 250, 250);
        sprite2.setBackground(backgr);
        sprite3 = new Sprite(getImage("resources/plane1.png"), 400, 400);
        sprite3.setBackground(backgr);
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    @Override
    public void update(long elapsedTime) {
        backgr.update(elapsedTime);
        sprite1.update(elapsedTime);
        sprite2.update(elapsedTime);
        sprite3.update(elapsedTime);
        double speedX = 0, speedY = 0;
        if (keyDown(KeyEvent.VK_LEFT))   
            speedX = -0.1;
        if (keyDown(KeyEvent.VK_RIGHT))  
            speedX =  0.1;
        if (keyDown(KeyEvent.VK_UP))     
            speedY = -0.1;
        if (keyDown(KeyEvent.VK_DOWN))   
            speedY =  0.1;
        sprite1.setSpeed(speedX, speedY);
        backgr.setToCenter(sprite1);
    }

    @Override
    public void render(Graphics2D g) {
        backgr.render(g);
        sprite1.render(g);
        sprite2.render(g);
        sprite3.render(g);
        int spriteX = (int) sprite1.getX(),
            spriteY = (int) sprite1.getY();
        int screenX = (int) sprite1.getScreenX(),
            screenY = (int) sprite1.getScreenY();
        font.drawString(g, "LOCATED AT " + spriteX + ", " + spriteY,
            GameFont.CENTER, screenX-155, screenY+70, 400);
        font.drawString(g, "ON THE BACKGROUND",
            GameFont.CENTER, screenX-155, screenY+90, 400);
        font.drawString(g, "BG SIZE     : " +
                        backgr.getWidth() + " X " + backgr.getHeight(),
                        10, 10);
        font.drawString(g, "BG POSITION : " +
                        (int) backgr.getX() + ", " + (int) backgr.getY(),
                        10, 35);
    }

    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial8_1(), new Dimension(640,480), false);
        game.start();
    }
}