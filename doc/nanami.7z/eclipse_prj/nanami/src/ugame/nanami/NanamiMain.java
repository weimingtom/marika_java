package ugame.nanami;

/**
 * 
 * @see http://www.javalobby.org/forums/thread.jspa?threadID=16867&tstart=0
 */
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.util.Vector;
import javax.swing.JFrame;
import java.lang.Math;

public class NanamiMain {
    static final long serialVersionUID = 0L;
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 600;
    private static final String IMG_DIR = "assets/LB.PNG";
    private static final int CHARACTER_COUNT = 100;
    private static final int TIMER_INTEVAL = 50;
    private static final int FPS = 10;
    private static final int FRAME_DELAY = 1000 / FPS;
    public static final int RATE_FACT = 20;

    public static void main(String[] args) {
	JFrame frame = new JFrame("My Game Demo");
	Canvas gui = new Canvas();
	frame.getContentPane().add(gui);
	frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	frame.setLocationRelativeTo(null);
	frame.addWindowListener(new WindowAdapter() {
	    @Override
	    public void windowClosing(WindowEvent e) {
		System.exit(0);
	    }
	});
	Thread gameThread = new Thread(new GameLoop(gui));
	gameThread.setPriority(Thread.MIN_PRIORITY);
	frame.setVisible(true);
	gameThread.start();
    }

    private static class GameLoop implements Runnable {
	private boolean isRunning;
	private Canvas gui;
	private long cycleTime;
	private long lastTime;

	public GameLoop(Canvas canvas) {
	    gui = canvas;
	    isRunning = true;
	    gui.addMouseListener(new MouseAdapter() {
		public void mousePressed(MouseEvent e) {
		    onMousePressed(e);
		}
	    });
	    imgCharacter = Toolkit.getDefaultToolkit().createImage(IMG_DIR);
	    for (int i = 0; i < CHARACTER_COUNT; i++) {
		NanamiCharacter c = new NanamiCharacter();
		c.setPoint(new Point(0, 0));
		c.setTargetPoint(new Point(0, 0));
		points.add(c);
	    }
	}

	public void run() {
	    cycleTime = System.currentTimeMillis();
	    gui.createBufferStrategy(2);
	    BufferStrategy strategy = gui.getBufferStrategy();
	    while (isRunning) {
		if (System.currentTimeMillis() - lastTime > TIMER_INTEVAL) {
		    onTimer();
		    lastTime = System.currentTimeMillis();
		}
		updateGameState();
		updateGUI(strategy);
		synchFramerate();
	    }
	}

	private void synchFramerate() {
	    cycleTime = cycleTime + FRAME_DELAY;
	    long difference = cycleTime - System.currentTimeMillis();
	    try {
		Thread.sleep(Math.max(0, difference));
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	@SuppressWarnings("unused")
	public void shutdown() {
	    isRunning = false;
	}

	private void updateGameState() {

	}

	private void updateGUI(BufferStrategy strategy) {
	    Graphics g = strategy.getDrawGraphics();

	    g.setColor(Color.WHITE);
	    g.fillRect(0, 0, gui.getWidth(), gui.getHeight());
	    g.setColor(Color.BLACK);

	    g.setColor(Color.RED);
	    for (int i = 0; i < points.size(); i++) {
		for (int index = 0; index < points.size(); index++) {
		    Point p = (Point) (points.elementAt(index).getPoint());
		    g.drawImage(imgCharacter, p.x, p.y, gui);
		    g.drawString("char " + index, p.x, p.y);
		}
	    }

	    g.dispose();
	    strategy.show();
	}

	public void onMousePressed(MouseEvent e) {

	}

	public void onTimer() {
	    for (int i = 0; i < points.size(); i++) {
		points.elementAt(i).move();
	    }
	}

	private Vector<NanamiCharacter> points = new Vector<NanamiCharacter>();
	private Image imgCharacter;
    }
}
