﻿package ugame.nanami;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class TileBackground extends AbstractTileBackground {
    private static final long serialVersionUID = -1608779555653076202L;

    private transient BufferedImage[] tileImages;
    private int[][] tiles;

    public TileBackground(BufferedImage[] tileImages, int[][] tiles) {
	super(tiles.length, tiles[0].length, tileImages[0].getWidth(),
		tileImages[0].getHeight());
	this.tileImages = tileImages;
	this.tiles = tiles;
    }

    public TileBackground(BufferedImage[] tileImages, int horiz, int vert) {
	this(tileImages, new int[horiz][vert]);
    }

    public void renderTile(Graphics2D g, int tileX, int tileY, int x, int y) {
	int tile = this.tiles[tileX][tileY];
	if (tile >= 0) {
	    g.drawImage(this.tileImages[tile], x, y, null);
	}
    }

    public BufferedImage[] getTileImages() {
	return this.tileImages;
    }

    public void setTileImages(BufferedImage[] tileImages) {
	this.tileImages = tileImages;
	this.setTileSize(tileImages[0].getWidth(), tileImages[0].getHeight());
    }

    public int[][] getTiles() {
	return this.tiles;
    }

    public void setTiles(int[][] tiles) {
	this.tiles = tiles;
	super.setSize(tiles.length, tiles[0].length);
    }

    public void setSize(int horiz, int vert) {
	if (horiz != this.tiles.length || vert != this.tiles[0].length) {
	    int[][] old = this.tiles;
	    this.tiles = new int[horiz][vert];
	    int minx = Math.min(this.tiles.length, old.length), miny = Math
		    .min(this.tiles[0].length, old[0].length);
	    for (int j = 0; j < miny; j++) {
		for (int i = 0; i < minx; i++) {
		    this.tiles[i][j] = old[i][j];
		}
	    }
	}
	super.setSize(horiz, vert);
    }
}
