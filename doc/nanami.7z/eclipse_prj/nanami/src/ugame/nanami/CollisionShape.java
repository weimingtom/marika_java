﻿package ugame.nanami;

public interface CollisionShape {
    public boolean intersects(CollisionShape shape);

    public void setLocation(double x, double y);

    public void move(double dx, double dy);

    public void setBounds(double x1, double y1, int w1, int h1);

    public double getX();

    public double getY();

    public int getWidth();

    public int getHeight();

}
