﻿package ugame.nanami;

import java.awt.Graphics2D;

public interface GameFont {
    public static final int LEFT = 1;
    public static final int RIGHT = 2;
    public static final int CENTER = 3;
    public static final int JUSTIFY = 4;

    public int drawString(Graphics2D g, String s, int x, int y);

    public int drawString(Graphics2D g, String s, int alignment, int x, int y,
	    int width);

    public int drawText(Graphics2D g, String text, int alignment, int x, int y,
	    int width, int vspace, int firstIndent);

    public int getWidth(String st);

    public int getWidth(char c);

    public int getHeight();

    public boolean isAvailable(char c);
}
