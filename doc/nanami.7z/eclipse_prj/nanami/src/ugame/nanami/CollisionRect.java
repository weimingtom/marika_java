﻿package ugame.nanami;

public class CollisionRect implements CollisionShape {
    public double x;
    public double y;
    public int width;
    public int height;

    public CollisionRect() {
	this.x = 0;
	this.y = 0;
	this.width = 0;
	this.height = 0;
    }

    public void grow(int h, int v) {
	if (h >= 0) {
	    this.width += h;
	} else {
	    this.x += h;
	    this.width -= h;
	}
	if (v >= 0) {
	    this.height += v;
	} else {
	    this.y += v;
	    this.height -= v;
	}
    }

    public void shrink(int h, int v) {
	if (h >= 0) {
	    this.width -= h;
	} else {
	    this.x -= h;
	    this.width += h;
	}
	if (v >= 0) {
	    this.height -= v;
	} else {
	    this.y -= v;
	    this.height += v;
	}
    }

    @Override
    public boolean intersects(CollisionShape shape) {
	return (this.x + this.width > shape.getX()
		&& this.x < shape.getX() + shape.getWidth()
		&& this.y + this.height > shape.getY() && this.y < shape.getY()
		+ shape.getHeight());
    }

    @Override
    public void setBounds(double x1, double y1, int w1, int h1) {
	this.x = x1;
	this.y = y1;
	this.width = w1;
	this.height = h1;
    }

    public void setBounds(CollisionShape shape) {
	this.setBounds(shape.getX(), shape.getY(), shape.getWidth(), shape
		.getHeight());
    }

    @Override
    public void setLocation(double x1, double y1) {
	this.x = x1;
	this.y = y1;
    }

    @Override
    public void move(double dx, double dy) {
	this.x += dx;
	this.y += dy;
    }

    @Override
    public double getX() {
	return this.x;
    }

    @Override
    public double getY() {
	return this.y;
    }

    @Override
    public int getWidth() {
	return this.width;
    }

    @Override
    public int getHeight() {
	return this.height;
    }

    @Override
    public String toString() {
	return super.toString() + " " + "[x=" + this.x + ", y=" + this.y
		+ ", width=" + this.width + ", height=" + this.height + "]";
    }
}
