﻿package ugame.nanami;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Transparency;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;

public abstract class GameObject {
    public final GameEngine parent;
    public BaseGraphics bsGraphics;
    public BaseIO bsIO;
    public BaseLoader bsLoader;
    public BaseInput bsInput;
    public BaseTimer bsTimer;
    public BaseAudio bsMusic;
    public BaseAudio bsSound;
    public GameFontManager fontManager;

    private boolean finish;
    private boolean initialized;

    public GameObject(GameEngine parent) {
	this.parent = parent;
	this.grabEngines();
    }

    private void grabEngines() {
	this.bsGraphics = this.parent.bsGraphics;
	this.bsIO = this.parent.bsIO;
	this.bsLoader = this.parent.bsLoader;
	this.bsInput = this.parent.bsInput;
	this.bsTimer = this.parent.bsTimer;
	this.bsMusic = this.parent.bsMusic;
	this.bsSound = this.parent.bsSound;
	this.fontManager = this.parent.fontManager;
    }

    public final void start() {
	this.grabEngines();
	GameFont fpsFont = this.parent.fpsFont;
	if (!this.initialized) {
	    this.initResources();
	    this.initialized = true;
	}
	this.finish = false;
	System.gc();
	System.runFinalization();
	this.bsInput.refresh();
	this.bsTimer.refresh();
	long elapsedTime = 0;
	out: while (true) {
	    if (this.parent.inFocus) {
		// update game
		this.update(elapsedTime);
		this.parent.update(elapsedTime);
		this.bsInput.update(elapsedTime);
	    } else {
		try {
		    Thread.sleep(300);
		} catch (InterruptedException e) {

		}
	    }
	    do {
		if (this.finish || !this.parent.isRunning()) {
		    break out;
		}
		Graphics2D g = this.bsGraphics.getBackBuffer();
		this.render(g);
		this.parent.render(g);
		if (!this.parent.isDistribute()) {
		    if (g.getClip() != null) {
			g.setClip(null);
		    }
		    if (g.getComposite() != null) {
			if (g.getComposite() != AlphaComposite.SrcOver) {
			    g.setComposite(AlphaComposite.SrcOver);
			}
		    }
		    fpsFont.drawString(g, "FPS = " + this.getCurrentFPS() + "/"
			    + this.getFPS(), 9, this.getHeight() - 21);
		    fpsFont.drawString(g, "GTGE", this.getWidth() - 65, 9);
		}
		if (!this.parent.inFocus) {
		    this.parent.renderLostFocus(g);
		}
	    } while (this.bsGraphics.flip() == false);
	    elapsedTime = this.bsTimer.sleep();
	    if (elapsedTime > 100) {
		elapsedTime = 100;
	    }
	}
    }

    public void finish() {
	this.finish = true;
    }

    public abstract void initResources();

    public abstract void update(long elapsedTime);

    public abstract void render(Graphics2D g);

    public int getRandom(int low, int hi) {
	return NanamiUtil.getRandom(low, hi);
    }

    public int getWidth() {
	return this.bsGraphics.getSize().width;
    }

    public int getHeight() {
	return this.bsGraphics.getSize().height;
    }

    public BufferedImage takeScreenShot() {
	BufferedImage screen = NanamiUtil.createImage(this.getWidth(), this
		.getHeight(), Transparency.OPAQUE);
	Graphics2D g = screen.createGraphics();
	this.render(g);
	g.dispose();
	return screen;
    }

    public void takeScreenShot(File f) {
	NanamiUtil.saveImage(this.takeScreenShot(), f);
    }

    public int playMusic(String audiofile) {
	return this.bsMusic.play(audiofile);
    }

    public int playSound(String audiofile) {
	return this.bsSound.play(audiofile);
    }

    public void setFPS(int fps) {
	this.bsTimer.setFPS(fps);
    }

    public int getCurrentFPS() {
	return this.bsTimer.getCurrentFPS();
    }

    public int getFPS() {
	return this.bsTimer.getFPS();
    }

    public void drawFPS(Graphics2D g, int x, int y) {
	this.fontManager.getFont("FPS Font").drawString(g,
		"FPS = " + this.getCurrentFPS() + "/" + this.getFPS(), x, y);
    }

    public int getMouseX() {
	return this.bsInput.getMouseX();
    }

    public int getMouseY() {
	return this.bsInput.getMouseY();
    }

    public boolean checkPosMouse(int x1, int y1, int x2, int y2) {
	return (this.getMouseX() >= x1 && this.getMouseY() >= y1
		&& this.getMouseX() <= x2 && this.getMouseY() <= y2);
    }

    public boolean checkPosMouse(Sprite sprite, boolean pixelCheck) {
	Background bg = sprite.getBackground();
	if (this.getMouseX() < bg.getClip().x
		|| this.getMouseY() < bg.getClip().y
		|| this.getMouseX() > bg.getClip().x + bg.getClip().width
		|| this.getMouseY() > bg.getClip().y + bg.getClip().height) {
	    return false;
	}
	double mosx = this.getMouseX() + bg.getX() - bg.getClip().x;
	double mosy = this.getMouseY() + bg.getY() - bg.getClip().y;
	if (pixelCheck) {
	    try {
		return ((sprite.getImage().getRGB((int) (mosx - sprite.getX()),
			(int) (mosy - sprite.getY())) & 0xFF000000) != 0x00);
	    } catch (Exception e) {
		return false;
	    }
	} else {
	    return (mosx >= sprite.getX() && mosy >= sprite.getY()
		    && mosx <= sprite.getX() + sprite.getWidth() && mosy <= sprite
		    .getY()
		    + sprite.getHeight());
	}
    }

    public boolean click() {
	return this.bsInput.isMousePressed(MouseEvent.BUTTON1);
    }

    public boolean rightClick() {
	return this.bsInput.isMousePressed(MouseEvent.BUTTON3);
    }

    public boolean keyDown(int keyCode) {
	return this.bsInput.isKeyDown(keyCode);
    }

    public boolean keyPressed(int keyCode) {
	return this.bsInput.isKeyPressed(keyCode);
    }

    public void hideCursor() {
	this.bsInput.setMouseVisible(false);
    }

    public void showCursor() {
	this.bsInput.setMouseVisible(true);
    }

    public void setMaskColor(Color c) {
	this.bsLoader.setMaskColor(c);
    }

    public BufferedImage getImage(String imagefile, boolean useMask) {
	return this.bsLoader.getImage(imagefile, useMask);
    }

    public BufferedImage getImage(String imagefile) {
	return this.bsLoader.getImage(imagefile);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask) {
	return this.bsLoader.getImages(imagefile, col, row, useMask);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row) {
	return this.bsLoader.getImages(imagefile, col, row);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask, String sequence, int digit) {
	String mapping = imagefile + sequence + digit;
	BufferedImage[] image = this.bsLoader.getStoredImages(mapping);
	if (image == null) {
	    BufferedImage[] src = this.getImages(imagefile, col, row, useMask);
	    int count = sequence.length() / digit;
	    image = new BufferedImage[count];
	    for (int i = 0; i < count; i++) {
		image[i] = src[Integer.parseInt(sequence.substring(i * digit,
			((i + 1) * digit)))];
	    }
	    this.bsLoader.storeImages(mapping, image);
	}
	return image;
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    String sequence, int digit) {
	return this.getImages(imagefile, col, row, true, sequence, digit);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask, int start, int end) {
	String mapping = start + imagefile + end;
	BufferedImage[] image = this.bsLoader.getStoredImages(mapping);

	if (image == null) {
	    BufferedImage[] src = this.getImages(imagefile, col, row, useMask);
	    int count = end - start + 1;
	    image = new BufferedImage[count];
	    for (int i = 0; i < count; i++) {
		image[i] = src[start + i];
	    }
	    this.bsLoader.storeImages(mapping, image);
	}
	return image;
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    int start, int end) {
	return this.getImages(imagefile, col, row, true, start, end);
    }

}
