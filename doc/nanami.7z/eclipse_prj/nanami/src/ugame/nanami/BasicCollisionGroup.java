﻿package ugame.nanami;

public abstract class BasicCollisionGroup extends CollisionManager {
    protected final CollisionRect rect1 = new CollisionRect();
    protected final CollisionRect rect2 = new CollisionRect();
    public boolean pixelPerfectCollision;

    public BasicCollisionGroup() {

    }

    public CollisionShape getCollisionShape1(Sprite s1) {
	this.rect1.setBounds(s1.getX(), s1.getY(), s1.getWidth(), s1
		.getHeight());
	return this.rect1;
    }

    public CollisionShape getCollisionShape2(Sprite s2) {
	this.rect2.setBounds(s2.getX(), s2.getY(), s2.getWidth(), s2
		.getHeight());
	return this.rect2;
    }

    @Override
    public void checkCollision() {
	SpriteGroup group1 = this.getGroup1(), group2 = this.getGroup2();
	if (!group1.isActive() || !group2.isActive()) {
	    return;
	}
	Sprite[] member1 = group1.getSprites();
	Sprite[] member2 = group2.getSprites();
	int size1 = group1.getSize();
	int size2 = group2.getSize();
	Sprite sprite1, sprite2;
	CollisionShape shape1, shape2;
	for (int i = 0; i < size1; i++) {
	    sprite1 = member1[i];
	    if (!sprite1.isActive()
		    || (shape1 = this.getCollisionShape1(sprite1)) == null) {
		continue;
	    }
	    for (int j = 0; j < size2; j++) {
		sprite2 = member2[j];
		if (!sprite2.isActive() || sprite1 == sprite2
			|| (shape2 = this.getCollisionShape2(sprite2)) == null) {
		    continue;
		}
		if (this.isCollide(sprite1, sprite2, shape1, shape2)) {
		    this.collided(sprite1, sprite2);
		    if (!sprite1.isActive()
			    || (shape1 = this.getCollisionShape1(sprite1)) == null) {
			break;
		    }
		}
	    }
	}
    }

    public boolean isCollide(Sprite s1, Sprite s2, CollisionShape shape1,
	    CollisionShape shape2) {
	if (!this.pixelPerfectCollision) {
	    return (shape1.intersects(shape2));
	} else {
	    if (shape1.intersects(shape2)) {
		return CollisionManager.isPixelCollide(s1.getX(), s1.getY(), s1
			.getImage(), s2.getX(), s2.getY(), s2.getImage());
	    }
	    return false;
	}
    }

    public abstract void collided(Sprite s1, Sprite s2);

}
