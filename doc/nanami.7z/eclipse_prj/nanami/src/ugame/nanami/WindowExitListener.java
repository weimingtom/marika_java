﻿package ugame.nanami;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * @see http://code.google.com/p/gtge/
 */
public final class WindowExitListener implements WindowListener {
    private static final WindowListener singleton = new WindowExitListener();

    public static WindowListener getInstance() {
	return WindowExitListener.singleton;
    }

    private WindowExitListener() {

    }

    public void windowClosing(WindowEvent e) {
	System.exit(0);
    }

    public void windowOpened(WindowEvent e) {

    }

    public void windowClosed(WindowEvent e) {

    }

    public void windowIconified(WindowEvent e) {

    }

    public void windowDeiconified(WindowEvent e) {

    }

    public void windowActivated(WindowEvent e) {

    }

    public void windowDeactivated(WindowEvent e) {

    }
}
