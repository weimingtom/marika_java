﻿package ugame.nanami;

import java.awt.image.BufferedImage;

public class VolatileSprite extends AdvanceSprite {
    private static final long serialVersionUID = 3599186946035433218L;

    public VolatileSprite(BufferedImage[] image, double x, double y) {
	super(image, x, y);
	this.setAnimate(true);
    }

    public void update(long elapsedTime) {
	super.update(elapsedTime);
	if (!this.isAnimate()) {
	    this.setActive(false);
	}
    }
}
