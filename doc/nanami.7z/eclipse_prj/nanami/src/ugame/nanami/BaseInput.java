﻿package ugame.nanami;

public interface BaseInput {
    public static final int NO_BUTTON = Integer.MIN_VALUE;
    public static final int NO_KEY = Integer.MIN_VALUE;

    public void update(long elapsedTime);

    public void refresh();

    public void cleanup();

    public void mouseMove(int x, int y);

    public boolean isMouseExists();

    public int getMouseX();

    public int getMouseY();

    public int getMouseDX();

    public int getMouseDY();

    public int getMouseReleased();

    public boolean isMouseReleased(int button);

    public int getMousePressed();

    public boolean isMousePressed(int button);

    public boolean isMouseDown(int button);

    public void setMouseVisible(boolean visible);

    public boolean isMouseVisible();

    public int getKeyReleased();

    public boolean isKeyReleased(int keyCode);

    public int getKeyPressed();

    public boolean isKeyPressed(int keyCode);

    public boolean isKeyDown(int keyCode);

    public int getKeyTyped();

    public boolean isKeyTyped(int keyCode);

    public long getRepeatDelay();

    public void setRepeatDelay(long delay);

    public long getRepeatRate();

    public void setRepeatRate(long rate);

}
