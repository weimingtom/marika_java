﻿package ugame.nanami;

import java.awt.AlphaComposite;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;

/**
 * @see http://code.google.com/p/gtge/
 */
public class NanamiUtil {
    public static final GraphicsConfiguration CONFIG = GraphicsEnvironment
	    .getLocalGraphicsEnvironment().getDefaultScreenDevice()
	    .getDefaultConfiguration();

    private final static Random rnd = new Random();
    private static final MediaTracker tracker = new MediaTracker(new Canvas());
    private static Composite composite;

    private NanamiUtil() {

    }

    public static Object expand(Object src, int increase, boolean bottom) {
	int size = Array.getLength(src);
	Object dest = Array.newInstance(src.getClass().getComponentType(), size
		+ increase);
	System.arraycopy(src, 0, dest, (bottom) ? 0 : increase, size);
	return dest;
    }

    public static Object expand(Object src, int increase) {
	return expand(src, increase, true);
    }

    public static Object expand(Object src, int increase, boolean bottom,
	    Class type) {
	if (src == null) {
	    return Array.newInstance(type, 1);
	}
	return expand(src, increase, bottom);
    }

    public static Object cut(Object src, int position) {
	int size = Array.getLength(src);
	if (size == 1) {
	    return Array.newInstance(src.getClass().getComponentType(), 0);
	}
	int numMoved = size - position - 1;
	if (numMoved > 0) {
	    System.arraycopy(src, position + 1, src, position, numMoved);
	}
	size--;
	Object dest = Array
		.newInstance(src.getClass().getComponentType(), size);
	System.arraycopy(src, 0, dest, 0, size);
	return dest;
    }

    public static void mixElements(Object src) {
	int size = Array.getLength(src);
	Object tempVal;
	int tempPos;
	for (int i = 0; i < size; i++) {
	    tempPos = getRandom(i, size - 1);
	    tempVal = Array.get(src, tempPos);
	    Array.set(src, tempPos, Array.get(src, i));
	    Array.set(src, i, tempVal);
	}
    }

    public static Random getRandomObject() {
	return rnd;
    }

    public static int getRandom(int lowerBound, int upperBound) {
	return lowerBound + rnd.nextInt(upperBound - lowerBound + 1);
    }

    public static String[] compactStrings(String[] s) {
	String[] result = new String[s.length];
	int offset = 0;
	for (int i = 0; i < s.length; ++i) {
	    offset += s[i].length();
	}
	char[] allchars = new char[offset];
	offset = 0;
	for (int i = 0; i < s.length; ++i) {
	    s[i].getChars(0, s[i].length(), allchars, offset);
	    offset += s[i].length();
	}
	String allstrings = new String(allchars);
	offset = 0;
	for (int i = 0; i < s.length; ++i) {
	    result[i] = allstrings.substring(offset, offset += s[i].length());
	}
	return result;
    }

    public static BufferedImage getImage(URL url, int transparency) {
	try {
	    Image image = Toolkit.getDefaultToolkit().getImage(url);
	    waitForResource(image);
	    BufferedImage buffImage = createImage(image.getWidth(null), image
		    .getHeight(null), transparency);
	    Graphics2D g = (Graphics2D) buffImage.createGraphics();
	    g.setComposite(AlphaComposite.Src);
	    g.drawImage(image, 0, 0, null);
	    g.dispose();
	    return buffImage;
	} catch (Exception e) {
	    System.err.println("ERROR: Unable to load Image = " + url);
	    e.printStackTrace();
	    return createImage(50, 50);
	}
    }

    public static BufferedImage getImage(URL url) {
	return getImage(url, Transparency.OPAQUE);
    }

    public static BufferedImage getImage(URL url, Color keyColor) {
	try {
	    Image image = Toolkit.getDefaultToolkit().getImage(url);
	    waitForResource(image);
	    return applyMask(image, keyColor);
	} catch (Exception e) {
	    System.err.println("ERROR: Unable to load Image = " + url);
	    e.printStackTrace();
	    return createImage(50, 50);
	}
    }

    public static BufferedImage[] getImages(URL url, int col, int row,
	    int transparency) {
	return splitImages(getImage(url, transparency), col, row);
    }

    public static BufferedImage[] getImages(URL url, int col, int row) {
	return splitImages(getImage(url), col, row);
    }

    public static BufferedImage[] getImages(URL url, int col, int row,
	    Color keyColor) {
	return splitImages(getImage(url, keyColor), col, row);
    }

    public static BufferedImage createImage(int width, int height,
	    int transparency) {
	return CONFIG.createCompatibleImage(width, height, transparency);
    }

    public static BufferedImage createImage(int width, int height) {
	return createImage(width, height, Transparency.OPAQUE);
    }

    private static void waitForResource(Image image) throws Exception {
	if (image == null) {
	    throw new NullPointerException();
	}
	try {
	    tracker.addImage(image, 0);
	    tracker.waitForAll();
	    if ((tracker.statusID(0, true) & MediaTracker.ERRORED) != 0) {
		throw new RuntimeException();
	    }
	} catch (Exception e) {
	    tracker.removeImage(image, 0);
	    throw e;
	}
    }

    public static BufferedImage applyMask(Image img, Color keyColor) {
	BufferedImage alpha = createImage(img.getWidth(null), img
		.getHeight(null), Transparency.BITMASK);
	Graphics2D g = alpha.createGraphics();
	g.setComposite(AlphaComposite.Src);
	g.drawImage(img, 0, 0, null);
	g.dispose();
	for (int y = 0; y < alpha.getHeight(); y++) {
	    for (int x = 0; x < alpha.getWidth(); x++) {
		int col = alpha.getRGB(x, y);
		if (col == keyColor.getRGB()) {
		    alpha.setRGB(x, y, col & 0x00ffffff);
		}
	    }
	}
	return alpha;
    }

    public static BufferedImage[] splitImages(BufferedImage image, int col,
	    int row) {
	int total = col * row;
	int frame = 0;
	int i, j;
	int w = image.getWidth() / col;
	int h = image.getHeight() / row;
	BufferedImage[] images = new BufferedImage[total];
	for (j = 0; j < row; j++) {
	    for (i = 0; i < col; i++) {
		int transparency = image.getColorModel().getTransparency();
		images[frame] = createImage(w, h, transparency);
		Graphics2D g = images[frame].createGraphics();
		g.drawImage(image, 0, 0, w, h, i * w, j * h, (i + 1) * w,
			(j + 1) * h, null);
		g.dispose();
		frame++;
	    }
	}
	return images;
    }

    public static BufferedImage rotate(BufferedImage src, int angle) {
	int w = src.getWidth(), h = src.getHeight(), transparency = src
		.getColorModel().getTransparency();
	BufferedImage image = createImage(w, h, transparency);
	Graphics2D g = image.createGraphics();
	g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
		RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	g.rotate(Math.toRadians(angle), w / 2, h / 2);
	g.drawImage(src, 0, 0, null);
	g.dispose();
	return image;
    }

    public static BufferedImage resize(BufferedImage src, int w, int h) {
	int transparency = src.getColorModel().getTransparency();
	BufferedImage image = createImage(w, h, transparency);
	Graphics2D g = image.createGraphics();
	g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
		RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	g.drawImage(src, 0, 0, w, h, 0, 0, src.getWidth(), src.getHeight(),
		null);
	g.dispose();
	return image;
    }

    public static BufferedImage flipHorizontal(BufferedImage src) {
	int w = src.getWidth(), h = src.getHeight();
	BufferedImage flipped = createImage(w, h, src.getColorModel()
		.getTransparency());
	Graphics2D g = flipped.createGraphics();
	g.drawImage(src, 0, 0, w, h, w, 0, 0, h, null);
	g.dispose();
	return flipped;
    }

    public static BufferedImage flipVertical(BufferedImage src) {
	int w = src.getWidth(), h = src.getHeight();
	BufferedImage flipped = createImage(w, h, src.getColorModel()
		.getTransparency());
	Graphics2D g = flipped.createGraphics();
	g.drawImage(src, 0, 0, w, h, 0, h, w, 0, null);
	g.dispose();
	return flipped;
    }

    public static void saveImage(BufferedImage image, File imagefile) {
	try {
	    ImageIO.write(image, "png", imagefile);
	} catch (IOException e) {
	    System.err.println("ERROR: unable to save = " + imagefile);
	    e.printStackTrace();
	}
    }

    public static byte[] toByteArray(BufferedImage image, String extension) {
	if (image != null) {
	    ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
	    try {
		ImageIO.write(image, extension, baos);
	    } catch (IOException e) {
		throw new IllegalStateException(e.toString());
	    }
	    byte[] b = baos.toByteArray();
	    return b;
	}
	return new byte[0];
    }

    public static BufferedImage fromByteArray(byte[] imagebytes) {
	try {
	    if (imagebytes != null && (imagebytes.length > 0)) {
		BufferedImage im = ImageIO.read(new ByteArrayInputStream(
			imagebytes));
		return im;
	    }
	    return null;
	} catch (IOException e) {
	    throw new IllegalArgumentException(e.toString());
	}
    }

    public static void saveComposite(Graphics2D g) {
	composite = g.getComposite();
    }

    public static void loadComposite(Graphics2D g) {
	g.setComposite(composite);
	composite = null;
    }

    public static void setTransparent(Graphics2D g, float alpha) {
	g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
		alpha));
    }

    public static boolean fileWrite(String[] text, File file) {
	try {
	    BufferedWriter out = new BufferedWriter(new FileWriter(file));
	    PrintWriter writeOut = new PrintWriter(out);
	    for (int i = 0; i < text.length; i++) {
		writeOut.println(text[i]);
	    }
	    writeOut.close();
	    return true;
	} catch (IOException e) {
	    e.printStackTrace();
	    return false;
	}
    }

    public static String[] fileRead(File file) {
	try {
	    FileReader in = new FileReader(file);
	    BufferedReader readIn = new BufferedReader(in);
	    ArrayList list = new ArrayList(50);
	    String data;
	    while ((data = readIn.readLine()) != null) {
		list.add(data);
	    }
	    readIn.close();
	    return compactStrings((String[]) list.toArray(new String[0]));
	} catch (IOException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public static String[] fileRead(InputStream stream) {
	try {
	    InputStreamReader in = new InputStreamReader(stream);
	    BufferedReader readIn = new BufferedReader(in);
	    ArrayList list = new ArrayList(50);
	    String data;
	    while ((data = readIn.readLine()) != null) {
		list.add(data);
	    }
	    readIn.close();
	    return compactStrings((String[]) list.toArray(new String[0]));
	} catch (IOException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public static String[] fileRead(URL url) {
	try {
	    return fileRead(url.openStream());
	} catch (Exception e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public static File setExtension(File f, String ext) {
	String s = f.getAbsolutePath();
	int i = s.lastIndexOf('.');
	if (i < 0) {
	    return new File(s + "." + ext);
	} else {
	    return new File(s.substring(0, i) + "." + ext);
	}
    }

    public static String getExtension(File f) {
	return getExtension(f.getName());
    }

    public static String getExtension(String st) {
	int index = getIndex(st);
	String s = (index <= 0) ? st : st.substring(index + 1);
	String ext = "";
	int i = s.lastIndexOf('.');
	if (i > 0 && i < s.length() - 1) {
	    ext = s.substring(i + 1);
	}
	return ext;
    }

    public static String getName(File f) {
	return getName(f.getName());
    }

    public static String getName(String st) {
	int index = getIndex(st);
	String s = (index <= 0) ? st : st.substring(index + 1);
	String name = s;
	int i = s.lastIndexOf('.');
	if (i > 0 && i < s.length()) {
	    name = s.substring(0, i);
	}
	return name;
    }

    public static String getPath(File f) {
	try {
	    return getPath(f.getCanonicalPath());
	} catch (IOException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public static String getPath(String st) {
	String path = "";
	int index = getIndex(st);
	if (index > 0) {
	    path = st.substring(0, index + 1);
	}
	return path;
    }

    public static String getPathName(File f) {
	try {
	    return getPathName(f.getCanonicalPath());
	} catch (IOException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    public static String getPathName(String st) {
	String path = "";
	int index = getIndex(st);
	if (index > 0) {
	    path = st.substring(0, index + 1);
	} else {
	    index = 0;
	}
	String s = (index <= 0) ? st : st.substring(index + 1);
	String name = s;
	int i = s.lastIndexOf('.');
	if (i > 0 && i < s.length()) {
	    name = s.substring(0, i);
	}
	return path + name;
    }

    private static int getIndex(String st) {
	int index = st.lastIndexOf('/');
	if (index < 0) {
	    index = st.lastIndexOf(File.separatorChar);
	}
	return index;
    }

    public static Font createTrueTypeFont(URL url, int style, float size) {
	Font f = null;
	try {
	    f = Font.createFont(Font.TRUETYPE_FONT, url.openStream());
	} catch (IOException e) {
	    System.err.println("ERROR: " + url
		    + " is not found or can not be read");
	    f = new Font("Verdana", 0, 0);
	} catch (FontFormatException e) {
	    System.err.println("ERROR: " + url
		    + " is not a valid true type font");
	    f = new Font("Verdana", 0, 0);
	}
	return f.deriveFont(style, size);
    }

    public static BufferedImage createBitmapFont(Font f, Color col) {
	Graphics2D g = createImage(1, 1).createGraphics();
	FontMetrics fm = g.getFontMetrics(f);
	g.dispose();
	byte[] bytes = new byte[95];
	for (int i = 0; i < bytes.length; i++) {
	    bytes[i] = (byte) (32 + i);
	}
	String st = new String(bytes);
	int w = fm.stringWidth(st);
	int h = fm.getHeight();
	int len = st.length();
	int x = 0;
	int y = h - fm.getDescent() + 1;
	Color delim = Color.GREEN;
	if (delim.equals(col)) {
	    delim = Color.YELLOW;
	}
	BufferedImage bitmap = createImage(w, h, Transparency.BITMASK);
	g = bitmap.createGraphics();
	g.setFont(f);
	for (int i = 0; i < len; i++) {
	    char c = st.charAt(i);
	    g.setColor(delim);
	    g.drawLine(x, 0, x, 0);
	    g.setColor(col);
	    g.drawString(String.valueOf(c), x, y);
	    x += fm.charWidth(c);
	}
	g.dispose();
	return bitmap;
    }
}
