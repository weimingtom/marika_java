﻿package ugame.nanami;

import java.net.URL;

public abstract class BaseAudioRenderer {
    public static final int PLAYING = 1;
    public static final int STOPPED = 2;
    public static final int END_OF_SOUND = 3;
    public static final int ERROR = 4;

    private URL audiofile;
    private boolean loop;
    protected int status;
    protected float volume;

    public BaseAudioRenderer() {
	this.volume = 1.0f;
	this.status = BaseAudioRenderer.STOPPED;
    }

    protected void setSoundVolume(float volume) {

    }

    public void play(URL audiofile) {
	this.status = BaseAudioRenderer.PLAYING;
	if (this.audiofile == audiofile) {
	    this.replaySound(audiofile);
	    return;
	}
	this.audiofile = audiofile;
	this.playSound(audiofile);
    }

    public void play() {
	this.status = BaseAudioRenderer.PLAYING;
	this.replaySound(this.audiofile);
    }

    public void stop() {
	if (this.audiofile != null && this.status == BaseAudioRenderer.PLAYING) {
	    this.status = BaseAudioRenderer.STOPPED;
	    this.stopSound();
	}
    }

    public void setLoop(boolean loop) {
	this.loop = loop;
    }

    public boolean isLoop() {
	return this.loop;
    }

    public void setVolume(float volume) {
	if (volume < 0.0f) {
	    volume = 0.0f;
	}
	if (volume > 1.0f) {
	    volume = 1.0f;
	}
	if (this.volume != volume && this.isVolumeSupported()) {
	    this.volume = volume;
	    this.setSoundVolume(volume);
	}
    }

    public float getVolume() {
	return this.volume;
    }

    public boolean isVolumeSupported() {
	return true;
    }

    public URL getAudioFile() {
	return this.audiofile;
    }

    public int getStatus() {
	return this.status;
    }

    public abstract boolean isAvailable();

    protected abstract void playSound(URL audiofile);

    protected abstract void replaySound(URL audiofile);

    protected abstract void stopSound();
}
