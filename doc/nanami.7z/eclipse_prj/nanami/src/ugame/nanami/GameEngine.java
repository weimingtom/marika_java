﻿package ugame.nanami;

import java.awt.Graphics2D;

public abstract class GameEngine extends Game {
    private GameObject currentGame;
    private int currentGameID;
    public GameObject nextGame;
    public int nextGameID = 0;

    public GameEngine() {

    }

    @Override
    void startGameLoop() {
	// start the timer
	this.bsTimer.startTimer();

	while (this.isRunning()) {
	    // refresh global game state
	    this.bsInput.refresh();
	    this.refresh();

	    // validate game to be played next
	    if (this.nextGameID == -1 && this.nextGame == null) {
		// next game is not provided, game ended
		this.finish();
		break;
	    }

	    // get the game object to be played next
	    this.currentGameID = this.nextGameID;
	    this.currentGame = (this.nextGame != null) ? this.nextGame : this
		    .getGame(this.nextGameID);

	    if (this.currentGame == null) {
		// game is not available, exit the game
		System.err.println("ERROR: GameObject with ID = "
			+ this.currentGameID + " is not available!!");
		this.finish();
		break;
	    }

	    // clear next game, to avoid this current game played forever
	    if (this.nextGame == this.currentGame) {
		this.nextGame = null;
	    }
	    if (this.nextGameID == this.currentGameID) {
		this.nextGameID = -1;
	    }

	    // running the game
	    // in here there's other game loop,
	    // loop ended when the game finished, calling GameObject.finish()
	    this.currentGame.start();
	}

	// dispose everything
	this.bsTimer.stopTimer();
	this.bsSound.stopAll();
	this.bsMusic.stopAll();

	if (this.isFinish()) {
	    this.bsGraphics.cleanup();
	    this.notifyExit();
	}
    }

    /**
     * *************************************************************************
     */
    /**
     * ************************** GAME OPERATION *******************************
     */
    /**
     * *************************************************************************
     */

    /**
     * Initialization of global game resources.
     * <p>
     * 
     * The implementation of this method provided by the <code>GameEngine</code>
     * class does nothing.
     */
    public void initResources() {
    }

    /**
     * Global game update.
     * <p>
     * 
     * The implementation of this method provided by the <code>GameEngine</code>
     * class does nothing.
     * 
     * @param elapsedTime
     *            time elapsed since last update
     */
    public void update(long elapsedTime) {
    }

    public void render(Graphics2D g) {

    }

    public void refresh() {

    }

    public abstract GameObject getGame(int GameID);

    public GameObject getCurrentGame() {
	return this.currentGame;
    }

    public int getCurrentGameID() {
	return this.currentGameID;
    }

}
