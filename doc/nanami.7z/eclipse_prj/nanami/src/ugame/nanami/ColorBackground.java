﻿package ugame.nanami;

import java.awt.Color;
import java.awt.Graphics2D;

public class ColorBackground extends Background {
    private static final long serialVersionUID = 3668701023849676983L;

    private Color color;

    public ColorBackground(Color bgColor, int w, int h) {
	super(w, h);
	this.color = bgColor;
    }

    public ColorBackground(Color bgColor) {
	this.color = bgColor;
    }

    public Color getColor() {
	return this.color;
    }

    public void setColor(Color bgColor) {
	this.color = bgColor;
    }

    @Override
    public void render(Graphics2D g, int xbg, int ybg, int x, int y, int w,
	    int h) {
	g.setColor(this.color);
	g.fillRect(x, y, w, h);
    }
}
