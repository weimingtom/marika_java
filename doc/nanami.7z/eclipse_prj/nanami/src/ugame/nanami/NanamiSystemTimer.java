﻿package ugame.nanami;

/**
 * @see http://code.google.com/p/gtge/
 */
public class NanamiSystemTimer implements BaseTimer {
    private int fps = 50;
    private long msDelay;
    private long start;
    private long end;
    private long timeDiff;
    private long sleepTime;
    private long overSleepTime;
    private boolean running;
    private NanamiFPSCounter fpsCounter;

    public NanamiSystemTimer() {
	this.fpsCounter = new NanamiFPSCounter();
    }

    public void startTimer() {
	if (this.running) {
	    this.stopTimer();
	}
	this.running = true;

	this.msDelay = 1000 / this.fps;
	this.refresh();

	this.fpsCounter.refresh();
    }

    public void stopTimer() {
	this.running = false;
    }

    public long sleep() {
	this.end = System.currentTimeMillis();
	this.timeDiff = this.end - this.start;
	this.sleepTime = (this.msDelay - this.timeDiff) - this.overSleepTime;
	if (this.sleepTime > 0) {
	    try {
		Thread.sleep(this.sleepTime);
	    } catch (InterruptedException e) {

	    }
	    this.overSleepTime = (System.currentTimeMillis() - this.end)
		    - this.sleepTime;
	} else {
	    try {
		Thread.sleep(1);
	    } catch (InterruptedException e) {

	    }
	    this.overSleepTime = 0;
	}
	this.fpsCounter.calculateFPS();
	long end = System.currentTimeMillis();
	long elapsedTime = end - this.start;
	this.start = end;
	return elapsedTime;
    }

    public boolean isRunning() {
	return this.running;
    }

    public int getCurrentFPS() {
	return this.fpsCounter.getCurrentFPS();
    }

    public int getFPS() {
	return this.fps;
    }

    public void setFPS(int fps) {
	if (this.fps == fps) {
	    return;
	}
	this.fps = fps;
	if (this.running) {
	    this.startTimer();
	}
    }

    public long getTime() {
	return System.currentTimeMillis();
    }

    public void refresh() {
	this.start = System.currentTimeMillis();
	this.overSleepTime = 0;
    }
}
