﻿package ugame.nanami;

/**
 * @see http://www.javalobby.org/forums/thread.jspa?threadID=16867&tstart=0
 */
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.util.Vector;
import javax.swing.JFrame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.Math;
import java.net.Socket;

/**
 * 
 * @author Administrator
 * @usage mysql -uroot -p123456 chap3jdbc select * from users order by uid;
 */
public class NanamiMainMT {
    static final long serialVersionUID = 0L;
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 600;
    private static final String IMG_DIR = "assets/LB.PNG";
    private static final int CHARACTER_COUNT = 10;
    private static final int TIMER_INTEVAL = 2;
    private static final int FPS = 10;
    private static final int FRAME_DELAY = 1000 / FPS;

    public static final int RATE_FACT = 20;

    public static void main(String[] args) {
	JFrame frame = new JFrame("My Game Demo");
	Canvas gui = new Canvas();
	frame.getContentPane().add(gui);
	frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	frame.setLocationRelativeTo(null);
	frame.addWindowListener(new WindowAdapter() {
	    @Override
	    public void windowClosing(WindowEvent e) {
		System.exit(0);
	    }
	});
	GameLoop game = new GameLoop(gui);
	Thread gameThread = new Thread(game);
	gameThread.setPriority(Thread.MIN_PRIORITY);
	frame.setVisible(true);
	gameThread.start();
	for (int i = 0; i < CHARACTER_COUNT; i++) {
	    bench b = new bench(i, game.points);
	    b.start();
	}
    }

    private static class GameLoop implements Runnable {
	private boolean isRunning;
	private Canvas gui;
	private long cycleTime;
	private long lastTime;

	public GameLoop(Canvas canvas) {
	    gui = canvas;
	    isRunning = true;
	    gui.addMouseListener(new MouseAdapter() {
		@Override
		public void mousePressed(MouseEvent e) {
		    onMousePressed(e);
		}
	    });
	    imgCharacter = Toolkit.getDefaultToolkit().createImage(IMG_DIR);
	    for (int i = 0; i < CHARACTER_COUNT; i++) {
		NanamiCharacterMT c = new NanamiCharacterMT();
		c.setPoint(new Point(0, 0));
		c.setTargetPoint(new Point(0, 0));
		points.add(c);
	    }
	}

	@Override
	public void run() {
	    cycleTime = System.currentTimeMillis();
	    gui.createBufferStrategy(2);
	    BufferStrategy strategy = gui.getBufferStrategy();
	    while (isRunning) {
		if (System.currentTimeMillis() - lastTime > TIMER_INTEVAL) {
		    onTimer();
		    lastTime = System.currentTimeMillis();
		}
		updateGameState();
		updateGUI(strategy);
		synchFramerate();
	    }
	}

	private void synchFramerate() {
	    cycleTime = cycleTime + FRAME_DELAY;
	    long difference = cycleTime - System.currentTimeMillis();
	    try {
		Thread.sleep(Math.max(0, difference));
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	@SuppressWarnings("unused")
	public void shutdown() {
	    isRunning = false;
	}

	private void updateGameState() {

	}

	private void updateGUI(BufferStrategy strategy) {
	    Graphics g = strategy.getDrawGraphics();

	    g.setColor(Color.WHITE);
	    g.fillRect(0, 0, gui.getWidth(), gui.getHeight());
	    g.setColor(Color.BLACK);

	    g.setColor(Color.RED);
	    for (int i = 0; i < points.size(); i++) {
		for (int index = 0; index < points.size(); index++) {
		    Point p = (Point) (points.elementAt(index).getPoint());
		    g.drawImage(imgCharacter, p.x, p.y, gui);
		    g.drawString("char " + index, p.x, p.y);
		}
	    }

	    g.dispose();
	    strategy.show();
	}

	public void onMousePressed(MouseEvent e) {

	}

	public void onTimer() {
	    // for(int i = 0; i < points.size(); i++) {
	    // points.elementAt(i).move();
	    // }
	}

	private Vector<NanamiCharacterMT> points = new Vector<NanamiCharacterMT>();
	private Image imgCharacter;
    }

    private static class bench extends Thread {
	private int threadNum;
	private boolean isRunning;
	private long cycleTime;
	private Vector<NanamiCharacterMT> points;

	public bench(int threadNum, Vector<NanamiCharacterMT> points) {
	    this.threadNum = threadNum;
	    this.points = points;
	    this.isRunning = true;
	}

	@Override
	public void run() {
	    startConnect();
	    long lastTime = System.currentTimeMillis();
	    cycleTime = System.currentTimeMillis();
	    if (points == null)
		return;
	    while (isRunning) {
		if (System.currentTimeMillis() - lastTime > TIMER_INTEVAL) {
		    onTimer();
		    lastTime = System.currentTimeMillis();
		}
		synchFramerate();
	    }
	}

	private void onTimer() {
	    NanamiCharacterMT ch = points.elementAt(threadNum);
	    boolean isChanged = ch.move();

	    if (isChanged) {
		String strMsg = "setlocation," + this.threadNum + ","
			+ ch.getTargetPoint().x + "," + ch.getTargetPoint().y;
		sendMsg(strMsg);
	    }
	}

	private void synchFramerate() {
	    cycleTime = cycleTime + FRAME_DELAY;
	    long difference = cycleTime - System.currentTimeMillis();
	    try {
		Thread.sleep(Math.max(0, difference));
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	private Socket socket;
	private BufferedReader in;
	private PrintWriter out;
	public final static int DEFAULT_PORT = 6543;
	private boolean bConnected;

	public void startConnect() {
	    bConnected = false;
	    try {
		socket = new Socket("127.0.0.1", DEFAULT_PORT);
		bConnected = true;
		System.out.println("Connection OK");
		in = new BufferedReader(new InputStreamReader(socket
			.getInputStream()));
		out = new PrintWriter(socket.getOutputStream());
	    } catch (IOException e) {
		// e.printStackTrace();
		bConnected = false;
		System.out.println("Connection failed");
	    }
	}

	public void sendMsg(String str) {
	    try {
		if (bConnected) {
		    out.println(str);
		    out.flush();
		    String strRead = in.readLine();
		    // System.out.println(str);
		    if (strRead != null) {
			// System.out.println(strRead);
		    }
		}
	    } catch (Exception e) {
		bConnected = false;
		// e.printStackTrace();
		System.out.println("Write/Read failed");
	    }
	}
    }
}
