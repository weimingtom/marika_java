import java.awt.*;
import java.awt.event.*;

import ugame.nanami.*;

public class Tutorial8_3 extends Game {
    AnimatedSprite sprite;
    ImageBackground background;
    GameFont font;
    
    @Override
    public void initResources() {
        background = new ImageBackground(getImage("resources/background.jpg"));
        background.setClip(100, 100, 350, 300);
        sprite = new AnimatedSprite(getImages("resources/plane2.png", 3, 1));
        sprite.setBackground(background);
        sprite.setAnimate(true);
        sprite.setLoopAnim(true);
        font = fontManager.getFont(getImages("resources/font.png", 20, 3),
                                   " !            .,0123" +
                                   "456789:   -? ABCDEFG" +
                                   "HIJKLMNOPQRSTUVWXYZ ");
    }

    @Override
    public void update(long elapsedTime) {
        background.update(elapsedTime);
        sprite.update(elapsedTime);
        double speedX = 0, speedY = 0;
        if (keyDown(KeyEvent.VK_LEFT))  
            speedX = -0.1;
        if (keyDown(KeyEvent.VK_RIGHT)) 
            speedX =  0.1;
        if (keyDown(KeyEvent.VK_UP))    
            speedY = -0.1;
        if (keyDown(KeyEvent.VK_DOWN))  
            speedY =  0.1;
        sprite.setSpeed(speedX, speedY);
        background.setToCenter(sprite);
    }

    @Override
    public void render(Graphics2D g) {
        g.setColor(Color.BLUE);
        g.fillRect(0, 0, getWidth(), getHeight());
        background.render(g);
        sprite.render(g);
        font.drawString(g, "THE SPRITE IS LOCATED AT " +
                        (int) sprite.getX() + ", " + (int) sprite.getY(),
                        100, 50);
        font.drawString(g, "ON THE BACKGROUND", 100, 70);
        font.drawString(g, "BACKGROUND VIEWPORT", 100, 415);
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial8_3(), new Dimension(640,480), false);
        game.start();
    }

}